# PROGRESS - Golden Shop Manager

## PARTIE A : GARDES CÔTÉ BASE (`src/db/index.ts`)
- [x] A1. `createSaleTransaction` : gardes quantité <= 0, prix < 0, paidAmount > totalAmount, paidAmount < 0, stock insuffisant, remainingAmount > 0 sans client (`src/db/index.ts:696-749`)
- [x] A2. `deliverRepairOrder` : anti double-livraison (`repair.status === 'delivered'`), vérification du montant restant, bénéfice compté une seule fois (`src/db/index.ts:2232-2297` & `src/pages/DashboardPage.tsx:107-125`)
- [x] A3. Transactions atomiques : `returnSaleItemTransaction` (`src/db/index.ts:887-955`), `registerCustomerPaymentAdvancedTransaction` (`src/db/index.ts:1060-1208`), `getNextBonNumber` / `getNextRepairNumber` / `getNextPurchaseOrderNumber` appelés à l'intérieur de la transaction Dexie de création (`src/db/index.ts:751`, `1677`, `2198`)

## PARTIE B : DATES (`src/lib/dateUtils.ts`)
- [x] B1. Remplacement des occurrences métier de `toISOString` par `todayMA()` / `monthMA()` / `nowMA()` (`src/pages/SettingsPage.tsx:229,239`, `src/db/index.ts:1189,1244,1293`). Seules 48 occurrences techniques (`created_at`, `updated_at`, `deleted_at`, `detectedAt`) subsistent.

## PARTIE C : PERMISSIONS (`src/lib/permissions.ts`)
- [x] C1. `src/lib/permissions.ts` source unique (`hasPermission`, `isOwnerRole`, `canAccessTab`), mode local = `owner` (`src/lib/permissions.ts:1-66`, `src/lib/accessAuth.tsx:419-424`)
- [x] C2. Protection dans `src/App.tsx` de l'accès direct aux onglets réservés au propriétaire (`dashboard`, `reports`, `expenses`, `suppliers`, `settings`, `activity`) avec redirection vers `pos` (`src/App.tsx:49-53, 211-235`)
- [x] C3. Masquage pour l'employé : prix d'achat/coût, bénéfice, suppression de bon/article/réparation, annulation/modification de paiement, import/export/effacement, gestion des utilisateurs (`58` vérifications `can(...)` dans `src/`)
- [x] C4. Accès direct au Journal d'activité dans le menu propriétaire (`src/components/Sidebar.tsx:48`, `src/components/BottomNav.tsx:50`, `src/App.tsx:230-231`)

## PARTIE D : SUPABASE (`supabase/`)
- [x] D1. Edge Function `supabase/functions/create-employee/index.ts` (Deno, vérifie owner actif, clé service role côté serveur, upsert `users_profile` employee actif) branchée dans `src/pages/SettingsPage.tsx:886-995` via `src/lib/supabaseSync.ts:554-590`
- [x] D2. `supabase/schema.sql` : 23 politiques RLS, triggers `updated_at` automatiques (`supabase/schema.sql:516-567`), trigger `auth.users` (`supabase/schema.sql:573-609`), RPC atomiques `next_bon_number`, `next_repair_number`, `next_purchase_order_number`, `next_trade_in_number` (`supabase/schema.sql:74-159`)
- [x] D3. `src/lib/supabaseSync.ts` : calcul du stock via mouvements (`previousQty + sum(quantityDelta)`, lignes `423-446`) et renumérotation des bons provisoires `G-L-`, `REP-L-`, `R-L-`, `BA-L-` via RPC serveur (`src/lib/supabaseSync.ts:304-354`)
- [~] D4. Tests réels contre une instance Supabase Cloud en ligne et déploiement CLI de l'Edge Function (documentés dans `TODO_USER.md` et `SETUP_SUPABASE.md`)

## PARTIE E : FONCTIONNALITÉS / ASSETS
- [x] E1. Lazy-load des pages (`React.lazy` + `Suspense` dans `src/App.tsx:20-32`) et import dynamique de `jspdf` / `jspdf-autotable` au clic (`src/lib/pdfGenerator.ts:6-12`)
- [x] E2. Vraies icônes PWA PNG 192x192 et 512x512 (monogramme Or/Noir "GS") générées dans `public/pwa-192x192.png` et `public/pwa-512x512.png`

## PARTIE F : LIVRABLES FINAUX
- [x] F1. `CHANGELOG.md`, `TESTS.md`, `SETUP_SUPABASE.md`, `TODO_USER.md` mis à jour et archive `golden-shop-manager.zip` recréée sans `node_modules` ni `dist`
- [x] F2. `PROGRESS.md` mis à jour honnêtement avec preuves
