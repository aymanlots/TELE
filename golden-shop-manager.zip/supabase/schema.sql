-- ============================================================================
-- GOLDEN SHOP MANAGER — SUPABASE MULTI-DEVICE SYNCHRONIZATION SCHEMA & RLS
-- Context: Single store shared between Owner ('owner') and Employee ('employee')
-- ============================================================================

create extension if not exists "pgcrypto";

-- 1. STORE TABLE (Single store record + shared atomic counters)
create table if not exists public.store (
  id uuid primary key default '00000000-0000-4000-8000-000000000001'::uuid,
  store_name text not null default 'Golden Shop Manager',
  bon_seq bigint not null default 0,
  repair_seq bigint not null default 0,
  po_seq bigint not null default 0,
  trade_in_seq bigint not null default 0,
  migrated_at timestamptz,
  updated_at timestamptz not null default now()
);

alter table public.store add column if not exists po_seq bigint not null default 0;
alter table public.store add column if not exists trade_in_seq bigint not null default 0;

insert into public.store (id, store_name, bon_seq, repair_seq, po_seq, trade_in_seq)
values ('00000000-0000-4000-8000-000000000001'::uuid, 'Golden Shop Manager', 0, 0, 0, 0)
on conflict (id) do nothing;

-- 2. USERS PROFILE TABLE (Roles: 'owner' | 'employee')
create table if not exists public.users_profile (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  role text not null default 'employee' check (role in ('owner', 'employee')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Helper SQL functions for RLS role checks
create or replace function public.get_server_time()
returns timestamptz
language sql
security definer
stable
set search_path = public
as $$
  select now();
$$;

create or replace function public.is_active_shop_member()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.users_profile
    where id = auth.uid() and active = true
  );
$$;

create or replace function public.is_shop_owner()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.users_profile
    where id = auth.uid() and role = 'owner' and active = true
  );
$$;

-- 3. ATOMIC SHARED SEQUENTIAL NUMBERING RPC FUNCTIONS (Partie 2 #5)
create or replace function public.next_bon_number()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  next_val bigint;
begin
  if not public.is_active_shop_member() then
    raise exception 'Unauthorized';
  end if;

  update public.store
  set bon_seq = bon_seq + 1,
      updated_at = now()
  where id = '00000000-0000-4000-8000-000000000001'::uuid
  returning bon_seq into next_val;

  return 'G-' || lpad(next_val::text, 4, '0');
end;
$$;

create or replace function public.next_repair_number()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  next_val bigint;
begin
  if not public.is_active_shop_member() then
    raise exception 'Unauthorized';
  end if;

  update public.store
  set repair_seq = repair_seq + 1,
      updated_at = now()
  where id = '00000000-0000-4000-8000-000000000001'::uuid
  returning repair_seq into next_val;

  return 'R-' || lpad(next_val::text, 4, '0');
end;
$$;

create or replace function public.next_purchase_order_number()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  next_val bigint;
begin
  if not public.is_active_shop_member() then
    raise exception 'Unauthorized';
  end if;

  update public.store
  set po_seq = po_seq + 1,
      updated_at = now()
  where id = '00000000-0000-4000-8000-000000000001'::uuid
  returning po_seq into next_val;

  return 'BA-' || lpad(next_val::text, 4, '0');
end;
$$;

create or replace function public.next_trade_in_number()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  next_val bigint;
begin
  if not public.is_active_shop_member() then
    raise exception 'Unauthorized';
  end if;

  update public.store
  set trade_in_seq = trade_in_seq + 1,
      updated_at = now()
  where id = '00000000-0000-4000-8000-000000000001'::uuid
  returning trade_in_seq into next_val;

  return 'REP-' || lpad(next_val::text, 4, '0');
end;
$$;

-- 4. ENTITY TABLES (Each row has: id uuid, updated_at timestamptz, deleted_at timestamptz, device_id text, payload jsonb)
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  name text not null,
  category text not null,
  barcode text,
  quantity integer not null default 0,
  min_alert_qty integer not null default 5,
  purchase_price numeric(12,2) not null default 0,
  retail_price numeric(12,2) not null default 0,
  wholesale_price numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  name text not null,
  phone text,
  cin text,
  total_credit numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  bon_number text not null,
  customer_uuid uuid,
  customer_name text,
  date text not null,
  total_amount numeric(12,2) not null default 0,
  paid_amount numeric(12,2) not null default 0,
  remaining_amount numeric(12,2) not null default 0,
  status text not null default 'active',
  sale_kind text not null default 'product',
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid references public.sales(id) on delete cascade,
  product_uuid uuid,
  name text not null,
  imei text,
  quantity integer not null default 1,
  price numeric(12,2) not null default 0,
  cost_price numeric(12,2) not null default 0,
  is_returned boolean not null default false,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.warranties (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  bon_number text not null,
  imei text,
  status text not null default 'active',
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.sav_tickets (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  bon_number text,
  imei text,
  status text not null default 'open',
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.repairs (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  repair_number text not null,
  customer_name text not null,
  customer_phone text,
  status text not null default 'pending',
  agreed_price numeric(12,2) not null default 0,
  deposit_amount numeric(12,2) not null default 0,
  remaining_amount numeric(12,2) not null default 0,
  total_parts_cost numeric(12,2) not null default 0,
  net_profit numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.spare_parts (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  name text not null,
  quantity integer not null default 0,
  purchase_price numeric(12,2) not null default 0,
  selling_price numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  name text not null,
  phone text,
  total_debt numeric(12,2) not null default 0,
  paid_amount numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.supplier_payments (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  supplier_uuid uuid,
  amount numeric(12,2) not null default 0,
  date text not null,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.supplier_purchase_orders (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  bon_number text not null,
  supplier_uuid uuid,
  total_amount numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.customer_payments (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  customer_uuid uuid,
  sale_uuid uuid,
  amount numeric(12,2) not null default 0,
  date text not null,
  status text not null default 'active',
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.credit_audit_logs (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  customer_uuid uuid,
  action text not null,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  category text not null,
  amount numeric(12,2) not null default 0,
  date text not null,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.recurring_expenses (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  title text not null,
  amount numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  product_uuid uuid,
  type text not null,
  quantity_delta integer not null,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.cash_closures (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  date text not null,
  counted_cash numeric(12,2) not null default 0,
  discrepancy numeric(12,2) not null default 0,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  local_id bigint,
  action text not null,
  entity_type text not null,
  payload jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.settings (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  value jsonb not null default '{}'::jsonb,
  device_id text,
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

-- ============================================================================
-- 5. ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

alter table public.store enable row level security;
alter table public.users_profile enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.warranties enable row level security;
alter table public.sav_tickets enable row level security;
alter table public.repairs enable row level security;
alter table public.spare_parts enable row level security;
alter table public.suppliers enable row level security;
alter table public.supplier_payments enable row level security;
alter table public.supplier_purchase_orders enable row level security;
alter table public.customer_payments enable row level security;
alter table public.credit_audit_logs enable row level security;
alter table public.expenses enable row level security;
alter table public.recurring_expenses enable row level security;
alter table public.stock_movements enable row level security;
alter table public.cash_closures enable row level security;
alter table public.activity_logs enable row level security;
alter table public.settings enable row level security;

-- Store & Users Profile Policies
create policy "Active shop members can read store" on public.store
  for select using (public.is_active_shop_member());

create policy "Owner can update store" on public.store
  for all using (public.is_shop_owner());

create policy "Users can read own profile or owner reads all" on public.users_profile
  for select using (auth.uid() = id or public.is_shop_owner());

create policy "Owner manages user profiles" on public.users_profile
  for all using (public.is_shop_owner());

-- Operational tables accessible by both Owner and active Employee
create policy "Shop members access products" on public.products
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access customers" on public.customers
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access sales" on public.sales
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access sale_items" on public.sale_items
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access warranties" on public.warranties
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access sav_tickets" on public.sav_tickets
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access repairs" on public.repairs
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access spare_parts" on public.spare_parts
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access customer_payments" on public.customer_payments
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access credit_audit_logs" on public.credit_audit_logs
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members access stock_movements" on public.stock_movements
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

create policy "Shop members insert activity_logs" on public.activity_logs
  for insert with check (public.is_active_shop_member());

create policy "Owner reads activity_logs" on public.activity_logs
  for select using (public.is_shop_owner());

-- Owner-only tables (Settings with PIN/Security, Expenses, Suppliers, Cash Closures)
-- Employee is strictly denied access to settings containing owner PIN!
create policy "Owner only access settings" on public.settings
  for all using (
    public.is_shop_owner() or (public.is_active_shop_member() and key <> 'access_security_state')
  )
  with check (public.is_shop_owner());

create policy "Owner only access expenses" on public.expenses
  for all using (public.is_shop_owner()) with check (public.is_shop_owner());

create policy "Owner only access recurring_expenses" on public.recurring_expenses
  for all using (public.is_shop_owner()) with check (public.is_shop_owner());

create policy "Owner only access suppliers" on public.suppliers
  for all using (public.is_shop_owner()) with check (public.is_shop_owner());

create policy "Owner only access supplier_payments" on public.supplier_payments
  for all using (public.is_shop_owner()) with check (public.is_shop_owner());

create policy "Owner only access supplier_purchase_orders" on public.supplier_purchase_orders
  for all using (public.is_shop_owner()) with check (public.is_shop_owner());

create policy "Shop members access cash_closures" on public.cash_closures
  for all using (public.is_active_shop_member()) with check (public.is_active_shop_member());

-- ============================================================================
-- 6. AUTOMATIC UPDATED_AT TRIGGERS ON ALL TABLES
-- ============================================================================

create or replace function public.handle_updated_at()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare
  tbl text;
begin
  foreach tbl in array array[
    'store',
    'users_profile',
    'products',
    'customers',
    'sales',
    'sale_items',
    'warranties',
    'sav_tickets',
    'repairs',
    'spare_parts',
    'suppliers',
    'supplier_payments',
    'supplier_purchase_orders',
    'customer_payments',
    'credit_audit_logs',
    'expenses',
    'recurring_expenses',
    'stock_movements',
    'cash_closures',
    'activity_logs',
    'settings'
  ]
  loop
    execute format('drop trigger if exists trg_%I_updated_at on public.%I;', tbl, tbl);
    execute format(
      'create trigger trg_%I_updated_at before update on public.%I for each row execute function public.handle_updated_at();',
      tbl,
      tbl
    );
  end loop;
end;
$$;

-- ============================================================================
-- 7. AUTH.USERS TRIGGER (First user = active owner; subsequent = inactive employee unless created via Edge Function)
-- ============================================================================

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_count integer;
  assigned_role text;
  assigned_active boolean;
  meta_full_name text;
  by_owner boolean;
begin
  select count(*) into existing_count from public.users_profile;
  meta_full_name := coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1));
  by_owner := coalesce((new.raw_user_meta_data->>'created_by_owner')::boolean, false);

  if existing_count = 0 then
    assigned_role := 'owner';
    assigned_active := true;
  else
    assigned_role := 'employee';
    assigned_active := by_owner;
  end if;

  insert into public.users_profile (id, email, full_name, role, active, created_at, updated_at)
  values (new.id, coalesce(new.email, ''), meta_full_name, assigned_role, assigned_active, now(), now())
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();

