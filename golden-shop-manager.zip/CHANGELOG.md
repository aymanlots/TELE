# Changelog — Golden Shop Manager

## [2.1.0] - 2026-10-20
### Sécurité & Gardes Base de Données (`src/db/index.ts`)
- **Gardes `createSaleTransaction`** : Validation stricte côté base de données (quantité > 0, prix >= 0, montant payé entre 0 et total net, stock suffisant, et client obligatoire si reste à payer > 0).
- **Gardes `deliverRepairOrder`** : Protection anti double-livraison (`repair.status === 'delivered'`), validation du solde restant, et comptabilisation unique du bénéfice net (`agreedPrice - totalPartsCost`).
- **Numérotation atomique dans la transaction Dexie** : `getNextBonNumber`, `getNextRepairNumber` et `getNextPurchaseOrderNumber` s'exécutent à l'intérieur de la transaction Dexie de création afin d'éviter tout trou ou doublon.
- **Suppression de bon (`deleteSaleTransaction`)** : Réservée au propriétaire (`can('delete_records')`), avec remise en stock des articles non retournés et ajustement du crédit client.

### Fuseau Horaire Maroc (`src/lib/dateUtils.ts`)
- **Normalisation `Africa/Casablanca`** : Utilisation de `todayMA()`, `monthMA()` et `nowMA()` pour toutes les dates métier (ventes, dépenses, versements, clôtures, échéances, garanties, rapports, sauvegardes et audits de crédit). `toISOString()` est conservé uniquement pour les horodatages techniques (`created_at` / `updated_at` / `deleted_at`).

### Permissions & Rôles (`src/lib/permissions.ts`, `src/lib/accessAuth.tsx`)
- **Source unique des permissions** : `src/lib/permissions.ts` centralise `hasPermission`, `isOwnerRole` et `canAccessTab`. En mode local sans Supabase, le rôle actif est `owner`.
- **Protection des routes (`src/App.tsx`)** : Redirection automatique vers la Caisse (`pos`) si l'employé tente d'accéder au Dashboard financier, Rapports, Dépenses, Fournisseurs, Journal d'activité ou Paramètres.
- **Masquage employé (58 points de contrôle)** : Masquage des prix d'achat, coûts des pièces, marges/bénéfices, suppressions d'articles/bons/réparations, annulations de paiements, sauvegardes et gestion des utilisateurs.

### Synchronisation Cloud Supabase (`supabase/schema.sql`, `src/lib/supabaseSync.ts`)
- **Edge Function `supabase/functions/create-employee/index.ts`** : Création sécurisée du compte employé côté serveur avec `SUPABASE_SERVICE_ROLE_KEY` après vérification du profil `owner` actif de l'appelant.
- **Triggers SQL** : Trigger automatique `updated_at` sur les 21 tables et trigger `on_auth_user_created` sur `auth.users` (premier compte = `owner` actif, suivants = `employee`).
- **RPC Atomiques** : `next_bon_number`, `next_repair_number`, `next_purchase_order_number`, `next_trade_in_number` et `get_server_time` avec `SECURITY DEFINER` et `set search_path = public`.
- **Fusion Stock par Mouvements** : Calcul de la quantité produit lors de la synchronisation à partir des mouvements de stock (`previousQty + sum(quantityDelta)`).

### Performance & PWA
- **Lazy Loading** : Chargement dynamique des pages (`React.lazy` + `Suspense`) et import dynamique de `jspdf` / `jspdf-autotable` uniquement lors de la génération d'un PDF.
- **Icônes PWA** : Génération des icônes PNG `public/pwa-192x192.png` et `public/pwa-512x512.png` (monogramme Or/Noir "GS").
