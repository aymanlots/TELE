# Guide des Tests — Golden Shop Manager

## Scénarios de Test Manuels

1. **Vente à crédit sans client** :
   - Tenter de valider une vente au POS avec un montant restant > 0 sans sélectionner de client.
   - Résultat attendu : Refus avec message d'erreur clair en FR et AR.

2. **Retour d'article** :
   - Effectuer une vente avec remise et articles multiples, puis retourner un article.
   - Résultat attendu : Recalcul automatique du total net, prorata de la remise, et exclusion des articles retournés du chiffre d'affaires et du bénéfice.

3. **Paiement client en mode FIFO** :
   - Enregistrer un versement supérieur au total dû ou avec un surplus.
   - Résultat attendu : Demande de confirmation explicite ou refus du surplus si non affecté.

4. **Réparation et Acompte** :
   - Créer une réparation avec acompte, puis livrer la réparation.
   - Résultat attendu : L'acompte est enregistré à sa date, le solde à la livraison, et le bénéfice net est compté une seule fois sans double comptabilisation.

5. **Sécurité PIN et Rôles** :
   - Configurer un PIN à 6 chiffres. Tenter 5 mauvais codes pour vérifier le verrouillage temporaire.
   - Se connecter en tant qu'employé pour vérifier que les prix d'achat, bénéfices, rapports et paramètres sont masqués ou inaccessibles.

6. **Synchronisation Hors-Ligne** :
   - Effectuer des ventes et modifications en mode hors-ligne, vérifier la génération des numéros G-L-xxxx, puis reconnecter Internet pour observer la resynchronisation automatique avec Supabase.
