import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  Wrench,
  Plus,
  Search,
  Printer,
  CheckCircle2,
  Clock,
  PackageCheck,
  AlertCircle,
  Eye,
  EyeOff,
  Phone,
  Smartphone,
  Check,
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  FileText,
  DollarSign,
  Calendar,
  MessageCircle,
  Cpu,
  Trash2,
  X,
} from 'lucide-react';
import {
  db,
  createRepairOrder,
  updateRepairStatus,
  deliverRepairOrder,
  getStoreSettings,
  addPartToRepair,
  removePartFromRepair,
  cancelOrDeleteRepairOrder,
} from '../db';
import { RepairOrder, RepairStatus, SparePart, UsedSparePart } from '../types';
import { useI18n } from '../i18n';
import { useViewMode } from '../lib/viewMode';
import { useAccessAuth } from '../lib/accessAuth';
import { useToast } from '../components/Toast';
import { formatMAD } from '../lib/currency';
import { Modal } from '../components/Modal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { getMoroccoDateString } from '../lib/dateUtils';
import { decryptSensitiveData } from '../lib/cryptoUtils';
import {
  openWhatsAppChat,
  renderWhatsAppMessage,
  DEFAULT_WHATSAPP_TEMPLATES_AR,
  DEFAULT_WHATSAPP_TEMPLATES_FR,
} from '../lib/whatsapp';
import { ScanButton } from '../components/ScanButton';
import { ReceiptPrintModal } from '../components/ReceiptPrintModal';

interface RepairsPageProps {
  initialSearch?: string;
}

export const RepairsPage: React.FC<RepairsPageProps> = ({ initialSearch }) => {
  const { t, language } = useI18n();
  const { isMobileMode } = useViewMode();
  const { can } = useAccessAuth();
  const { success, error } = useToast();

  const [search, setSearch] = useState(initialSearch || '');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [visibleCount, setVisibleCount] = useState(20);

  // Intake Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [imei, setImei] = useState('');
  const [issue, setIssue] = useState('');
  const [conditionNotes, setConditionNotes] = useState('');
  const [lockCode, setLockCode] = useState('');
  const [showLockCode, setShowLockCode] = useState(false);
  const [agreedPrice, setAgreedPrice] = useState<number>(0);
  const [depositAmount, setDepositAmount] = useState<number>(0);
  const [intakeDate, setIntakeDate] = useState<string>(getMoroccoDateString());
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return getMoroccoDateString(d);
  });
  const [technicianNotes, setTechnicianNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Deliver Confirmation Modal
  const [deliveringRepair, setDeliveringRepair] = useState<RepairOrder | null>(null);
  const [collectedAmount, setCollectedAmount] = useState<number>(0);
  const [receiptPrintRepair, setReceiptPrintRepair] = useState<{
    repair: RepairOrder;
    type: 'deposit' | 'delivery';
  } | null>(null);

  // Live Query from Dexie (decrypts AES-GCM lockCode transparently in memory - Partie 1 #9)
  const repairs =
    useLiveQuery(async () => {
      const raw = await db.repairs.orderBy('id').reverse().toArray();
      const active = raw.filter((r) => !r.deleted_at);
      const decrypted: RepairOrder[] = [];
      for (const r of active) {
        if (r.lockCode) {
          const plain = await decryptSensitiveData(r.lockCode);
          decrypted.push({ ...r, lockCode: plain });
        } else {
          decrypted.push(r);
        }
      }
      return decrypted;
    }, []) || [];
  const allSpareParts =
    useLiveQuery(async () => {
      const all = await db.spareParts.toArray();
      return all.filter((p) => !p.deleted_at);
    }, []) || [];

  // Spare Parts Integration State
  const [partModalRepair, setPartModalRepair] = useState<RepairOrder | null>(null);
  const [selectedPartId, setSelectedPartId] = useState<number | null>(null);
  const [partQuantity, setPartQuantity] = useState<number>(1);
  const [partSearch, setPartSearch] = useState<string>('');
  const [removingPartInfo, setRemovingPartInfo] = useState<{
    repairId: number;
    partIndex: number;
    partName: string;
  } | null>(null);
  const [deletingRepair, setDeletingRepair] = useState<RepairOrder | null>(null);

  // Filtered Repairs
  const filteredRepairs = repairs.filter((r) => {
    const matchesFilter = statusFilter === 'all' || r.status === statusFilter;
    if (!matchesFilter) return false;

    if (!search.trim()) return true;
    const q = search.toLowerCase().trim();
    return (
      r.repairNumber.toLowerCase().includes(q) ||
      r.customerName.toLowerCase().includes(q) ||
      r.customerPhone.includes(q) ||
      r.brand.toLowerCase().includes(q) ||
      r.model.toLowerCase().includes(q) ||
      (r.imei && r.imei.toLowerCase().includes(q))
    );
  });

  const paginatedRepairs = filteredRepairs.slice(0, visibleCount);

  // Calculate automatically remaining amount in intake form
  const remainingCalculated = Math.max(0, agreedPrice - depositAmount);

  // Open Intake Modal
  const handleOpenAdd = () => {
    setCustomerName('');
    setCustomerPhone('');
    setBrand('');
    setModel('');
    setImei('');
    setIssue('');
    setConditionNotes('');
    setLockCode('');
    setShowLockCode(false);
    setAgreedPrice(0);
    setDepositAmount(0);
    setIntakeDate(getMoroccoDateString());
    const d = new Date();
    d.setDate(d.getDate() + 2);
    setExpectedDeliveryDate(getMoroccoDateString(d));
    setTechnicianNotes('');
    setIsAddOpen(true);
  };

  // Submit Intake Form
  const handleSubmitIntake = async (andPrint: boolean) => {
    if (!customerName.trim() || !customerPhone.trim() || !brand.trim() || !model.trim() || !issue.trim()) {
      error(
        language === 'ar'
          ? 'يرجى ملء معلومات الزبون، الماركة، الموديل، ووصف العطب.'
          : 'Veuillez renseigner le nom, téléphone, marque, modèle et la panne.'
      );
      return;
    }

    if (agreedPrice <= 0) {
      error(
        language === 'ar'
          ? 'يرجى إدخال الثمن المتفق عليه للإصلاح.'
          : 'Veuillez saisir le prix convenu pour la réparation.'
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const newOrder = await createRepairOrder({
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        brand: brand.trim(),
        model: model.trim(),
        imei: imei.trim() || undefined,
        issue: issue.trim(),
        conditionNotes: conditionNotes.trim() || undefined,
        lockCode: lockCode.trim() || undefined,
        agreedPrice: Number(agreedPrice) || 0,
        depositAmount: Number(depositAmount) || 0,
        remainingAmount: Math.max(0, (Number(agreedPrice) || 0) - (Number(depositAmount) || 0)),
        intakeDate,
        expectedDeliveryDate: expectedDeliveryDate || undefined,
        status: 'pending',
        technicianNotes: technicianNotes.trim() || undefined,
      });

      success(
        language === 'ar'
          ? `تم تسجيل الجهاز برقم ${newOrder.repairNumber} بنجاح.`
          : `Appareil enregistré avec succès sous le dossier ${newOrder.repairNumber}.`
      );

      setIsAddOpen(false);

      if (andPrint) {
        const settings = await getStoreSettings();
        const { generateRepairDepositPDF } = await import('../lib/pdfGenerator');
        await generateRepairDepositPDF(newOrder, settings, 'print');
      }
    } catch {
      error(
        language === 'ar'
          ? 'حدث خطأ أثناء تسجيل طلب الإصلاح.'
          : "Erreur lors de l'enregistrement de la réparation."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // One-Click Stage Progression
  const handleQuickNextStatus = async (repair: RepairOrder) => {
    const sequence: RepairStatus[] = ['pending', 'in_progress', 'waiting_parts', 'ready', 'delivered'];
    const currentIdx = sequence.indexOf(repair.status);

    if (currentIdx === -1 || currentIdx >= sequence.length - 1) return;

    const next = sequence[currentIdx + 1];

    if (next === 'delivered') {
      // Open delivery modal to collect remaining balance and record revenue
      setDeliveringRepair(repair);
      setCollectedAmount(repair.remainingAmount);
    } else {
      await updateRepairStatus(repair.id!, next);
      success(t.repairs.statusChanged);
    }
  };

  // Direct status select
  const handleSelectStatus = async (repair: RepairOrder, status: RepairStatus) => {
    if (status === 'delivered') {
      setDeliveringRepair(repair);
      setCollectedAmount(repair.remainingAmount);
    } else {
      await updateRepairStatus(repair.id!, status);
      success(t.repairs.statusChanged);
    }
  };

  // Confirm Delivery and Record Final Revenue
  const handleConfirmDeliver = async () => {
    if (!deliveringRepair || !deliveringRepair.id) return;

    try {
      await deliverRepairOrder(deliveringRepair.id, Number(collectedAmount));
      success(t.repairs.deliveredSuccess);

      // Offer printing delivery receipt
      const settings = await getStoreSettings();
      const { generateRepairDeliveryPDF } = await import('../lib/pdfGenerator');
      await generateRepairDeliveryPDF(
        { ...deliveringRepair, status: 'delivered', remainingAmount: 0 },
        settings,
        'save'
      );

      setDeliveringRepair(null);
    } catch {
      error(
        language === 'ar'
          ? 'حدث خطأ أثناء تأكيد تسليم الجهاز.'
          : "Erreur lors de la livraison de l'appareil."
      );
    }
  };

  // Print Deposit Receipt (Opens Thermal 58mm/80mm/A4 Preview + PDF option)
  const handlePrintDeposit = async (repair: RepairOrder) => {
    setReceiptPrintRepair({ repair, type: 'deposit' });
  };

  // Print Delivery Receipt (Opens Thermal 58mm/80mm/A4 Preview + PDF option)
  const handlePrintDelivery = async (repair: RepairOrder) => {
    setReceiptPrintRepair({ repair, type: 'delivery' });
  };

  // Send WhatsApp Direct Notification
  const handleSendWhatsApp = async (repair: RepairOrder) => {
    if (!repair.customerPhone || !repair.customerPhone.trim()) {
      error(t.whatsapp.noPhoneAlert);
      return;
    }

    try {
      const settings = await getStoreSettings();
      const templates = settings.whatsappTemplates || {};
      const defaultTemplates =
        language === 'ar' ? DEFAULT_WHATSAPP_TEMPLATES_AR : DEFAULT_WHATSAPP_TEMPLATES_FR;

      const template =
        templates.repairReady || defaultTemplates.repairReady;

      const fallbackStoreName = language === 'ar' ? 'متجري' : 'Mon Magasin';
      const storeName = settings.storeName?.trim() || fallbackStoreName;

      const text = renderWhatsAppMessage(template, {
        clientName: repair.customerName,
        model: `${repair.brand} ${repair.model}`,
        remaining: repair.remainingAmount,
        total: repair.agreedPrice,
        storeName,
        repairNumber: repair.repairNumber,
      });

      const opened = openWhatsAppChat(repair.customerPhone, text);
      if (opened) {
        success(language === 'ar' ? 'تم فتح تطبيق واتساب بنجاح.' : 'Discussion WhatsApp ouverte avec succès.');
      } else {
        error(language === 'ar' ? 'رقم الهاتف غير صالح للمراسلة عبر واتساب.' : 'Numéro de téléphone non valide pour WhatsApp.');
      }
    } catch {
      error(language === 'ar' ? 'حدث خطأ أثناء فتح واتساب.' : "Erreur lors de l'ouverture de WhatsApp.");
    }
  };

  // Open Add Spare Part Modal for this repair
  const handleOpenAddPart = (repair: RepairOrder) => {
    setPartModalRepair(repair);
    setSelectedPartId(null);
    setPartQuantity(1);
    setPartSearch('');
  };

  // Confirm Add Part to Repair
  const handleConfirmAddPart = async () => {
    if (!partModalRepair || !partModalRepair.id || !selectedPartId) {
      error(
        language === 'ar'
          ? 'يرجى اختيار القطعة المراد استخدامها.'
          : 'Veuillez sélectionner la pièce à utiliser.'
      );
      return;
    }

    try {
      await addPartToRepair(partModalRepair.id, selectedPartId, Math.max(1, partQuantity));
      success(t.spareParts.partAddedSuccess);
      setPartModalRepair(null);
    } catch (err: any) {
      error(err?.message || (language === 'ar' ? 'حدث خطأ أثناء إضافة القطعة.' : "Erreur lors de l'ajout de la pièce."));
    }
  };

  // Confirm Remove Part from Repair (Restores stock)
  const handleConfirmRemovePart = async () => {
    if (!removingPartInfo) return;
    try {
      await removePartFromRepair(removingPartInfo.repairId, removingPartInfo.partIndex);
      success(t.spareParts.partRemovedSuccess);
      setRemovingPartInfo(null);
    } catch (err: any) {
      error(err?.message || (language === 'ar' ? 'حدث خطأ أثناء إزالة القطعة.' : "Erreur lors du retrait de la pièce."));
    }
  };

  // Confirm Cancel & Delete Repair (Restores all used parts to stock)
  const handleConfirmDeleteRepair = async () => {
    if (!deletingRepair?.id) return;
    try {
      await cancelOrDeleteRepairOrder(deletingRepair.id);
      success(
        language === 'ar'
          ? 'تم إلغاء الإصلاح واسترجاع قطع الغيار المستخدمة إلى المخزون بنجاح.'
          : 'Dossier de réparation annulé et pièces réintégrées au stock avec succès.'
      );
      setDeletingRepair(null);
    } catch (err: any) {
      error(
        err?.message ||
          (language === 'ar'
            ? 'حدث خطأ أثناء إلغاء الإصلاح.'
            : "Erreur lors de l'annulation de la réparation.")
      );
    }
  };

  // Helpers for Status Badges
  const getStatusBadge = (status: RepairStatus) => {
    switch (status) {
      case 'pending':
        return {
          label: t.repairs.pending,
          color: 'bg-neutral-800 text-neutral-300 border-neutral-700',
          dot: 'bg-neutral-400',
        };
      case 'in_progress':
        return {
          label: t.repairs.in_progress,
          color: 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-xs shadow-amber-500/10',
          dot: 'bg-amber-400',
        };
      case 'waiting_parts':
        return {
          label: t.repairs.waiting_parts,
          color: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
          dot: 'bg-purple-400',
        };
      case 'ready':
        return {
          label: t.repairs.ready,
          color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs shadow-emerald-500/10',
          dot: 'bg-emerald-400',
        };
      case 'delivered':
        return {
          label: t.repairs.delivered,
          color: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
          dot: 'bg-blue-400',
        };
    }
  };

  // Counts
  const openRepairsCount = repairs.filter((r) => r.status !== 'delivered').length;
  const readyRepairsCount = repairs.filter((r) => r.status === 'ready').length;

  return (
    <div className="space-y-6">
      {/* Top Banner & Intake CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-neutral-900 border border-amber-500/20 shadow-xl shadow-black/80">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400 shadow-inner">
              <Wrench className="w-5 h-5 drop-shadow-[0_0_6px_rgba(212,175,55,0.4)]" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-gold-gradient tracking-tight">
                {t.repairs.title}
              </h1>
              <p className="text-xs text-neutral-300 mt-0.5 font-medium">
                {t.repairs.subtitle}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleOpenAdd}
            className={`flex items-center justify-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold transition shadow-md active:scale-95 ${
              isMobileMode ? 'w-full py-3.5 px-4 text-sm min-h-[48px]' : 'px-4 py-2.5 text-xs'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{t.repairs.newRepair}</span>
          </button>
        </div>
      </div>

      {/* KPI Counters Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-neutral-400 font-semibold">{t.repairs.openRepairsCount}</span>
            <div className="text-2xl font-black font-mono text-amber-400 mt-1 tabular-nums">
              {openRepairsCount}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-neutral-400 font-semibold">{t.repairs.readyRepairsCount}</span>
            <div className="text-2xl font-black font-mono text-emerald-400 mt-1 tabular-nums">
              {readyRepairsCount}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <PackageCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="col-span-2 sm:col-span-1 p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between shadow-lg">
          <div>
            <span className="text-xs text-neutral-400 font-semibold">{t.repairs.deliveredCount}</span>
            <div className="text-2xl font-black font-mono text-neutral-100 mt-1 tabular-nums">
              {repairs.filter((r) => r.status === 'delivered').length}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-neutral-800 text-neutral-400 border border-neutral-700">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Search & Stage Filter Tabs */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-neutral-900 border border-neutral-800">
        <div className="flex items-center gap-2 w-full md:w-96">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.repairs.searchPlaceholder}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg ps-9 pe-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-hidden focus:border-amber-500/50"
            />
          </div>
          <ScanButton
            onScan={(code) => setSearch(code.trim())}
            mode="any"
            size="md"
          />
        </div>

        {/* Stage Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto py-1">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              statusFilter === 'all'
                ? 'bg-amber-500 text-neutral-950 font-bold shadow-md shadow-amber-500/20'
                : 'bg-neutral-800 text-neutral-300 hover:text-white'
            }`}
          >
            {t.repairs.all} ({repairs.length})
          </button>
          {(['pending', 'in_progress', 'waiting_parts', 'ready', 'delivered'] as RepairStatus[]).map((st) => {
            const count = repairs.filter((r) => r.status === st).length;
            const badge = getStatusBadge(st);
            return (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 ${
                  statusFilter === st
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-md shadow-amber-500/20'
                    : 'bg-neutral-800 text-neutral-300 hover:text-white'
                }`}
              >
                <span>{badge.label}</span>
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-black/25">
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Repairs List: Mobile Mode (Vertical Cards) vs Desktop Mode (Wide Table) */}
      {filteredRepairs.length === 0 ? (
        <div className="py-16 text-center text-xs text-neutral-400 bg-neutral-900/40 rounded-2xl border border-neutral-800 flex flex-col items-center justify-center gap-3">
          <Wrench className="w-10 h-10 text-neutral-600" />
          <p className="text-sm font-medium text-neutral-300">
            {search ? t.repairs.noRepairsSearch : t.repairs.noRepairs}
          </p>
          {!search && (
            <button
              onClick={handleOpenAdd}
              className="mt-1 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-lg text-xs transition flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>{t.repairs.newRepair}</span>
            </button>
          )}
        </div>
      ) : isMobileMode ? (
        /* Mobile Mode: Large Touch-Friendly Vertical Cards */
        <div className="space-y-4">
          {paginatedRepairs.map((repair) => {
            const badge = getStatusBadge(repair.status);
            return (
              <div
                key={repair.id}
                className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4 shadow-xl shadow-black/80"
              >
                {/* Header row: Reference & Status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg font-mono font-black text-xs text-amber-400 bg-amber-500/10 border border-amber-500/30">
                      {repair.repairNumber}
                    </span>
                    <span className="text-[11px] text-neutral-400 font-mono">
                      {repair.intakeDate}
                    </span>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${badge.color}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                    <span>{badge.label}</span>
                  </span>
                </div>

                {/* Device & Client info */}
                <div className="space-y-1">
                  <h3 className="text-base font-black text-neutral-100 flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>{repair.brand} {repair.model}</span>
                  </h3>
                  <div className="flex items-center justify-between text-xs text-neutral-300 pt-1">
                    <span className="font-semibold">{repair.customerName}</span>
                    <a
                      href={`tel:${repair.customerPhone}`}
                      className="flex items-center gap-1 text-amber-400 font-mono font-bold"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>{repair.customerPhone}</span>
                    </a>
                  </div>
                </div>

                {/* Issue & Condition box */}
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 space-y-1.5 text-xs">
                  <div className="text-neutral-200">
                    <strong className="text-amber-400/90">{language === 'ar' ? 'العطب :' : 'Panne :'} </strong>
                    <span>{repair.issue}</span>
                  </div>
                  {repair.conditionNotes && (
                    <div className="text-neutral-400 text-[11px]">
                      <strong>{language === 'ar' ? 'الحالة :' : 'État :'} </strong>
                      <span>{repair.conditionNotes}</span>
                    </div>
                  )}
                  {repair.lockCode && (
                    <div className="text-neutral-400 text-[11px] font-mono flex items-center gap-1.5">
                      <strong>{language === 'ar' ? 'كود القفل :' : 'Code PIN/Schéma :'} </strong>
                      <span className="text-amber-300 font-bold px-1.5 py-0.5 rounded bg-neutral-900 border border-neutral-800">
                        {repair.lockCode}
                      </span>
                    </div>
                  )}
                </div>

                {/* Used Spare Parts Section & Net Profit */}
                <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t.spareParts.usedParts}</span>
                      {repair.usedParts && repair.usedParts.length > 0 && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold">
                          {repair.usedParts.length}
                        </span>
                      )}
                    </span>
                    {repair.status !== 'delivered' && (
                      <button
                        type="button"
                        onClick={() => handleOpenAddPart(repair)}
                        className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 text-xs font-bold flex items-center gap-1 transition active:scale-95 border border-neutral-700"
                      >
                        <Plus className="w-3 h-3" />
                        <span>{t.spareParts.quickAddUsed}</span>
                      </button>
                    )}
                  </div>

                  {repair.usedParts && repair.usedParts.length > 0 ? (
                    <div className="space-y-1.5 pt-1">
                      {repair.usedParts.map((part, pIdx) => (
                        <div
                          key={pIdx}
                          className="flex items-center justify-between py-1.5 px-2 rounded-lg bg-neutral-900 border border-neutral-800/80 text-xs"
                        >
                          <div>
                            <span className="font-semibold text-neutral-200">
                              {part.name}
                            </span>
                            <span className="text-[10px] text-neutral-400 ms-1.5">
                              ({part.brand} {part.model})
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {can('view_cost_price') && (
                              <span className="font-mono text-neutral-300 text-[11px]">
                                {formatMAD(part.purchasePrice * part.quantity, language)}
                              </span>
                            )}
                            {repair.status !== 'delivered' && (
                              <button
                                type="button"
                                onClick={() =>
                                  setRemovingPartInfo({
                                    repairId: repair.id!,
                                    partIndex: pIdx,
                                    partName: part.name,
                                  })
                                }
                                className="p-1 rounded text-neutral-500 hover:text-rose-400 transition"
                                title="Retirer la pièce et réintégrer au stock"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      ))}

                      {/* Real Net Profit Breakdown */}
                      {can('view_profits') && (
                        <div className="flex items-center justify-between pt-1.5 border-t border-neutral-800/80 text-xs">
                          <span className="text-neutral-400">
                            {t.spareParts.partsCost}:{' '}
                            <span className="font-mono font-bold text-neutral-200">
                              {formatMAD(repair.totalPartsCost || 0, language)}
                            </span>
                          </span>
                          <span className="font-bold text-emerald-400 flex items-center gap-1">
                            <span>{t.spareParts.realProfit}:</span>
                            <span className="font-mono text-xs font-black px-1.5 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30">
                              {formatMAD(
                                repair.netProfit !== undefined
                                  ? repair.netProfit
                                  : Math.max(0, repair.agreedPrice - (repair.totalPartsCost || 0)),
                                language
                              )}
                            </span>
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-[11px] text-neutral-500 italic py-0.5">
                      {language === 'ar'
                        ? 'لم يتم تسجيل أي قطع غيار مستعملة لهذا الإصلاح.'
                        : 'Aucune pièce détachée associée à cette réparation.'}
                    </div>
                  )}
                </div>

                {/* Financial Summary */}
                <div className="grid grid-cols-3 gap-2 py-2 px-3 bg-neutral-950 rounded-xl text-center text-xs">
                  <div>
                    <span className="text-[10px] text-neutral-400 block">{t.total}</span>
                    <span className="font-mono font-bold text-neutral-100">
                      {formatMAD(repair.agreedPrice, language)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block">{t.repairs.deposit}</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {formatMAD(repair.depositAmount, language)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block">{t.repairs.remaining}</span>
                    <span className={`font-mono font-bold ${repair.remainingAmount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {formatMAD(repair.remainingAmount, language)}
                    </span>
                  </div>
                </div>

                {/* WhatsApp Notification Button */}
                <button
                  type="button"
                  onClick={() => handleSendWhatsApp(repair)}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-emerald-950 min-h-[44px]"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>
                    {repair.status === 'ready'
                      ? (language === 'ar' ? 'واتساب: إشعار الهاتف جاهز للتسليم' : 'WhatsApp : Notifier appareil prêt')
                      : (language === 'ar' ? 'مراسلة الزبون عبر واتساب' : 'Contacter sur WhatsApp')}
                  </span>
                </button>

                {/* Actions Bar */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {repair.status !== 'delivered' ? (
                    <button
                      type="button"
                      onClick={() => handleQuickNextStatus(repair)}
                      className="col-span-2 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md min-h-[46px]"
                    >
                      <Check className="w-4 h-4" />
                      <span>
                        {repair.status === 'ready'
                          ? t.repairs.deliverDevice
                          : `${t.repairs.nextStatus} (${getStatusBadge(
                              repair.status === 'pending'
                                ? 'in_progress'
                                : repair.status === 'in_progress'
                                ? 'waiting_parts'
                                : 'ready'
                            ).label})`}
                      </span>
                    </button>
                  ) : (
                    <div className="col-span-2 py-2.5 px-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-center font-bold text-xs">
                      {t.repairs.delivered} ({repair.actualDeliveryDate || repair.intakeDate})
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => handlePrintDeposit(repair)}
                    className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 min-h-[44px]"
                  >
                    <Printer className="w-3.5 h-3.5 text-amber-400" />
                    <span>{t.repairs.printDepositReceipt}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePrintDelivery(repair)}
                    className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 min-h-[44px]"
                  >
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{t.repairs.printDeliveryReceipt}</span>
                  </button>

                  {can('delete_records') && (
                    <button
                      type="button"
                      onClick={() => setDeletingRepair(repair)}
                      className="col-span-2 py-2 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/25 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
                      title={language === 'ar' ? 'إلغاء وحذف الإصلاح' : 'Annuler et supprimer la réparation'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'إلغاء الإصلاح واسترجاع القطع' : 'Annuler la réparation (Restituer les pièces)'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Desktop Mode: Wide High-Density Table */
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] tracking-wider border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-4 text-start">{language === 'ar' ? 'رقم الإصلاح' : 'Dossier'}</th>
                  <th className="py-3 px-4 text-start">{t.date}</th>
                  <th className="py-3 px-4 text-start">{t.repairs.customerName}</th>
                  <th className="py-3 px-4 text-start">{language === 'ar' ? 'الجهاز والعطب' : 'Appareil & Panne'}</th>
                  <th className="py-3 px-4 text-start">{language === 'ar' ? 'المرحلة' : 'Étape'}</th>
                  <th className="py-3 px-4 text-end">{t.total}</th>
                  <th className="py-3 px-4 text-end">{t.repairs.deposit}</th>
                  <th className="py-3 px-4 text-end">{t.repairs.remaining}</th>
                  <th className="py-3 px-4 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {paginatedRepairs.map((repair) => {
                  const badge = getStatusBadge(repair.status);
                  return (
                    <tr key={repair.id} className="hover:bg-neutral-800/40 transition">
                      <td className="py-3 px-4 font-mono font-bold text-amber-400 whitespace-nowrap">
                        {repair.repairNumber}
                      </td>
                      <td className="py-3 px-4 text-neutral-400 whitespace-nowrap font-mono text-[11px]">
                        <div>{repair.intakeDate}</div>
                        {repair.expectedDeliveryDate && (
                          <div className="text-[10px] text-emerald-400/80">
                            Prévu: {repair.expectedDeliveryDate}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-neutral-100">{repair.customerName}</div>
                        <a
                          href={`tel:${repair.customerPhone}`}
                          className="text-[11px] text-neutral-400 hover:text-amber-400 font-mono transition"
                        >
                          {repair.customerPhone}
                        </a>
                      </td>
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-bold text-neutral-100 flex items-center gap-1.5">
                          <Smartphone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span>{repair.brand} {repair.model}</span>
                        </div>
                        <div className="text-neutral-400 text-[11px] truncate mt-0.5" title={repair.issue}>
                          {repair.issue}
                        </div>
                        {repair.lockCode && (
                          <span className="text-[10px] font-mono text-amber-300/80 bg-neutral-950 px-1 rounded border border-neutral-800">
                            PIN: {repair.lockCode}
                          </span>
                        )}
                        {repair.usedParts && repair.usedParts.length > 0 && can('view_profits') && (
                          <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-300 font-mono border border-amber-500/30">
                              {repair.usedParts.length} {language === 'ar' ? 'قطع مستعملة' : 'pièces'} ({formatMAD(repair.totalPartsCost || 0, language)})
                            </span>
                            <span className="text-[10px] font-bold text-emerald-400 font-mono">
                              {language === 'ar' ? 'ربح:' : 'Gain:'} {formatMAD(
                                repair.netProfit !== undefined
                                  ? repair.netProfit
                                  : Math.max(0, repair.agreedPrice - (repair.totalPartsCost || 0)),
                                language
                              )}
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <select
                            value={repair.status}
                            onChange={(e) => handleSelectStatus(repair, e.target.value as RepairStatus)}
                            className={`py-1 px-2.5 rounded-lg text-xs font-bold border cursor-pointer focus:outline-hidden ${badge.color}`}
                          >
                            <option value="pending" className="bg-neutral-900 text-white">{t.repairs.pending}</option>
                            <option value="in_progress" className="bg-neutral-900 text-white">{t.repairs.in_progress}</option>
                            <option value="waiting_parts" className="bg-neutral-900 text-white">{t.repairs.waiting_parts}</option>
                            <option value="ready" className="bg-neutral-900 text-white">{t.repairs.ready}</option>
                            <option value="delivered" className="bg-neutral-900 text-white">{t.repairs.delivered}</option>
                          </select>

                          {repair.status !== 'delivered' && (
                            <button
                              type="button"
                              onClick={() => handleQuickNextStatus(repair)}
                              title={t.repairs.nextStatus}
                              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-neutral-700 transition"
                            >
                              <ChevronRight className="w-3.5 h-3.5 rtl:rotate-180" />
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-end font-mono whitespace-nowrap">
                        <div className="font-bold text-neutral-100">
                          {formatMAD(repair.agreedPrice, language)}
                        </div>
                        {repair.totalPartsCost && can('view_cost_price') ? (
                          <div className="text-[10px] text-neutral-400">
                            Coût: {formatMAD(repair.totalPartsCost, language)}
                          </div>
                        ) : null}
                      </td>
                      <td className="py-3 px-4 text-end font-mono font-semibold text-emerald-400 whitespace-nowrap">
                        {formatMAD(repair.depositAmount, language)}
                      </td>
                      <td className="py-3 px-4 text-end font-mono whitespace-nowrap">
                        {repair.remainingAmount > 0 ? (
                          <span className="font-bold text-rose-400">
                            {formatMAD(repair.remainingAmount, language)}
                          </span>
                        ) : (
                          <span className="font-semibold text-emerald-400">0 DH (Soldé)</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* WhatsApp button */}
                          <button
                            type="button"
                            onClick={() => handleSendWhatsApp(repair)}
                            className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white border border-emerald-500/30 transition shadow-xs"
                            title={
                              repair.status === 'ready'
                                ? (language === 'ar' ? 'إشعار واتساب: الهاتف واجد' : 'Notifier prêt via WhatsApp')
                                : t.whatsapp.send
                            }
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>

                          {/* Quick add spare part button */}
                          {repair.status !== 'delivered' && (
                            <button
                              type="button"
                              onClick={() => handleOpenAddPart(repair)}
                              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-neutral-700 transition"
                              title={t.spareParts.quickAddUsed}
                            >
                              <Cpu className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => handlePrintDeposit(repair)}
                            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-amber-400 border border-neutral-700 transition"
                            title={t.repairs.printDepositReceipt}
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handlePrintDelivery(repair)}
                            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-emerald-400 border border-neutral-700 transition"
                            title={t.repairs.printDeliveryReceipt}
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                          {can('delete_records') && (
                            <button
                              type="button"
                              onClick={() => setDeletingRepair(repair)}
                              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-rose-500/20 text-neutral-400 hover:text-rose-400 border border-neutral-700 hover:border-rose-500/30 transition"
                              title={language === 'ar' ? 'إلغاء الإصلاح واسترجاع القطع' : 'Annuler la réparation (Restituer les pièces)'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Load More Pagination (Partie 1 #11) */}
      {filteredRepairs.length > visibleCount && (
        <div className="flex justify-center pt-2">
          <button
            type="button"
            onClick={() => setVisibleCount((prev) => prev + 20)}
            className="px-5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-amber-500/30 text-amber-400 text-xs font-bold transition"
          >
            {language === 'ar'
              ? `عرض المزيد (${filteredRepairs.length - visibleCount} متبقية)`
              : `Voir plus (${filteredRepairs.length - visibleCount} restants)`}
          </button>
        </div>
      )}

      {/* Intake / New Repair Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title={t.repairs.newRepair}
        maxWidth="2xl"
      >
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmitIntake(true);
          }}
          className="space-y-4 text-xs"
        >
          {/* Section 1: Customer Details */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <h3 className="font-bold text-neutral-100 flex items-center gap-2">
              <Phone className="w-4 h-4 text-amber-400" />
              <span>{t.repairs.clientInfo}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.customerName} *
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="ex: Mohamed Amrani"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-semibold focus:outline-hidden focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.customerPhone} *
                </label>
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0612345678"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-mono focus:outline-hidden focus:border-amber-500/50"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Device Details & Issue */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <h3 className="font-bold text-neutral-100 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-amber-400" />
              <span>{t.repairs.deviceInfo}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.brand} *
                </label>
                <input
                  type="text"
                  required
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder="ex: Samsung, Apple, Xiaomi..."
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-semibold focus:outline-hidden focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.model} *
                </label>
                <input
                  type="text"
                  required
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="ex: Galaxy A54, iPhone 13..."
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-semibold focus:outline-hidden focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.imei}
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={imei}
                    onChange={(e) => setImei(e.target.value)}
                    placeholder="15 chiffres (optionnel)"
                    className="flex-1 bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-mono focus:outline-hidden focus:border-amber-500/50"
                  />
                  <ScanButton
                    onScan={(code) => {
                      setImei(code.trim());
                      success(`IMEI: ${code.trim()}`);
                    }}
                    mode="imei"
                    size="md"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-neutral-300 font-semibold mb-1">
                {t.repairs.issue} *
              </label>
              <textarea
                required
                rows={2}
                value={issue}
                onChange={(e) => setIssue(e.target.value)}
                placeholder="ex: Écran cassé et tactile inopérant suite à chute..."
                className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 focus:outline-hidden focus:border-amber-500/50"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.condition}
                </label>
                <input
                  type="text"
                  value={conditionNotes}
                  onChange={(e) => setConditionNotes(e.target.value)}
                  placeholder={t.repairs.conditionPlaceholder}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 focus:outline-hidden focus:border-amber-500/50"
                />
              </div>

              {/* Lock code (hidden by default) */}
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.lockCode}
                </label>
                <div className="relative">
                  <input
                    type={showLockCode ? 'text' : 'password'}
                    value={lockCode}
                    onChange={(e) => setLockCode(e.target.value)}
                    placeholder="PIN / Mot de passe écran"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg ps-3 pe-10 py-2 text-neutral-100 font-mono focus:outline-hidden focus:border-amber-500/50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLockCode(!showLockCode)}
                    className="absolute end-2 top-1/2 -translate-y-1/2 p-1 text-neutral-400 hover:text-amber-400 transition"
                    title={showLockCode ? t.repairs.hideLockCode : t.repairs.showLockCode}
                  >
                    {showLockCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Financial Pricing & Dates */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <h3 className="font-bold text-neutral-100 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>{t.repairs.financialInfo}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.agreedPrice} *
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  required
                  value={agreedPrice || ''}
                  onChange={(e) => setAgreedPrice(parseFloat(e.target.value) || 0)}
                  placeholder="350"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-mono font-bold focus:outline-hidden focus:border-amber-500/50 text-end"
                />
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.deposit}
                </label>
                <input
                  type="number"
                  min="0"
                  max={agreedPrice}
                  step="0.01"
                  value={depositAmount || ''}
                  onChange={(e) => setDepositAmount(parseFloat(e.target.value) || 0)}
                  placeholder="100"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-emerald-400 font-mono font-bold focus:outline-hidden focus:border-amber-500/50 text-end"
                />
              </div>

              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.remaining}
                </label>
                <div className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg px-3 py-2 font-mono font-black text-end text-rose-400 text-sm">
                  {formatMAD(remainingCalculated, language)}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.intakeDate}
                </label>
                <input
                  type="date"
                  value={intakeDate}
                  onChange={(e) => setIntakeDate(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-mono focus:outline-hidden focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-neutral-300 font-semibold mb-1">
                  {t.repairs.expectedDeliveryDate}
                </label>
                <input
                  type="date"
                  value={expectedDeliveryDate}
                  onChange={(e) => setExpectedDeliveryDate(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-mono focus:outline-hidden focus:border-amber-500/50"
                />
              </div>
            </div>
          </div>

          {/* Terms info */}
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300/90 leading-relaxed">
            {t.repairs.termsNotice}
          </div>

          {/* Form Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-end gap-2.5 pt-2 border-t border-neutral-800">
            <button
              type="button"
              onClick={() => setIsAddOpen(false)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold transition"
            >
              {t.cancel}
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmitIntake(false)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-100 font-bold border border-neutral-700 transition"
            >
              {t.repairs.saveOnly}
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold transition shadow-md shadow-amber-500/20 active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>{t.repairs.saveAndPrint}</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* Deliver Confirmation & Final Revenue Encasement Modal */}
      {deliveringRepair && (
        <Modal
          isOpen={!!deliveringRepair}
          onClose={() => setDeliveringRepair(null)}
          title={t.repairs.deliverDevice}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 space-y-1">
              <div className="flex justify-between font-bold text-neutral-100">
                <span>{deliveringRepair.brand} {deliveringRepair.model}</span>
                <span className="font-mono text-amber-400">{deliveringRepair.repairNumber}</span>
              </div>
              <div className="text-neutral-400">
                Client : <strong className="text-neutral-200">{deliveringRepair.customerName}</strong> ({deliveringRepair.customerPhone})
              </div>
            </div>

            <p className="text-neutral-300 leading-relaxed">
              {t.repairs.deliverConfirm}
            </p>

            <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Prix total réparation :</span>
                <span className="font-mono font-bold text-neutral-100">
                  {formatMAD(deliveringRepair.agreedPrice, language)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Acompte déjà versé :</span>
                <span className="font-mono font-bold text-emerald-400">
                  {formatMAD(deliveringRepair.depositAmount, language)}
                </span>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
                <span className="font-bold text-neutral-100">Montant encaissé maintenant (MAD) :</span>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={collectedAmount}
                  onChange={(e) => setCollectedAmount(parseFloat(e.target.value) || 0)}
                  className="w-28 bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-1 text-end font-mono font-bold text-emerald-400 text-xs focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setDeliveringRepair(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={handleConfirmDeliver}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold shadow-md shadow-emerald-500/25 active:scale-95"
              >
                <Check className="w-4 h-4" />
                <span>{t.confirm}</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Spare Part Selection Modal */}
      {partModalRepair && (
        <Modal
          isOpen={!!partModalRepair}
          onClose={() => setPartModalRepair(null)}
          title={t.spareParts.selectPartToUse}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs">
            {/* Target Repair Header Banner */}
            <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-neutral-100 text-sm">
                    {partModalRepair.brand} {partModalRepair.model}
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    {partModalRepair.repairNumber} · {partModalRepair.customerName}
                  </div>
                </div>
              </div>
              <div className="text-end">
                <div className="text-[10px] text-neutral-500">{language === 'ar' ? 'سعر الإصلاح' : 'Prix convenu'}</div>
                <div className="font-mono font-bold text-amber-400 text-sm">
                  {formatMAD(partModalRepair.agreedPrice, language)}
                </div>
              </div>
            </div>

            {/* Search Available Stock */}
            <div className="relative">
              <Search className="absolute start-3 top-2.5 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={partSearch}
                onChange={(e) => setPartSearch(e.target.value)}
                placeholder={t.spareParts.searchPlaceholder}
                className="w-full ps-9 pe-4 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-hidden focus:border-amber-500/50"
              />
            </div>

            {/* List of Available Spare Parts */}
            <div className="max-h-60 overflow-y-auto space-y-2 pe-1">
              {allSpareParts.filter((p) => {
                if (p.quantity <= 0) return false;
                if (!partSearch.trim()) return true;
                const q = partSearch.toLowerCase().trim();
                return (
                  p.name.toLowerCase().includes(q) ||
                  p.compatibleBrand.toLowerCase().includes(q) ||
                  p.compatibleModel.toLowerCase().includes(q)
                );
              }).length === 0 ? (
                <div className="py-8 text-center text-neutral-500 text-xs">
                  {language === 'ar'
                    ? 'لا توجد قطع غيار متوفرة في المخزون مطابقة للبحث.'
                    : 'Aucune pièce disponible en stock pour cette recherche.'}
                </div>
              ) : (
                allSpareParts
                  .filter((p) => {
                    if (p.quantity <= 0) return false;
                    if (!partSearch.trim()) return true;
                    const q = partSearch.toLowerCase().trim();
                    return (
                      p.name.toLowerCase().includes(q) ||
                      p.compatibleBrand.toLowerCase().includes(q) ||
                      p.compatibleModel.toLowerCase().includes(q)
                    );
                  })
                  .map((part) => {
                    const isSelected = selectedPartId === part.id;
                    const isBrandMatch =
                      part.compatibleBrand.toLowerCase().includes(partModalRepair.brand.toLowerCase()) ||
                      partModalRepair.brand.toLowerCase().includes(part.compatibleBrand.toLowerCase());

                    return (
                      <div
                        key={part.id}
                        onClick={() => setSelectedPartId(part.id!)}
                        className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 shadow-sm shadow-amber-500/10'
                            : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-neutral-100">{part.name}</span>
                            {isBrandMatch && (
                              <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300">
                                {language === 'ar' ? 'متوافق' : 'Compatible'}
                              </span>
                            )}
                            <span className="text-[10px] text-neutral-400 font-medium">
                              ({part.compatibleBrand} {part.compatibleModel})
                            </span>
                          </div>
                          <div className="text-[11px] text-neutral-400 mt-0.5">
                            {language === 'ar' ? 'الجودة :' : 'Qualité :'} {part.quality.toUpperCase()} ·{' '}
                            <span className="text-emerald-400 font-bold font-mono">
                              {part.quantity} {language === 'ar' ? 'متوفرة' : 'en stock'}
                            </span>
                          </div>
                        </div>

                        {can('view_cost_price') && (
                          <div className="text-end">
                            <div className="font-mono font-bold text-amber-400 text-sm">
                              {formatMAD(part.purchasePrice, language)}
                            </div>
                            <div className="text-[10px] text-neutral-500">
                              {language === 'ar' ? 'سعر التكلفة' : 'Coût achat'}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
              )}
            </div>

            {/* Quantity Selector and Profit Preview */}
            {selectedPartId && (
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="font-semibold text-neutral-200">
                    {language === 'ar' ? 'الكمية المستعملة :' : 'Quantité à utiliser :'}
                  </label>
                  <input
                    type="number"
                    min="1"
                    max={allSpareParts.find((p) => p.id === selectedPartId)?.quantity || 1}
                    value={partQuantity}
                    onChange={(e) => setPartQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 bg-neutral-900 border border-neutral-700 rounded-lg px-2.5 py-1 text-center font-mono font-bold text-neutral-100"
                  />
                </div>

                {/* Calculation breakdown */}
                {can('view_profits') && (() => {
                  const part = allSpareParts.find((p) => p.id === selectedPartId);
                  if (!part) return null;
                  const addedCost = part.purchasePrice * partQuantity;
                  const currentPartsCost = partModalRepair.totalPartsCost || 0;
                  const totalNewCost = currentPartsCost + addedCost;
                  const projectedProfit = Math.max(0, partModalRepair.agreedPrice - totalNewCost);

                  return (
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-800 text-[11px]">
                      <div>
                        <span className="text-neutral-400 block">{t.spareParts.partsCost} :</span>
                        <span className="font-mono font-bold text-neutral-200">
                          {formatMAD(totalNewCost, language)}
                        </span>
                      </div>
                      <div className="text-end">
                        <span className="text-neutral-400 block">{t.spareParts.realProfit} :</span>
                        <span className="font-mono font-black text-emerald-400 text-xs">
                          {formatMAD(projectedProfit, language)}
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setPartModalRepair(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                disabled={!selectedPartId}
                onClick={handleConfirmAddPart}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold transition shadow-md disabled:opacity-40"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>
                  {language === 'ar'
                    ? 'إضافة للورشة وخصم من المخزون'
                    : 'Ajouter et déduire du stock'}
                </span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Confirm Dialog to Remove Used Part and Restore Stock */}
      <ConfirmDialog
        isOpen={!!removingPartInfo}
        onClose={() => setRemovingPartInfo(null)}
        onConfirm={handleConfirmRemovePart}
        title={t.spareParts.restoreStockConfirm}
        message={
          language === 'ar'
            ? `هل تريد إزالة القطعة "${removingPartInfo?.partName}" من هذا الإصلاح وإرجاع كميتها تلقائياً إلى مخزون قطع الغيار؟`
            : `Confirmez-vous le retrait de la pièce "${removingPartInfo?.partName}" de cette réparation et sa réintégration au stock de pièces détachées ?`
        }
        isDestructive={true}
      />

      {/* Confirm Dialog to Cancel/Delete Repair and Restore Stock */}
      <ConfirmDialog
        isOpen={!!deletingRepair}
        onClose={() => setDeletingRepair(null)}
        onConfirm={handleConfirmDeleteRepair}
        title={language === 'ar' ? 'إلغاء وحذف ملف الإصلاح' : 'Annuler et supprimer le dossier'}
        message={
          language === 'ar'
            ? `هل أنت متأكد من إلغاء وحذف ملف الإصلاح (${deletingRepair?.repairNumber})؟ في حال كانت هناك قطع غيار مسجلة في هذا الإصلاح، سيتم إرجاع كمياتها تلقائياً إلى المخزون.`
            : `Confirmez-vous l'annulation et la suppression du dossier (${deletingRepair?.repairNumber}) ? Les pièces de rechange utilisées seront automatiquement réintégrées au stock.`
        }
        confirmLabel={language === 'ar' ? 'نعم، إلغاء واسترجاع المخزون' : 'Oui, annuler & restituer'}
        isDestructive={true}
      />

      {/* Thermal & Browser Repair Receipt Preview / Print Modal */}
      <ReceiptPrintModal
        isOpen={!!receiptPrintRepair}
        onClose={() => setReceiptPrintRepair(null)}
        repair={receiptPrintRepair?.repair || null}
        repairType={receiptPrintRepair?.type || 'deposit'}
      />
    </div>
  );
};
