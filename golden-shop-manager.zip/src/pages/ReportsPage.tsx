import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  FileSpreadsheet,
  Download,
  TrendingUp,
  DollarSign,
  Package,
  Wrench,
  Wallet,
  ShieldCheck,
  Calculator,
  Activity,
  BarChart3,
} from 'lucide-react';
import { db } from '../db';
import { useI18n } from '../i18n';
import { formatMAD } from '../lib/currency';
import { getMoroccoDateString, getMoroccoYearMonth } from '../lib/dateUtils';
import { useToast } from '../components/Toast';
import { CashClosureModal } from '../components/CashClosureModal';

type ReportPeriod = 'today' | 'week' | 'month' | 'lastMonth' | 'year' | 'custom';

interface ReportsPageProps {
  initialSubTab?: 'overview' | 'closures' | 'activity';
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ initialSubTab }) => {
  const { language } = useI18n();
  const { success, error } = useToast();
  const isAr = language === 'ar';

  const [period, setPeriod] = useState<ReportPeriod>('month');
  const [customStart, setCustomStart] = useState(getMoroccoDateString());
  const [customEnd, setCustomEnd] = useState(getMoroccoDateString());
  const [subTab, setSubTab] = useState<'overview' | 'closures' | 'activity'>(initialSubTab || 'overview');
  const [isCashClosureOpen, setIsCashClosureOpen] = useState(false);

  React.useEffect(() => {
    if (initialSubTab) {
      setSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  // Live Queries
  const sales =
    useLiveQuery(async () => {
      const all = await db.sales.toArray();
      return all.filter((s) => !s.deleted_at);
    }, []) || [];
  const repairs =
    useLiveQuery(async () => {
      const all = await db.repairs.toArray();
      return all.filter((r) => !r.deleted_at);
    }, []) || [];
  const expenses =
    useLiveQuery(async () => {
      const all = await db.expenses.toArray();
      return all.filter((e) => !e.deleted_at);
    }, []) || [];
  const products =
    useLiveQuery(async () => {
      const all = await db.products.toArray();
      return all.filter((p) => !p.deleted_at).map(({ image, ...rest }) => rest);
    }, []) || [];
  const customers =
    useLiveQuery(async () => {
      const all = await db.customers.toArray();
      return all.filter((c) => !c.deleted_at);
    }, []) || [];
  const purchaseOrders =
    useLiveQuery(async () => {
      const all = await db.supplierPurchaseOrders.toArray();
      return all.filter((po) => !po.deleted_at);
    }, []) || [];
  const cashClosures =
    useLiveQuery(async () => {
      return await db.cashClosures.orderBy('date').reverse().toArray();
    }, []) || [];
  const activityLogs =
    useLiveQuery(async () => {
      return await db.activityLogs.orderBy('id').reverse().limit(200).toArray();
    }, []) || [];

  // Calculate Date Range in Morocco Timezone
  const dateRange = useMemo(() => {
    const now = new Date();
    const todayStr = getMoroccoDateString(now);
    const currentYM = getMoroccoYearMonth(now);

    if (period === 'today') return { start: todayStr, end: todayStr };
    if (period === 'week') {
      const d = new Date(now);
      const day = d.getDay();
      const diff = (day === 0 ? -6 : 1) - day;
      d.setDate(d.getDate() + diff);
      return { start: getMoroccoDateString(d), end: todayStr };
    }
    if (period === 'month') {
      return { start: `${currentYM}-01`, end: todayStr };
    }
    if (period === 'lastMonth') {
      const [y, m] = currentYM.split('-').map(Number);
      const prevDate = new Date(y, m - 2, 1);
      const lastDayPrev = new Date(y, m - 1, 0);
      return {
        start: getMoroccoDateString(prevDate),
        end: getMoroccoDateString(lastDayPrev),
      };
    }
    if (period === 'year') {
      return { start: `${currentYM.slice(0, 4)}-01-01`, end: todayStr };
    }
    return { start: customStart || '2000-01-01', end: customEnd || '2099-12-31' };
  }, [period, customStart, customEnd]);

  // Compute Comprehensive Financial Report
  const report = useMemo(() => {
    const { start, end } = dateRange;

    // Product Sales (exclude REP-xxxx repair cash entries to avoid double counting)
    const periodProductSales = sales.filter(
      (s) =>
        s.date >= start &&
        s.date <= end &&
        s.status !== 'returned' &&
        s.saleKind !== 'repair_deposit' &&
        s.saleKind !== 'repair_delivery' &&
        !s.bonNumber?.startsWith('REP-')
    );

    let salesRevenue = 0;
    let salesCOGS = 0;
    let salesGrossMargin = 0;
    const topProductsMap = new Map<
      string,
      { name: string; qty: number; revenue: number; profit: number }
    >();

    for (const s of periodProductSales) {
      salesRevenue += s.totalAmount || 0;
      const rawSubtotal = (s.items || []).reduce(
        (acc, it) => acc + Number(it.price || 0) * Number(it.quantity || 1),
        0
      );
      const activeSubtotal = (s.items || [])
        .filter((it) => !it.isReturned)
        .reduce((acc, it) => acc + Number(it.price || 0) * Number(it.quantity || 1), 0);
      const activeCost = (s.items || [])
        .filter((it) => !it.isReturned)
        .reduce((acc, it) => acc + Number(it.costPrice || 0) * Number(it.quantity || 1), 0);
      const effectiveDiscount =
        rawSubtotal > 0 ? ((s.discountAmount || 0) * activeSubtotal) / rawSubtotal : 0;

      salesCOGS += activeCost;
      salesGrossMargin += activeSubtotal - effectiveDiscount - activeCost;

      for (const it of s.items || []) {
        if (it.isReturned) continue;
        const itemRev = Number(it.price || 0) * Number(it.quantity || 1);
        const itemCost = Number(it.costPrice || 0) * Number(it.quantity || 1);
        const itemDisc = rawSubtotal > 0 ? ((s.discountAmount || 0) * itemRev) / rawSubtotal : 0;
        const itemProfit = itemRev - itemDisc - itemCost;
        const prev = topProductsMap.get(it.name) || {
          name: it.name,
          qty: 0,
          revenue: 0,
          profit: 0,
        };
        prev.qty += Number(it.quantity || 1);
        prev.revenue += itemRev - itemDisc;
        prev.profit += itemProfit;
        topProductsMap.set(it.name, prev);
      }
    }

    // Delivered Repairs in Period
    const periodRepairs = repairs.filter((r) => {
      const dDate = r.actualDeliveryDate || r.intakeDate;
      return dDate >= start && dDate <= end && r.status === 'delivered';
    });

    const repairsRevenue = periodRepairs.reduce((acc, r) => acc + (r.agreedPrice || 0), 0);
    const repairsPartsCost = periodRepairs.reduce((acc, r) => acc + (r.totalPartsCost || 0), 0);
    const repairsProfit = periodRepairs.reduce(
      (acc, r) =>
        acc +
        (r.netProfit !== undefined ? r.netProfit : (r.agreedPrice || 0) - (r.totalPartsCost || 0)),
      0
    );

    // Expenses in Period
    const periodExpenses = expenses.filter((e) => e.date >= start && e.date <= end);
    const totalExpenses = periodExpenses.reduce((acc, e) => acc + (Number(e.amount) || 0), 0);

    // Stock Valuation
    const stockCostValue = products.reduce(
      (acc, p) => acc + (Number(p.purchasePrice) || 0) * (Number(p.quantity) || 0),
      0
    );
    const stockRetailValue = products.reduce(
      (acc, p) => acc + (Number(p.retailPrice) || 0) * (Number(p.quantity) || 0),
      0
    );

    // Purchase Orders in Period
    const periodPOs = purchaseOrders.filter((po) => po.date >= start && po.date <= end);
    const totalPurchases = periodPOs.reduce((acc, po) => acc + (po.totalAmount || 0), 0);

    const netProfit = salesGrossMargin + repairsProfit - totalExpenses;
    const topProducts = Array.from(topProductsMap.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    return {
      periodProductSales,
      periodRepairs,
      periodExpenses,
      periodPOs,
      salesRevenue,
      salesCOGS,
      salesGrossMargin,
      repairsRevenue,
      repairsPartsCost,
      repairsProfit,
      totalExpenses,
      totalPurchases,
      netProfit,
      stockCostValue,
      stockRetailValue,
      topProducts,
    };
  }, [sales, repairs, expenses, products, purchaseOrders, dateRange]);

  // Export Multi-Sheet Excel (.xlsx) for Accountant (Partie 3 #7)
  const handleExportExcel = async () => {
    try {
      const XLSX = await import('xlsx');
      const wb = XLSX.utils.book_new();

      // Sheet 1: Ventes
      const salesRows = report.periodProductSales.map((s) => ({
        Bon: s.bonNumber,
        Date: s.date,
        Client: s.customerName,
        Telephone: s.customerPhone || '',
        Articles: s.items
          .filter((i) => !i.isReturned)
          .map((i) => `${i.quantity}x ${i.name}${i.imei ? ` [${i.imei}]` : ''}`)
          .join(' | '),
        Remise_DH: s.discountAmount || 0,
        Total_Net_DH: s.totalAmount,
        Paye_DH: s.paidAmount,
        Reste_Credit_DH: s.remainingAmount,
        Mode: s.paymentMethod || s.paymentType,
        Statut: s.status,
      }));
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(salesRows.length ? salesRows : [{ Note: 'Aucune vente' }]),
        'Ventes'
      );

      // Sheet 2: Réparations
      const repairRows = report.periodRepairs.map((r) => ({
        Dossier: r.repairNumber,
        Date_Reception: r.intakeDate,
        Date_Livraison: r.actualDeliveryDate || r.intakeDate,
        Client: r.customerName,
        Appareil: `${r.brand} ${r.model}`,
        Panne: r.issue,
        Prix_Convenu_DH: r.agreedPrice,
        Cout_Pieces_DH: r.totalPartsCost || 0,
        Benefice_Net_DH:
          r.netProfit !== undefined ? r.netProfit : r.agreedPrice - (r.totalPartsCost || 0),
      }));
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(repairRows.length ? repairRows : [{ Note: 'Aucune réparation' }]),
        'Reparations'
      );

      // Sheet 3: Dépenses
      const expenseRows = report.periodExpenses.map((e) => ({
        Date: e.date,
        Categorie: e.category,
        Intitule: e.title || '',
        Montant_DH: e.amount,
        Note: e.note || '',
      }));
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(expenseRows.length ? expenseRows : [{ Note: 'Aucune dépense' }]),
        'Depenses'
      );

      // Sheet 4: Achats Fournisseurs
      const poRows = report.periodPOs.map((po) => ({
        Bon_Achat: po.bonNumber,
        Date: po.date,
        Fournisseur: po.supplierName,
        Total_DH: po.totalAmount,
        Paye_DH: po.paidAmount,
        Reste_Dette_DH: po.remainingAmount,
      }));
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(poRows.length ? poRows : [{ Note: 'Aucun bon d’achat' }]),
        'Achats_Fournisseurs'
      );

      // Sheet 5: État du Stock
      const stockRows = products.map((p) => ({
        Designation: p.name,
        Categorie: p.category,
        Quantite: p.quantity,
        Seuil_Alerte: p.minAlertQty ?? 5,
        Prix_Achat_DH: p.purchasePrice,
        Prix_Vente_Detail_DH: p.retailPrice,
        Prix_Vente_Gros_DH: p.wholesalePrice,
        Valeur_Stock_Achat_DH: p.purchasePrice * p.quantity,
      }));
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(stockRows.length ? stockRows : [{ Note: 'Stock vide' }]),
        'Stock'
      );

      // Sheet 6: Crédits Clients
      const creditRows = customers
        .filter((c) => c.totalCredit > 0)
        .map((c) => ({
          Client: c.name,
          Telephone: c.phone,
          CIN: c.CIN || '',
          Credit_Du_DH: c.totalCredit,
        }));
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(creditRows.length ? creditRows : [{ Note: 'Aucun crédit' }]),
        'Credits_Clients'
      );

      const fileName = `Golden_Shop_Comptabilite_${dateRange.start}_${dateRange.end}.xlsx`;
      XLSX.writeFile(wb, fileName);
      success(
        isAr
          ? 'تم تحميل ملف المحاسبة Excel بنجاح.'
          : 'Fichier comptable Excel (.xlsx) généré avec succès.'
      );
    } catch {
      error(isAr ? 'خطأ أثناء تصدير Excel.' : "Erreur lors de l'export Excel.");
    }
  };

  // Export CSV of Sales
  const handleExportSalesCsv = () => {
    const headers = ['Bon', 'Date', 'Client', 'Total_DH', 'Paye_DH', 'Reste_DH', 'Statut'];
    const lines = report.periodProductSales.map((s) =>
      [
        s.bonNumber,
        s.date,
        `"${(s.customerName || '').replace(/"/g, '""')}"`,
        s.totalAmount,
        s.paidAmount,
        s.remainingAmount,
        s.status,
      ].join(',')
    );
    const csvContent = '\uFEFF' + [headers.join(','), ...lines].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Ventes_${dateRange.start}_${dateRange.end}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    success(isAr ? 'تم تحميل ملف CSV.' : 'Export CSV téléchargé.');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-2xl bg-neutral-900 border border-amber-500/25 shadow-xl">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-gold-gradient tracking-tight flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-amber-400" />
            <span>
              {isAr
                ? 'التقارير المالية والمحاسبة وسجل العمليات'
                : 'Rapports Financiers, Exports Comptables & Audit'}
            </span>
          </h1>
          <p className="text-xs text-neutral-400 mt-1">
            {isAr
              ? `الفترة: من ${dateRange.start} إلى ${dateRange.end}`
              : `Période analysée : du ${dateRange.start} au ${dateRange.end}`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsCashClosureOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Calculator className="w-4 h-4" />
            <span>{isAr ? 'إغلاق الصندوق اليومي' : 'Clôture de Caisse (Z)'}</span>
          </button>

          <button
            type="button"
            onClick={handleExportSalesCsv}
            className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Download className="w-4 h-4" />
            <span>CSV</span>
          </button>

          <button
            type="button"
            onClick={handleExportExcel}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition active:scale-95"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{isAr ? 'تصدير للمحاسب (Excel .xlsx)' : 'Export Comptable (.xlsx)'}</span>
          </button>
        </div>
      </div>

      {/* Sub-navigation & Period Filter */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 p-4 rounded-xl bg-neutral-900/70 border border-neutral-800">
        <div className="flex items-center gap-1.5 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
          <button
            type="button"
            onClick={() => setSubTab('overview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              subTab === 'overview'
                ? 'bg-amber-500 text-neutral-950'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            {isAr ? 'الملخص المالي والأرباح' : 'Bilan Financier'}
          </button>
          <button
            type="button"
            onClick={() => setSubTab('closures')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              subTab === 'closures'
                ? 'bg-amber-500 text-neutral-950'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            {isAr ? `إغلاقات الصندوق (${cashClosures.length})` : `Clôtures Z (${cashClosures.length})`}
          </button>
          <button
            type="button"
            onClick={() => setSubTab('activity')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              subTab === 'activity'
                ? 'bg-amber-500 text-neutral-950'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            {isAr ? 'سجل نشاط المحل' : "Journal d'Activité"}
          </button>
        </div>

        {/* Period Pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {(
            [
              { id: 'today', fr: "Aujourd'hui", ar: 'اليوم' },
              { id: 'week', fr: 'Cette semaine', ar: 'هذا الأسبوع' },
              { id: 'month', fr: 'Ce mois', ar: 'هذا الشهر' },
              { id: 'lastMonth', fr: 'Mois dernier', ar: 'الشهر الماضي' },
              { id: 'year', fr: 'Cette année', ar: 'هذه السنة' },
              { id: 'custom', fr: 'Personnalisé', ar: 'فترة مخصصة' },
            ] as { id: ReportPeriod; fr: string; ar: string }[]
          ).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-2.5 py-1.5 rounded-lg font-medium transition ${
                period === p.id
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 font-bold'
                  : 'bg-neutral-800 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {isAr ? p.ar : p.fr}
            </button>
          ))}
        </div>
      </div>

      {period === 'custom' && (
        <div className="flex items-center gap-3 p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
          <div>
            <label className="text-neutral-400 me-2">{isAr ? 'من:' : 'Du :'}</label>
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-neutral-100"
            />
          </div>
          <div>
            <label className="text-neutral-400 me-2">{isAr ? 'إلى:' : 'Au :'}</label>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-neutral-100"
            />
          </div>
        </div>
      )}

      {subTab === 'overview' && (
        <div className="space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{isAr ? 'رقم معاملات المبيعات' : 'Chiffre d’Affaires Ventes'}</span>
                <DollarSign className="w-4 h-4 text-amber-400" />
              </div>
              <div className="font-mono font-black text-lg text-neutral-100">
                {formatMAD(report.salesRevenue, language)}
              </div>
              <div className="text-[11px] text-emerald-400 font-mono">
                {isAr ? 'هامش ربح المبيعات: ' : 'Marge brute : '}
                {formatMAD(report.salesGrossMargin, language)}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{isAr ? 'مداخيل وأرباح الإصلاحات' : 'Revenus Réparations'}</span>
                <Wrench className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="font-mono font-black text-lg text-neutral-100">
                {formatMAD(report.repairsRevenue, language)}
              </div>
              <div className="text-[11px] text-emerald-400 font-mono">
                {isAr ? 'صافي ربح الإصلاح: ' : 'Bénéfice net rép. : '}
                {formatMAD(report.repairsProfit, language)}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{isAr ? 'مجموع المصاريف' : 'Total des Dépenses'}</span>
                <Wallet className="w-4 h-4 text-rose-400" />
              </div>
              <div className="font-mono font-black text-lg text-rose-400">
                {formatMAD(report.totalExpenses, language)}
              </div>
              <div className="text-[11px] text-neutral-400 font-mono">
                {isAr ? 'مشتريات السلع (BA): ' : 'Achats stock (BA) : '}
                {formatMAD(report.totalPurchases, language)}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900 border border-amber-500/40 space-y-1 shadow-lg">
              <div className="flex items-center justify-between text-xs text-amber-300 font-bold">
                <span>{isAr ? 'الربح الصافي الحقيقي' : 'Bénéfice Net Réel'}</span>
                <TrendingUp className="w-4 h-4 text-amber-400" />
              </div>
              <div
                className={`font-mono font-black text-xl ${
                  report.netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {formatMAD(report.netProfit, language)}
              </div>
              <div className="text-[10px] text-neutral-400">
                {isAr
                  ? 'بعد خصم ثمن السلعة، قطع الغيار والمصاريف'
                  : 'Marge ventes + Réparations - Dépenses'}
              </div>
            </div>
          </div>

          {/* Stock Valuation & Top Products */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-4">
              <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
                <Package className="w-4 h-4 text-amber-400" />
                <span>{isAr ? 'تقييم المخزون الحالي' : 'Valorisation Actuelle du Stock'}</span>
              </h3>
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span className="text-neutral-400">
                    {isAr ? 'قيمة المخزون بثمن الشراء :' : 'Valeur au prix d’achat :'}
                  </span>
                  <span className="font-mono font-bold text-amber-400">
                    {formatMAD(report.stockCostValue, language)}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span className="text-neutral-400">
                    {isAr ? 'قيمة المخزون بثمن البيع :' : 'Valeur au prix de vente :'}
                  </span>
                  <span className="font-mono font-bold text-emerald-400">
                    {formatMAD(report.stockRetailValue, language)}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span className="text-neutral-400">
                    {isAr ? 'الربح المتوقع من المخزون :' : 'Marge potentielle en stock :'}
                  </span>
                  <span className="font-mono font-bold text-neutral-100">
                    {formatMAD(
                      Math.max(0, report.stockRetailValue - report.stockCostValue),
                      language
                    )}
                  </span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
              <h3 className="text-sm font-bold text-neutral-100">
                {isAr
                  ? 'أكثر المنتجات مبيعاً وربحاً خلال الفترة'
                  : 'Top Produits Vendus sur la Période'}
              </h3>
              {report.topProducts.length === 0 ? (
                <p className="text-xs text-neutral-500 py-8 text-center italic">
                  {isAr ? 'لا توجد مبيعات في هذه الفترة.' : 'Aucune vente enregistrée sur cette période.'}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-start">
                    <thead className="text-[10px] uppercase text-neutral-400 border-b border-neutral-800">
                      <tr>
                        <th className="py-2 text-start">{isAr ? 'المنتج' : 'Article'}</th>
                        <th className="py-2 text-center">{isAr ? 'الكمية' : 'Qté'}</th>
                        <th className="py-2 text-end">{isAr ? 'المبيعات' : 'CA Net'}</th>
                        <th className="py-2 text-end">{isAr ? 'الربح الصافي' : 'Marge'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-800/60">
                      {report.topProducts.map((tp, idx) => (
                        <tr key={idx}>
                          <td className="py-2.5 font-semibold text-neutral-200">{tp.name}</td>
                          <td className="py-2.5 text-center font-mono">{tp.qty}</td>
                          <td className="py-2.5 text-end font-mono text-amber-400">
                            {formatMAD(tp.revenue, language)}
                          </td>
                          <td className="py-2.5 text-end font-mono font-bold text-emerald-400">
                            {formatMAD(tp.profit, language)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SubTab 2: Cash Closures History (Partie 3 #4) */}
      {subTab === 'closures' && (
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-amber-400" />
            <span>
              {isAr ? 'سجل إغلاق الصندوق اليومي (Z de caisse)' : 'Historique des Clôtures de Caisse'}
            </span>
          </h3>
          {cashClosures.length === 0 ? (
            <p className="text-xs text-neutral-500 py-8 text-center italic">
              {isAr ? 'لم يتم تسجيل أي إغلاق للصندوق بعد.' : 'Aucune clôture de caisse enregistrée.'}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-start">
                <thead className="text-[10px] uppercase text-neutral-400 border-b border-neutral-800">
                  <tr>
                    <th className="py-2.5 px-3 text-start">{isAr ? 'التاريخ' : 'Date'}</th>
                    <th className="py-2.5 px-3 text-end">
                      {isAr ? 'النقد المتوقع' : 'Attendu Caisse'}
                    </th>
                    <th className="py-2.5 px-3 text-end">
                      {isAr ? 'النقد الفعلي المحسوب' : 'Espèces Comptées'}
                    </th>
                    <th className="py-2.5 px-3 text-end">{isAr ? 'الفارق' : 'Écart'}</th>
                    <th className="py-2.5 px-3 text-start">{isAr ? 'المسؤول' : 'Par'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-mono">
                  {cashClosures.map((c) => (
                    <tr key={c.id}>
                      <td className="py-2.5 px-3 font-bold text-amber-400">{c.date}</td>
                      <td className="py-2.5 px-3 text-end">
                        {formatMAD(c.netExpectedCash, language)}
                      </td>
                      <td className="py-2.5 px-3 text-end font-bold text-neutral-100">
                        {formatMAD(c.countedCash, language)}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-end font-bold ${
                          Math.abs(c.discrepancy) < 0.01
                            ? 'text-emerald-400'
                            : c.discrepancy > 0
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {c.discrepancy > 0 ? `+${formatMAD(c.discrepancy, language)}` : formatMAD(c.discrepancy, language)}
                      </td>
                      <td className="py-2.5 px-3 font-sans text-neutral-400">
                        {c.closedBy} {c.notes ? `— ${c.notes}` : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SubTab 3: Activity Log (Partie 3 #2) */}
      {subTab === 'activity' && (
        <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
          <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <span>
              {isAr
                ? 'سجل تتبع العمليات (المالك / المستخدم)'
                : "Journal d'Activité & Traçabilité (Propriétaire / Employé)"}
            </span>
          </h3>
          {activityLogs.length === 0 ? (
            <p className="text-xs text-neutral-500 py-8 text-center italic">
              {isAr ? 'لا توجد عمليات مسجلة بعد.' : 'Aucune activité enregistrée.'}
            </p>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {activityLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                        log.userRole === 'owner'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      }`}
                    >
                      {log.userName}
                    </span>
                    <span className="text-neutral-200 truncate">{log.details}</span>
                  </div>
                  <span className="text-[11px] font-mono text-neutral-500 shrink-0">
                    {log.createdAt.replace('T', ' ').slice(0, 16)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <CashClosureModal
        isOpen={isCashClosureOpen}
        onClose={() => setIsCashClosureOpen(false)}
      />
    </div>
  );
};
