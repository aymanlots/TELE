import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  Boxes,
  TrendingUp,
  CreditCard,
  AlertTriangle,
  Receipt,
  Plus,
  Eye,
  Search,
  Truck,
  Wrench,
  PackageCheck,
  Cpu,
  Wallet,
  Calculator,
  BarChart3,
} from 'lucide-react';
import { db, getStoreSettings } from '../db';
import { StatCard } from '../components/StatCard';
import { Modal } from '../components/Modal';
import { CashClosureModal } from '../components/CashClosureModal';
import { useI18n } from '../i18n';
import { formatMAD } from '../lib/currency';
import { AppTab, Product, Sale } from '../types';
import { useViewMode } from '../lib/viewMode';
import { getMoroccoDateString, getMoroccoYearMonth } from '../lib/dateUtils';

interface DashboardPageProps {
  onNavigate: (tab: AppTab, params?: any) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { t, language } = useI18n();
  const { isMobileMode } = useViewMode();
  const [showLowStockModal, setShowLowStockModal] = useState(false);
  const [showCashClosureModal, setShowCashClosureModal] = useState(false);

  // Live queries from Dexie (strip base64 images from products list for memory performance - Partie 1 #11)
  const products =
    useLiveQuery(async () => {
      const list = await db.products.toArray();
      return list
        .filter((p) => !p.deleted_at)
        .map(({ image, ...rest }) => rest as Product);
    }, []) || [];
  const sales = useLiveQuery(() => db.sales.orderBy('id').reverse().toArray(), []) || [];
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const suppliers = useLiveQuery(() => db.suppliers.toArray(), []) || [];
  const repairs = useLiveQuery(() => db.repairs.toArray(), []) || [];
  const spareParts = useLiveQuery(() => db.spareParts.toArray(), []) || [];
  const expenses = useLiveQuery(() => db.expenses.toArray(), []) || [];

  // Workshop counters
  const openRepairsCount = repairs.filter((r) => r.status !== 'delivered' && !r.deleted_at).length;
  const readyRepairsCount = repairs.filter((r) => r.status === 'ready' && !r.deleted_at).length;
  const lowSpareParts = spareParts.filter((p) => !p.deleted_at && p.quantity <= (p.minAlertQty ?? 2));

  // 1. KPI: Total stock value (purchase price * quantity)
  const totalStockValue = products.reduce((acc, p) => acc + p.purchasePrice * p.quantity, 0);

  // 2. KPI: Today's sales (in Morocco local timezone - Partie 1 #6)
  // Includes product sales net of returns + repair deposits on intakeDate + repair delivery balances on deliveryDate
  const todayStr = getMoroccoDateString();
  const todaySales = sales
    .filter((s) => s.date === todayStr && s.status !== 'returned' && !s.deleted_at)
    .reduce((acc, s) => acc + s.totalAmount, 0);

  // 3. KPI: Customer total credit
  const totalCustomerCredit = customers
    .filter((c) => !c.deleted_at)
    .reduce((acc, c) => acc + (c.totalCredit || 0), 0);

  // 4. KPI: Low stock items using configurable minAlertQty per product (default 5 - Partie 1 #12)
  const lowStockProducts = products.filter((p) => p.quantity <= (p.minAlertQty ?? 5));

  // 5. KPI: Supplier total debt balance
  const totalSupplierDebt = suppliers
    .filter((s) => !s.deleted_at)
    .reduce((acc, s) => acc + Math.max(0, s.totalDebt - s.paidAmount), 0);

  // 6. KPI: Monthly Net Profit (Partie 1 #2 & #5: Never double-count repairs; exclude returned items & proportional discount)
  const currentMonthKey = getMoroccoYearMonth();
  const monthProductSales = sales.filter(
    (s) =>
      s.date.startsWith(currentMonthKey) &&
      s.status !== 'returned' &&
      !s.deleted_at &&
      (!s.saleKind || s.saleKind === 'product') &&
      !s.bonNumber?.startsWith('REP-')
  );

  let monthSalesMargin = 0;
  for (const s of monthProductSales) {
    const activeItems = (s.items || []).filter((it) => !it.isReturned);
    if (activeItems.length === 0) continue;
    const activeCost = activeItems.reduce(
      (sum, it) => sum + (Number(it.costPrice) || 0) * (Number(it.quantity) || 1),
      0
    );
    // s.totalAmount is already net of discounts and net of any returned items
    monthSalesMargin += s.totalAmount - activeCost;
  }

  // Delivered repairs counted strictly ONCE with parts cost deducted
  const monthRepairs = repairs.filter((r) => {
    if (r.deleted_at || r.status !== 'delivered') return false;
    const rDate = r.actualDeliveryDate || r.intakeDate;
    return rDate.startsWith(currentMonthKey);
  });
  const monthRepairsProfit = monthRepairs.reduce(
    (acc, r) =>
      acc +
      (r.netProfit !== undefined
        ? r.netProfit
        : r.agreedPrice - (r.totalPartsCost || 0)),
    0
  );

  const monthExpenses = expenses
    .filter((e) => !e.deleted_at && e.date.startsWith(currentMonthKey))
    .reduce((acc, e) => acc + (Number(e.amount) || 0), 0);

  const monthNetProfit = monthSalesMargin + monthRepairsProfit - monthExpenses;

  // Last 7 days sales aggregation in Morocco timezone
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = getMoroccoDateString(d);
    const daySales = sales
      .filter((s) => s.date === dateStr && s.status !== 'returned' && !s.deleted_at)
      .reduce((sum, s) => sum + s.totalAmount, 0);
    const dayLabel = d.toLocaleDateString(language === 'ar' ? 'ar-MA' : 'fr-MA', {
      weekday: 'short',
    });
    return { date: dateStr, label: dayLabel, total: daySales };
  });

  const maxDaySales = Math.max(...last7Days.map((d) => d.total), 1000);

  // Quick Bon PDF Preview (Dynamic import - Partie 1 #11)
  const handleViewPdf = async (sale: Sale) => {
    const settings = await getStoreSettings();
    const { generateBonPDF } = await import('../lib/pdfGenerator');
    await generateBonPDF(sale, settings, 'save');
  };

  return (
    <div className="space-y-6">
      {/* Top Welcome & Quick Actions Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-neutral-900 border border-amber-500/20 shadow-xl shadow-black/80">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-gold-gradient tracking-tight">
            {t.dashboard.title}
          </h1>
          <p className="text-xs text-neutral-300 mt-1 font-medium">
            {t.appSubtitle}
          </p>
        </div>

        <div className={`flex flex-wrap items-center gap-2 ${isMobileMode ? 'w-full grid grid-cols-2' : 'shrink-0'}`}>
          <button
            onClick={() => onNavigate('pos')}
            className={`flex items-center justify-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold transition shadow-sm active:scale-95 ${
              isMobileMode ? 'py-3 px-3 text-xs min-h-[44px]' : 'px-3.5 py-2 text-xs'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>{t.nav.pos}</span>
          </button>
          <button
            onClick={() => onNavigate('stock', { action: 'add' })}
            className={`flex items-center justify-center gap-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold border border-neutral-700 transition active:scale-95 ${
              isMobileMode ? 'py-3 px-3 text-xs min-h-[44px]' : 'px-3 py-2 text-xs'
            }`}
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.stock.addProduct}</span>
          </button>
          <button
            onClick={() => setShowCashClosureModal(true)}
            className={`flex items-center justify-center gap-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-bold border border-emerald-500/30 transition active:scale-95 ${
              isMobileMode ? 'py-3 px-3 text-xs min-h-[44px]' : 'px-3 py-2 text-xs'
            }`}
          >
            <Calculator className="w-3.5 h-3.5 text-emerald-400" />
            <span>{language === 'ar' ? 'إغلاق الصندوق' : 'Clôture Caisse'}</span>
          </button>
          <button
            onClick={() => onNavigate('reports')}
            className={`flex items-center justify-center gap-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-amber-300 font-bold border border-amber-500/30 transition active:scale-95 ${
              isMobileMode ? 'py-3 px-3 text-xs min-h-[44px]' : 'px-3 py-2 text-xs'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'ar' ? 'التقارير' : 'Rapports'}</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <StatCard
          title={t.dashboard.kpiStockValue}
          value={formatMAD(totalStockValue, language)}
          subtitle={`${products.length} références`}
          icon={Boxes}
          onClick={() => onNavigate('stock')}
        />
        <StatCard
          title={t.dashboard.kpiTodaySales}
          value={formatMAD(todaySales, language)}
          subtitle={`${sales.filter((s) => s.date === todayStr).length} bons aujourd'hui`}
          icon={TrendingUp}
          onClick={() => onNavigate('bons')}
        />
        <StatCard
          title={t.dashboard.kpiCustomerCredit}
          value={formatMAD(totalCustomerCredit, language)}
          subtitle={`${customers.filter((c) => c.totalCredit > 0).length} clients avec solde`}
          icon={CreditCard}
          badge={totalCustomerCredit > 0 ? "À Recouvrer" : "Soldé"}
          alert={totalCustomerCredit > 5000}
          onClick={() => onNavigate('customers')}
        />
        <StatCard
          title={t.dashboard.kpiMonthlyNetProfit}
          value={formatMAD(monthNetProfit, language)}
          subtitle={
            language === 'ar'
              ? `${monthExpenses > 0 ? `مصاريف: ${formatMAD(monthExpenses, language)}` : 'بدون مصاريف'}`
              : `${monthExpenses > 0 ? `Dépenses: ${formatMAD(monthExpenses, language)}` : 'Sans charges'}`
          }
          icon={Wallet}
          badge={monthNetProfit >= 0 ? "+ Bénéfice" : "- Déficit"}
          alert={monthNetProfit < 0}
          onClick={() => onNavigate('expenses')}
        />
        <StatCard
          title={t.dashboard.kpiLowStock}
          value={lowStockProducts.length}
          subtitle={lowStockProducts.length > 0 ? "Moins de 5 pièces" : t.dashboard.noLowStock}
          icon={AlertTriangle}
          alert={lowStockProducts.length > 0}
          badge={lowStockProducts.length > 0 ? "Alerte Stock" : undefined}
          onClick={() => setShowLowStockModal(true)}
        />
      </div>

      {/* Workshop Live Counters (Open & Ready Repairs) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div
          onClick={() => onNavigate('repairs')}
          className="cursor-pointer p-4 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-500/50 transition-all flex items-center justify-between group shadow-sm active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-semibold text-neutral-400">
                {language === 'ar' ? 'الإصلاحات المفتوحة (ورشة الإصلاح)' : 'Réparations ouvertes (En cours)'}
              </div>
              <div className="text-2xl font-black font-mono text-neutral-100 mt-0.5">
                {openRepairsCount}
              </div>
              <div className="text-[11px] text-neutral-500">
                {language === 'ar' ? 'أجهزة قيد الفحص أو في انتظار قطع' : 'En attente de pièces ou en atelier'}
              </div>
            </div>
          </div>
          <span className="text-xs font-bold text-amber-400 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">
            {language === 'ar' ? 'فتح الورشة ←' : 'Ouvrir →'}
          </span>
        </div>

        <div
          onClick={() => onNavigate('repairs')}
          className="cursor-pointer p-4 rounded-xl bg-neutral-900 border border-emerald-500/30 hover:border-emerald-500/60 transition-all flex items-center justify-between group shadow-sm active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
              <PackageCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-semibold text-emerald-400/90 flex items-center gap-2">
                <span>{language === 'ar' ? 'إصلاحات واجدة للتسليم' : 'Appareils Prêts (À livrer)'}</span>
                {readyRepairsCount > 0 && (
                  <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                    {language === 'ar' ? 'جاهز' : 'Prêt'}
                  </span>
                )}
              </div>
              <div className="text-2xl font-black font-mono text-emerald-400 mt-0.5">
                {readyRepairsCount}
              </div>
              <div className="text-[11px] text-neutral-500">
                {language === 'ar' ? 'أجهزة انتهى إصلاحها وتنتظر التسليم' : 'Réparations terminées en attente client'}
              </div>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-400 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">
            {language === 'ar' ? 'تسليم ←' : 'Livrer →'}
          </span>
        </div>
      </div>

      {/* Low Spare Parts Critical Alert */}
      {lowSpareParts.length > 0 && (
        <div
          onClick={() => onNavigate('spare-parts')}
          className="cursor-pointer p-4 rounded-xl bg-amber-500/10 border border-amber-500/40 hover:bg-amber-500/15 transition flex items-center justify-between group shadow-sm active:scale-[0.99]"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
              <Cpu className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="text-xs font-bold text-amber-300 flex items-center gap-2">
                <span>{language === 'ar' ? 'تنبيه: قطع غيار قاربت على النفاد' : 'Alerte : Pièces de rechange sous le seuil critique'}</span>
                <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold">
                  {lowSpareParts.length} {language === 'ar' ? 'قطع' : 'références'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-0.5 line-clamp-1">
                {lowSpareParts.slice(0, 4).map((p) => `${p.name} (${p.compatibleBrand} ${p.compatibleModel}): ${p.quantity} restant`).join('  ·  ')}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-amber-400 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform whitespace-nowrap ps-3 shrink-0">
            {language === 'ar' ? 'عرض القطع ←' : 'Gérer les pièces ←'}
          </span>
        </div>
      )}

      {/* 2-Column Split: Sales Chart + Supplier Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 7-Day Sales Trend Bar Chart (2 columns) */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-neutral-900 border border-neutral-800 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-neutral-100">
                {t.dashboard.salesTrend7Days}
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Total 7 jours :{' '}
                <span className="font-mono font-bold text-amber-400">
                  {formatMAD(last7Days.reduce((a, b) => a + b.total, 0), language)}
                </span>
              </p>
            </div>
            <button
              onClick={() => onNavigate('bons')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium"
            >
              {t.dashboard.viewAllBons} →
            </button>
          </div>

          {/* Bar Chart Container */}
          <div className="h-44 flex items-end justify-between gap-3 pt-6 pb-2 px-2 border-b border-neutral-800">
            {last7Days.map((d, idx) => {
              const heightPercent = Math.max(8, Math.round((d.total / maxDaySales) * 100));
              const isToday = idx === 6;
              return (
                <div key={d.date} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                  <div className="opacity-0 group-hover:opacity-100 transition text-[10px] font-mono text-amber-300 bg-neutral-800 px-1.5 py-0.5 rounded -mb-1 pointer-events-none whitespace-nowrap">
                    {formatMAD(d.total, language)}
                  </div>
                  <div
                    style={{ height: `${heightPercent}%` }}
                    className={`w-full max-w-[42px] rounded-t-md transition-all duration-300 ${
                      isToday
                        ? 'bg-gradient-to-t from-amber-600 to-amber-400 shadow-md shadow-amber-500/10'
                        : d.total > 0
                        ? 'bg-neutral-700 hover:bg-neutral-600'
                        : 'bg-neutral-800/40'
                    }`}
                  />
                  <span className={`text-[11px] font-medium ${isToday ? 'text-amber-400 font-bold' : 'text-neutral-400'}`}>
                    {d.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Suppliers Quick Debt Card */}
        <div className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-neutral-100 flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-400" />
                <span>{t.dashboard.kpiDebtSuppliers}</span>
              </h2>
              <button
                onClick={() => onNavigate('suppliers')}
                className="text-xs text-amber-400 hover:text-amber-300"
              >
                Gérer →
              </button>
            </div>
            <div className="p-4 rounded-lg bg-neutral-950/60 border border-neutral-800 mb-4">
              <div className="text-xs text-neutral-400">Total à régler aux fournisseurs</div>
              <div className="text-xl font-bold font-mono text-neutral-100 mt-1">
                {formatMAD(totalSupplierDebt, language)}
              </div>
            </div>

            <div className="space-y-2 text-xs">
              {suppliers.length === 0 ? (
                <div className="py-4 text-center text-neutral-400 text-xs">
                  {language === 'ar' ? 'ما كاين والو، زيد أول مورد' : 'Aucun fournisseur enregistré'}
                </div>
              ) : (
                suppliers.slice(0, 3).map((sup) => {
                  const bal = Math.max(0, sup.totalDebt - sup.paidAmount);
                  return (
                    <div key={sup.id} className="flex items-center justify-between py-1.5 border-b border-neutral-800/60">
                      <span className="text-neutral-300 truncate max-w-[140px]">{sup.name}</span>
                      <span className={`font-mono font-semibold ${bal > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {formatMAD(bal, language)}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('suppliers')}
            className="w-full mt-4 py-2 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 transition text-center"
          >
            {t.suppliers.title}
          </button>
        </div>
      </div>

      {/* Recent Sales Table */}
      <div className="p-5 rounded-xl bg-neutral-900 border border-neutral-800">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-neutral-100">
            {t.dashboard.recentSales}
          </h2>
          <button
            onClick={() => onNavigate('bons')}
            className="text-xs text-amber-400 hover:text-amber-300 font-medium"
          >
            {t.dashboard.viewAllBons} →
          </button>
        </div>

        {sales.length === 0 ? (
          <div className="py-12 text-center text-neutral-400 text-xs flex flex-col items-center justify-center gap-2.5">
            <Receipt className="w-8 h-8 text-neutral-600" />
            <p className="text-neutral-300 font-medium">
              {language === 'ar' ? 'ما كاين والو، دير أول عملية بيع فـ الكاسة' : 'Aucune vente pour le moment, réalisez votre première vente.'}
            </p>
            <button
              onClick={() => onNavigate('pos')}
              className="mt-1 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-lg text-xs transition"
            >
              {language === 'ar' ? 'فتح الكاسة' : 'Ouvrir la caisse'}
            </button>
          </div>
        ) : isMobileMode ? (
          /* Mobile Mode: Vertical Cards for Sales */
          <div className="space-y-3">
            {sales.slice(0, 10).map((sale) => (
              <div
                key={sale.id}
                className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3 shadow-xs"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono font-black text-amber-400 text-sm">
                      {sale.bonNumber}
                    </span>
                    <div className="text-xs font-semibold text-neutral-200 mt-0.5">
                      {sale.customerName}
                    </div>
                  </div>
                  <span className="text-[10px] text-neutral-500 font-mono">
                    {sale.date}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 py-2 px-3 bg-neutral-900/60 rounded-lg text-center text-xs">
                  <div>
                    <span className="text-[10px] text-neutral-400 block">{t.total}</span>
                    <span className="font-mono font-bold text-neutral-100">
                      {formatMAD(sale.totalAmount, language)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block">{t.paid}</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {formatMAD(sale.paidAmount, language)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block">{t.remaining}</span>
                    <span className={`font-mono font-bold ${sale.remainingAmount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {formatMAD(sale.remainingAmount, language)}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleViewPdf(sale)}
                  className="w-full py-2.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition active:scale-95 min-h-[44px]"
                >
                  <Eye className="w-4 h-4 text-amber-400" />
                  <span>{t.bons.viewPdf}</span>
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead className="bg-neutral-950/60 text-neutral-400 uppercase text-[10px] tracking-wider border-b border-neutral-800">
                <tr>
                  <th className="py-2.5 px-3 text-start">{t.bons.bonNumber}</th>
                  <th className="py-2.5 px-3 text-start">{t.date}</th>
                  <th className="py-2.5 px-3 text-start">{t.bons.client}</th>
                  <th className="py-2.5 px-3 text-end">{t.total}</th>
                  <th className="py-2.5 px-3 text-end">{t.paid}</th>
                  <th className="py-2.5 px-3 text-end">{t.remaining}</th>
                  <th className="py-2.5 px-3 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
              {sales.slice(0, 10).map((sale) => (
                <tr key={sale.id} className="hover:bg-neutral-800/40 transition">
                  <td className="py-3 px-3 font-mono font-bold text-amber-400 whitespace-nowrap">
                    {sale.bonNumber}
                  </td>
                  <td className="py-3 px-3 text-neutral-400 whitespace-nowrap">
                    {sale.date}
                  </td>
                  <td className="py-3 px-3 font-medium text-neutral-200 truncate max-w-[160px]">
                    {sale.customerName}
                  </td>
                  <td className="py-3 px-3 text-end font-mono font-bold text-neutral-100 whitespace-nowrap">
                    {formatMAD(sale.totalAmount, language)}
                  </td>
                  <td className="py-3 px-3 text-end font-mono text-emerald-400 whitespace-nowrap">
                    {formatMAD(sale.paidAmount, language)}
                  </td>
                  <td className="py-3 px-3 text-end font-mono whitespace-nowrap">
                    {sale.remainingAmount > 0 ? (
                      <span className="text-rose-400 font-bold">
                        {formatMAD(sale.remainingAmount, language)}
                      </span>
                    ) : (
                      <span className="text-emerald-400 font-medium">0 DH</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <button
                      onClick={() => handleViewPdf(sale)}
                      className="p-1 rounded text-neutral-400 hover:text-amber-400 transition"
                      title={t.bons.viewPdf}
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>

      {/* Low Stock Alert Modal */}
      <Modal
        isOpen={showLowStockModal}
        onClose={() => setShowLowStockModal(false)}
        title={t.dashboard.lowStockTitle}
        maxWidth="lg"
      >
        <div className="space-y-3">
          {lowStockProducts.length === 0 ? (
            <p className="text-xs text-neutral-400 text-center py-4">{t.dashboard.noLowStock}</p>
          ) : (
            lowStockProducts.map((p) => (
              <div
                key={p.id}
                onClick={() => {
                  setShowLowStockModal(false);
                  onNavigate('stock', { search: p.name });
                }}
                className="flex items-center justify-between p-3 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 border border-neutral-700/60 cursor-pointer transition text-xs"
              >
                <div>
                  <div className="font-semibold text-neutral-100">{p.name}</div>
                  <div className="text-[11px] text-neutral-400 mt-0.5">
                    Catégorie: {t.stock.categories[p.category] || p.category}
                  </div>
                </div>
                <div className="text-end">
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                    {p.quantity} en stock
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </Modal>

      {/* Daily Cash Closure Modal (Partie 3 #4) */}
      <CashClosureModal
        isOpen={showCashClosureModal}
        onClose={() => setShowCashClosureModal(false)}
      />
    </div>
  );
};
