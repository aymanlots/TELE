import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  Cpu,
  Plus,
  Search,
  AlertTriangle,
  Boxes,
  Edit2,
  Trash2,
  Layers,
  ShieldCheck,
  TrendingUp,
  Tag,
  Filter,
  ArrowUpDown,
  Smartphone,
  Truck,
  Minus,
} from 'lucide-react';
import {
  db,
  createSparePart,
  updateSparePart,
  deleteSparePart,
} from '../db';
import { SparePart, PartQuality } from '../types';
import { useI18n } from '../i18n';
import { useViewMode } from '../lib/viewMode';
import { useAccessAuth } from '../lib/accessAuth';
import { useToast } from '../components/Toast';
import { formatMAD } from '../lib/currency';
import { Modal } from '../components/Modal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { StatCard } from '../components/StatCard';

const COMMON_PART_NAMES = [
  'Écran OLED',
  'Écran Incell / LCD',
  'Batterie',
  'Connecteur de charge',
  'Caméra Arrière',
  'Caméra Avant',
  'Nappe Power / Volume',
  'Haut-parleur / Écouteur',
  'Vitre arrière / Châssis',
  'Micro / Nappe auxiliaire',
];

const COMMON_BRANDS = [
  'Apple (iPhone)',
  'Samsung',
  'Xiaomi / Redmi',
  'Infinix',
  'Oppo',
  'Tecno',
  'Huawei',
  'Realme',
  'Autre',
];

interface SparePartsPageProps {
  initialSearch?: string;
  initialAction?: string;
}

export const SparePartsPage: React.FC<SparePartsPageProps> = ({
  initialSearch,
  initialAction,
}) => {
  const { t, language } = useI18n();
  const { isMobileMode } = useViewMode();
  const { can } = useAccessAuth();
  const { success, error } = useToast();

  const [search, setSearch] = useState(initialSearch || '');
  const [brandFilter, setBrandFilter] = useState<string>('all');
  const [qualityFilter, setQualityFilter] = useState<string>('all');
  const [onlyLowStock, setOnlyLowStock] = useState<boolean>(false);

  // Modal Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(initialAction === 'add');
  const [editingPart, setEditingPart] = useState<SparePart | null>(null);
  const [name, setName] = useState('');
  const [compatibleBrand, setCompatibleBrand] = useState('');
  const [compatibleModel, setCompatibleModel] = useState('');
  const [quality, setQuality] = useState<PartQuality>('original');
  const [quantity, setQuantity] = useState<number>(1);
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [supplierId, setSupplierId] = useState<number | undefined>(undefined);
  const [minAlertQty, setMinAlertQty] = useState<number>(2);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Delete Confirm
  const [deletingPart, setDeletingPart] = useState<SparePart | null>(null);

  // Live queries
  const spareParts =
    useLiveQuery(() => db.spareParts.orderBy('id').reverse().toArray(), []) || [];
  const suppliers = useLiveQuery(() => db.suppliers.toArray(), []) || [];

  // Open modal for new part
  const handleOpenAdd = () => {
    setEditingPart(null);
    setName('');
    setCompatibleBrand('');
    setCompatibleModel('');
    setQuality('original');
    setQuantity(1);
    setPurchasePrice(0);
    setSellingPrice(0);
    setSupplierId(undefined);
    setMinAlertQty(2);
    setNotes('');
    setIsModalOpen(true);
  };

  // Open modal for editing
  const handleOpenEdit = (part: SparePart) => {
    setEditingPart(part);
    setName(part.name);
    setCompatibleBrand(part.compatibleBrand);
    setCompatibleModel(part.compatibleModel);
    setQuality(part.quality);
    setQuantity(part.quantity);
    setPurchasePrice(part.purchasePrice);
    setSellingPrice(part.sellingPrice);
    setSupplierId(part.supplierId);
    setMinAlertQty(part.minAlertQty ?? 2);
    setNotes(part.notes || '');
    setIsModalOpen(true);
  };

  // Save part (Create / Update)
  const handleSavePart = async () => {
    if (!name.trim()) {
      error(
        language === 'ar'
          ? 'يرجى إدخال اسم القطعة (شاشة، بطارية...).'
          : 'Veuillez saisir le nom de la pièce.'
      );
      return;
    }
    if (!compatibleBrand.trim() || !compatibleModel.trim()) {
      error(
        language === 'ar'
          ? 'يرجى تحديد الماركة والموديل المتوافق.'
          : 'Veuillez renseigner la marque et le modèle compatibles.'
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const selectedSupplier = suppliers.find((s) => s.id === supplierId);

      const partData = {
        name: name.trim(),
        compatibleBrand: compatibleBrand.trim(),
        compatibleModel: compatibleModel.trim(),
        quality,
        quantity: Math.max(0, Number(quantity) || 0),
        purchasePrice: Math.max(0, Number(purchasePrice) || 0),
        sellingPrice: Math.max(0, Number(sellingPrice) || 0),
        supplierId: supplierId ? Number(supplierId) : undefined,
        supplierName: selectedSupplier?.name,
        minAlertQty: Math.max(0, Number(minAlertQty) || 2),
        notes: notes.trim() || undefined,
      };

      if (editingPart && editingPart.id) {
        await updateSparePart(editingPart.id, partData);
        success(language === 'ar' ? 'تم تحديث القطعة بنجاح.' : 'Pièce mise à jour avec succès.');
      } else {
        await createSparePart(partData);
        success(language === 'ar' ? 'تم تسجيل القطعة بنجاح في المخزون.' : 'Pièce ajoutée au stock avec succès.');
      }
      setIsModalOpen(false);
    } catch {
      error(language === 'ar' ? 'حدث خطأ أثناء الحفظ.' : "Erreur lors de l'enregistrement.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete part
  const handleConfirmDelete = async () => {
    if (!deletingPart || !deletingPart.id) return;
    try {
      await deleteSparePart(deletingPart.id);
      success(language === 'ar' ? 'تم حذف القطعة من المخزون.' : 'Pièce supprimée du stock.');
      setDeletingPart(null);
    } catch {
      error(language === 'ar' ? 'حدث خطأ أثناء الحذف.' : 'Erreur lors de la suppression.');
    }
  };

  // Quick quantity increment/decrement
  const handleQuickAdjustStock = async (part: SparePart, delta: number) => {
    if (!part.id) return;
    const newQty = Math.max(0, part.quantity + delta);
    await updateSparePart(part.id, { quantity: newQty });
  };

  // Filtered parts
  const filteredParts = spareParts.filter((p) => {
    // Low stock filter
    if (onlyLowStock && p.quantity > (p.minAlertQty ?? 2)) return false;

    // Quality filter
    if (qualityFilter !== 'all' && p.quality !== qualityFilter) return false;

    // Brand filter
    if (brandFilter !== 'all' && p.compatibleBrand.toLowerCase() !== brandFilter.toLowerCase())
      return false;

    // Text search
    if (!search.trim()) return true;
    const q = search.toLowerCase().trim();
    return (
      p.name.toLowerCase().includes(q) ||
      p.compatibleBrand.toLowerCase().includes(q) ||
      p.compatibleModel.toLowerCase().includes(q) ||
      (p.supplierName && p.supplierName.toLowerCase().includes(q))
    );
  });

  // KPI Calculations
  const totalStockValue = spareParts.reduce(
    (acc, p) => acc + p.purchasePrice * p.quantity,
    0
  );
  const totalPiecesCount = spareParts.reduce((acc, p) => acc + p.quantity, 0);
  const lowStockPartsCount = spareParts.filter(
    (p) => p.quantity <= (p.minAlertQty ?? 2)
  ).length;

  // Unique brands for filter
  const uniqueBrands = Array.from(
    new Set(spareParts.map((p) => p.compatibleBrand).filter(Boolean))
  );

  // Quality badge helper
  const getQualityBadge = (q: PartQuality) => {
    switch (q) {
      case 'original':
        return {
          label: t.spareParts.original,
          color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs shadow-emerald-500/10',
        };
      case 'oem':
        return {
          label: t.spareParts.oem,
          color: 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-xs shadow-amber-500/10',
        };
      case 'copy':
        return {
          label: t.spareParts.copy,
          color: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Action Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-neutral-900 border border-amber-500/25 shadow-xl shadow-black/80">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-gold-gradient tracking-tight">
                {t.spareParts.title}
              </h1>
              <p className="text-xs text-neutral-400 font-medium">
                {t.spareParts.subtitle}
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs transition shadow-md active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>{t.spareParts.addPart}</span>
        </button>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {can('view_cost_price') && (
          <StatCard
            title={t.spareParts.totalStockValue}
            value={formatMAD(totalStockValue, language)}
            subtitle={`${spareParts.length} références`}
            icon={TrendingUp}
          />
        )}
        <StatCard
          title={t.spareParts.totalPartsCount}
          value={totalPiecesCount}
          subtitle={language === 'ar' ? 'قطعة في المحل' : 'unités physiques en stock'}
          icon={Boxes}
        />
        <StatCard
          title={t.spareParts.lowStockCount}
          value={lowStockPartsCount}
          subtitle={
            lowStockPartsCount > 0
              ? language === 'ar'
                ? 'تحتاج إعادة طلب عاجلة'
                : 'Sous le seuil de sécurité'
              : language === 'ar'
              ? 'المخزون كافي'
              : 'Niveau optimal'
          }
          icon={AlertTriangle}
          alert={lowStockPartsCount > 0}
          badge={lowStockPartsCount > 0 ? t.spareParts.lowStockAlert : undefined}
          onClick={() => setOnlyLowStock((prev) => !prev)}
        />
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3 shadow-lg">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute start-3 top-2.5 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.spareParts.searchPlaceholder}
              className="w-full ps-9 pe-4 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-hidden"
            />
          </div>

          {/* Brand Filter */}
          <select
            value={brandFilter}
            onChange={(e) => setBrandFilter(e.target.value)}
            className="py-2 px-3 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 focus:border-amber-500/60 focus:outline-hidden cursor-pointer"
          >
            <option value="all">{t.spareParts.filterBrand}</option>
            {uniqueBrands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>

          {/* Quality Filter */}
          <select
            value={qualityFilter}
            onChange={(e) => setQualityFilter(e.target.value)}
            className="py-2 px-3 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 focus:border-amber-500/60 focus:outline-hidden cursor-pointer"
          >
            <option value="all">{t.spareParts.filterQuality}</option>
            <option value="original">{t.spareParts.original}</option>
            <option value="oem">{t.spareParts.oem}</option>
            <option value="copy">{t.spareParts.copy}</option>
          </select>

          {/* Low Stock Toggle Button */}
          <button
            onClick={() => setOnlyLowStock((prev) => !prev)}
            className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition border ${
              onlyLowStock
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-xs'
                : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <AlertTriangle className={`w-3.5 h-3.5 ${onlyLowStock ? 'text-rose-400' : 'text-neutral-400'}`} />
            <span>{t.spareParts.onlyLowStock}</span>
          </button>
        </div>
      </div>

      {/* Main Parts View: Mobile Cards or High-Density Desktop Table */}
      {isMobileMode ? (
        <div className="space-y-3">
          {filteredParts.length === 0 ? (
            <div className="py-16 text-center text-xs text-neutral-400 flex flex-col items-center justify-center gap-3 bg-neutral-900 border border-neutral-800 rounded-2xl">
              <Cpu className="w-10 h-10 text-neutral-600" />
              <p className="text-sm font-medium text-neutral-300">
                {search || brandFilter !== 'all' || qualityFilter !== 'all' || onlyLowStock
                  ? t.spareParts.noPartsSearch
                  : t.spareParts.noParts}
              </p>
            </div>
          ) : (
            filteredParts.map((part) => {
              const qualityBadge = getQualityBadge(part.quality);
              const isLow = part.quantity <= (part.minAlertQty ?? 2);
              const isOut = part.quantity === 0;

              return (
                <div
                  key={part.id}
                  className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 shadow-md"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-bold text-neutral-100 text-sm flex items-center gap-2">
                        <span>{part.name}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${qualityBadge.color}`}
                        >
                          {qualityBadge.label}
                        </span>
                      </div>
                      <div className="text-xs text-neutral-400 mt-1 flex items-center gap-1.5 font-medium">
                        <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                        <span>
                          {part.compatibleBrand} · {part.compatibleModel}
                        </span>
                      </div>
                    </div>

                    <div className="text-end shrink-0">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-lg text-xs font-black font-mono border ${
                          isOut
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            : isLow
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        }`}
                      >
                        {part.quantity} pcs
                      </span>
                    </div>
                  </div>

                  {/* Financial Breakdown */}
                  <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs font-mono">
                    {can('view_cost_price') && (
                      <div>
                        <span className="text-[10px] text-neutral-500 block uppercase">
                          {language === 'ar' ? 'سعر الشراء' : 'Achat'}
                        </span>
                        <span className="text-neutral-300 font-bold">
                          {formatMAD(part.purchasePrice, language)}
                        </span>
                      </div>
                    )}
                    <div className={can('view_cost_price') ? 'text-end' : 'col-span-2'}>
                      <span className="text-[10px] text-neutral-500 block uppercase">
                        {language === 'ar' ? 'سعر البيع/التركيب' : 'Vente/Pose'}
                      </span>
                      <span className="text-amber-400 font-bold">
                        {formatMAD(part.sellingPrice, language)}
                      </span>
                    </div>
                  </div>

                  {/* Quick Adjust & Actions Bar */}
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleQuickAdjustStock(part, -1)}
                        disabled={part.quantity <= 0}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 disabled:opacity-40 transition"
                        title="-1"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-mono text-xs font-bold px-2 text-neutral-200">
                        {part.quantity}
                      </span>
                      <button
                        onClick={() => handleQuickAdjustStock(part, 1)}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition"
                        title="+1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(part)}
                        className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-amber-400 transition"
                        title={t.edit}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      {can('delete_records') && (
                        <button
                          onClick={() => setDeletingPart(part)}
                          className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-rose-400 transition"
                          title={t.delete}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        /* Desktop Mode: High-Density Table */
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] tracking-wider border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-4 text-start">{t.spareParts.name}</th>
                  <th className="py-3 px-4 text-start">
                    {language === 'ar' ? 'الماركة والموديل' : 'Appareil Compatible'}
                  </th>
                  <th className="py-3 px-4 text-start">{t.spareParts.quality}</th>
                  <th className="py-3 px-4 text-center">{t.spareParts.quantity}</th>
                  {can('view_cost_price') && (
                    <th className="py-3 px-4 text-end">{t.spareParts.purchasePrice}</th>
                  )}
                  <th className="py-3 px-4 text-end">{t.spareParts.sellingPrice}</th>
                  <th className="py-3 px-4 text-start">{t.spareParts.supplier}</th>
                  <th className="py-3 px-4 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredParts.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-16 text-center text-neutral-400 text-xs">
                      {search || brandFilter !== 'all' || qualityFilter !== 'all' || onlyLowStock
                        ? t.spareParts.noPartsSearch
                        : t.spareParts.noParts}
                    </td>
                  </tr>
                ) : (
                  filteredParts.map((part) => {
                    const qualityBadge = getQualityBadge(part.quality);
                    const isLow = part.quantity <= (part.minAlertQty ?? 2);
                    const isOut = part.quantity === 0;

                    return (
                      <tr key={part.id} className="hover:bg-neutral-800/40 transition">
                        <td className="py-3 px-4">
                          <div className="font-bold text-neutral-100">{part.name}</div>
                          {part.notes && (
                            <div className="text-[11px] text-neutral-500 truncate max-w-xs mt-0.5">
                              {part.notes}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-semibold text-neutral-200">
                            {part.compatibleBrand}
                          </div>
                          <div className="text-[11px] text-amber-400/90 font-mono">
                            {part.compatibleModel}
                          </div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${qualityBadge.color}`}
                          >
                            {qualityBadge.label}
                          </span>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap text-center">
                          <div className="inline-flex items-center gap-1.5 bg-neutral-950 px-2 py-1 rounded-lg border border-neutral-800">
                            <button
                              onClick={() => handleQuickAdjustStock(part, -1)}
                              disabled={part.quantity <= 0}
                              className="text-neutral-400 hover:text-white disabled:opacity-30"
                              title="-1"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span
                              className={`font-mono font-bold text-xs px-1 ${
                                isOut
                                  ? 'text-rose-400'
                                  : isLow
                                  ? 'text-amber-400'
                                  : 'text-emerald-400'
                              }`}
                            >
                              {part.quantity}
                            </span>
                            <button
                              onClick={() => handleQuickAdjustStock(part, 1)}
                              className="text-neutral-400 hover:text-white"
                              title="+1"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                        {can('view_cost_price') && (
                          <td className="py-3 px-4 text-end font-mono text-neutral-300 whitespace-nowrap">
                            {formatMAD(part.purchasePrice, language)}
                          </td>
                        )}
                        <td className="py-3 px-4 text-end font-mono font-bold text-amber-400 whitespace-nowrap">
                          {formatMAD(part.sellingPrice, language)}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap text-neutral-400">
                          {part.supplierName || '—'}
                        </td>
                        <td className="py-3 px-4 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEdit(part)}
                              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 transition"
                              title={t.edit}
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {can('delete_records') && (
                              <button
                                onClick={() => setDeletingPart(part)}
                                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-rose-400 transition"
                                title={t.delete}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Add / Edit Spare Part */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingPart ? t.spareParts.editPart : t.spareParts.addPart}
        maxWidth="2xl"
      >
        <div className="space-y-4">
          {/* Quick Suggestions Strip */}
          <div>
            <label className="text-[11px] font-bold text-neutral-400 block mb-1.5">
              {language === 'ar' ? 'اقتراحات سريعة لاسم القطعة:' : 'Suggestions rapides :'}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_PART_NAMES.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => setName(suggestion)}
                  className={`px-2.5 py-1 rounded-lg text-xs transition border ${
                    name === suggestion
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 font-bold'
                      : 'bg-neutral-950 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          {/* Form Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Part Name */}
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.name} <span className="text-amber-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.spareParts.namePlaceholder}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-hidden"
              />
            </div>

            {/* Compatible Brand */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.compatibleBrand} <span className="text-amber-400">*</span>
              </label>
              <input
                type="text"
                value={compatibleBrand}
                onChange={(e) => setCompatibleBrand(e.target.value)}
                placeholder="ex: Samsung, Apple, Xiaomi..."
                list="brand-suggestions"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-hidden"
              />
              <datalist id="brand-suggestions">
                {COMMON_BRANDS.map((b) => (
                  <option key={b} value={b} />
                ))}
              </datalist>
            </div>

            {/* Compatible Model */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.compatibleModel} <span className="text-amber-400">*</span>
              </label>
              <input
                type="text"
                value={compatibleModel}
                onChange={(e) => setCompatibleModel(e.target.value)}
                placeholder="ex: Galaxy A14, iPhone 11, Redmi Note 12..."
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-hidden"
              />
            </div>

            {/* Quality Selector */}
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
                {t.spareParts.quality}
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['original', 'oem', 'copy'] as PartQuality[]).map((q) => {
                  const badge = getQualityBadge(q);
                  const isSelected = quality === q;
                  return (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setQuality(q)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition border ${
                        isSelected
                          ? `${badge.color} ring-1 ring-amber-400/50`
                          : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      {badge.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.quantity}
              </label>
              <input
                type="number"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs font-mono font-bold text-neutral-100 focus:outline-hidden"
              />
            </div>

            {/* Min Alert Quantity */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.minAlertQty}
              </label>
              <input
                type="number"
                min="0"
                value={minAlertQty}
                onChange={(e) => setMinAlertQty(Number(e.target.value))}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs font-mono text-neutral-100 focus:outline-hidden"
              />
            </div>

            {/* Purchase Price */}
            {can('view_cost_price') && (
              <div>
                <label className="text-xs font-semibold text-neutral-300 block mb-1">
                  {t.spareParts.purchasePrice}
                </label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs font-mono text-neutral-100 focus:outline-hidden"
                />
              </div>
            )}

            {/* Selling / Pose Price */}
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.sellingPrice}
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(Number(e.target.value))}
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs font-mono font-bold text-amber-400 focus:outline-hidden"
              />
            </div>

            {/* Supplier Selector */}
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.supplier}
              </label>
              <select
                value={supplierId || ''}
                onChange={(e) =>
                  setSupplierId(e.target.value ? Number(e.target.value) : undefined)
                }
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs text-neutral-100 focus:outline-hidden cursor-pointer"
              >
                <option value="">
                  {language === 'ar' ? 'بدون مورد محدد' : 'Aucun fournisseur'}
                </option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} {s.phone ? `(${s.phone})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Notes */}
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-neutral-300 block mb-1">
                {t.spareParts.notes}
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Détails techniques, provenance, garantie fournisseur..."
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 focus:border-amber-500/60 rounded-xl text-xs text-neutral-100 placeholder-neutral-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold transition"
            >
              {t.cancel}
            </button>
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleSavePart}
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-black transition shadow-md active:scale-95 disabled:opacity-50"
            >
              {editingPart ? t.save : t.add}
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!deletingPart}
        onClose={() => setDeletingPart(null)}
        onConfirm={handleConfirmDelete}
        title={t.spareParts.deletePart}
        message={
          language === 'ar'
            ? `هل أنت متأكد من حذف القطعة "${deletingPart?.name} (${deletingPart?.compatibleBrand} ${deletingPart?.compatibleModel})" من المخزون؟`
            : `Confirmez-vous la suppression de la pièce "${deletingPart?.name} (${deletingPart?.compatibleBrand} ${deletingPart?.compatibleModel})" du stock ?`
        }
        isDestructive={true}
      />
    </div>
  );
};
