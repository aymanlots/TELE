import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  History,
  Search,
  Filter,
  Eye,
  RotateCcw,
  CreditCard,
  Printer,
  Calendar,
  AlertCircle,
  CheckCircle,
  ShieldCheck,
  Edit,
  Clock,
  Split,
  PlusCircle,
  Trash2,
  MessageCircle,
} from 'lucide-react';
import {
  openWhatsAppChat,
  renderWhatsAppMessage,
  DEFAULT_WHATSAPP_TEMPLATES_AR,
  DEFAULT_WHATSAPP_TEMPLATES_FR,
} from '../lib/whatsapp';
import {
  db,
  returnSaleItemTransaction,
  deleteSaleTransaction,
  registerCustomerPaymentTransaction,
  updateSaleDueDateTransaction,
  updateSaleInstallmentsTransaction,
  getStoreSettings,
} from '../db';
import { Sale, SaleItem, Installment } from '../types';
import { Modal } from '../components/Modal';
import { useViewMode } from '../lib/viewMode';
import { useAccessAuth } from '../lib/accessAuth';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { useToast } from '../components/Toast';
import { useI18n } from '../i18n';
import { formatMAD } from '../lib/currency';
import { getMoroccoDateString } from '../lib/dateUtils';
import { ScanButton } from '../components/ScanButton';
import { ReceiptPrintModal } from '../components/ReceiptPrintModal';

interface BonsHistoryPageProps {
  initialSearch?: string;
}

export const BonsHistoryPage: React.FC<BonsHistoryPageProps> = ({ initialSearch }) => {
  const { t, language } = useI18n();
  const { isMobileMode } = useViewMode();
  const { can } = useAccessAuth();
  const { success, error } = useToast();

  const [search, setSearch] = useState(initialSearch || '');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [visibleCount, setVisibleCount] = useState(25);

  // Selected Sale for Detailed View
  const [viewSale, setViewSale] = useState<Sale | null>(null);
  const [receiptPrintSale, setReceiptPrintSale] = useState<Sale | null>(null);
  const [deleteSaleTarget, setDeleteSaleTarget] = useState<Sale | null>(null);

  // Return Item Modal
  const [returnSale, setReturnSale] = useState<Sale | null>(null);
  const [returnItemIndex, setReturnItemIndex] = useState<number | null>(null);
  const [returnNotes, setReturnNotes] = useState('');

  // Register Payment Modal
  const [paymentSale, setPaymentSale] = useState<Sale | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentNote, setPaymentNote] = useState('');

  // Edit Due Date Modal
  const [isEditingDueDate, setIsEditingDueDate] = useState(false);
  const [editDueDateVal, setEditDueDateVal] = useState('');
  const [editDueDateReason, setEditDueDateReason] = useState('');

  // Edit Installments Modal
  const [isEditingInstallments, setIsEditingInstallments] = useState(false);
  const [tempInstallments, setTempInstallments] = useState<Installment[]>([]);
  const [editInstallmentsReason, setEditInstallmentsReason] = useState('');
  const [splitCount, setSplitCount] = useState<number>(3);
  const [splitFreq, setSplitFreq] = useState<'monthly' | 'biweekly' | 'weekly'>('monthly');

  // Live queries
  const sales =
    useLiveQuery(async () => {
      const all = await db.sales.orderBy('id').reverse().toArray();
      return all.filter((s) => !s.deleted_at);
    }, []) || [];

  // Print PDF helper (Dynamic import - Partie 1 #11)
  const handlePrintPdf = async (sale: Sale) => {
    try {
      const settings = await getStoreSettings();
      const { generateBonPDF } = await import('../lib/pdfGenerator');
      await generateBonPDF(sale, settings, 'save');
      success(`Facture PDF générée pour le bon ${sale.bonNumber}`);
    } catch {
      error("Erreur lors de la génération de la facture PDF.");
    }
  };

  // Print Warranty Certificate helper (Dynamic import - Partie 1 #11)
  const handlePrintWarrantyPdf = async (sale: Sale) => {
    try {
      const settings = await getStoreSettings();
      const { generateWarrantyPDF } = await import('../lib/pdfGenerator');
      await generateWarrantyPDF(sale, settings, 'save');
      success(`Certificat de garantie généré pour le bon ${sale.bonNumber}`);
    } catch {
      error("Erreur lors de la génération du certificat de garantie.");
    }
  };

  // Send WhatsApp receipt details
  const handleSendWhatsApp = async (sale: Sale) => {
    if (!sale.customerPhone || !sale.customerPhone.trim()) {
      error(t.whatsapp.noPhoneAlert);
      return;
    }

    try {
      const settings = await getStoreSettings();
      const templates = settings.whatsappTemplates || {};
      const fallbackTemplates =
        language === 'ar' ? DEFAULT_WHATSAPP_TEMPLATES_AR : DEFAULT_WHATSAPP_TEMPLATES_FR;
      const template = templates.saleReceipt || fallbackTemplates.saleReceipt;

      const text = renderWhatsAppMessage(template, {
        clientName: sale.customerName,
        bonNumber: sale.bonNumber,
        total: sale.totalAmount,
        remaining: sale.remainingAmount,
        storeName: settings.storeName || (language === 'ar' ? 'المحل' : 'Le magasin'),
      });

      const opened = openWhatsAppChat(sale.customerPhone, text);
      if (opened) {
        success(language === 'ar' ? 'تم فتح تطبيق واتساب بنجاح.' : 'Discussion WhatsApp ouverte avec succès.');
      } else {
        error(language === 'ar' ? 'رقم الهاتف غير صالح للمراسلة عبر واتساب.' : 'Numéro de téléphone non valide pour WhatsApp.');
      }
    } catch {
      error(language === 'ar' ? 'حدث خطأ أثناء فتح واتساب.' : "Erreur lors de l'ouverture de WhatsApp.");
    }
  };

  // Confirm Return Item
  const handleConfirmReturn = async () => {
    if (!returnSale || returnItemIndex === null || !returnSale.id) return;
    try {
      await returnSaleItemTransaction(returnSale.id, returnItemIndex, returnNotes);
      success("Article retourné. Le stock et le crédit client ont été ajustés.");
      setReturnSale(null);
      setReturnItemIndex(null);
      setReturnNotes('');
      // update viewSale if currently viewing
      if (viewSale && viewSale.id === returnSale.id) {
        const updated = await db.sales.get(returnSale.id);
        if (updated) setViewSale(updated);
      }
    } catch (err: any) {
      error(err.message || "Erreur lors du retour de l'article.");
    }
  };

  // Submit Payment for Sale with remaining balance
  const handleSavePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentSale || !paymentSale.customerId || paymentAmount <= 0) return;
    try {
      await registerCustomerPaymentTransaction(
        paymentSale.customerId,
        paymentAmount,
        getMoroccoDateString(),
        paymentNote || `Versement pour Bon ${paymentSale.bonNumber}`,
        paymentSale.id
      );
      success(t.bons.paymentSuccess);
      setPaymentSale(null);
      setPaymentAmount(0);
      setPaymentNote('');
    } catch (err: any) {
      error(err.message || "Erreur lors du versement.");
    }
  };

  // 1. Save Edited Due Date (with Audit Log)
  const handleSaveDueDate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!viewSale || !viewSale.id || !editDueDateVal) return;
    if (!editDueDateReason.trim()) {
      error("Un motif est obligatoire pour modifier la date d'échéance.");
      return;
    }
    try {
      await updateSaleDueDateTransaction(viewSale.id, editDueDateVal, editDueDateReason);
      const updated = await db.sales.get(viewSale.id);
      if (updated) setViewSale(updated);
      success("Date d'échéance mise à jour et enregistrée dans l'historique.");
      setIsEditingDueDate(false);
      setEditDueDateReason('');
    } catch (err: any) {
      error(err.message || "Erreur lors de la mise à jour de l'échéance.");
    }
  };

  // 2. Save Edited Installments Schedule (with Audit Log)
  const handleSaveInstallments = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!viewSale || !viewSale.id) return;
    if (!editInstallmentsReason.trim()) {
      error("Un motif est obligatoire pour enregistrer l'échéancier.");
      return;
    }
    const sum = tempInstallments.reduce((s, i) => s + (Number(i.amount) || 0), 0);
    if (sum > viewSale.remainingAmount + 0.01) {
      error(`Le total (${sum} DH) ne peut pas dépasser le reste à payer (${viewSale.remainingAmount} DH).`);
      return;
    }
    for (const inst of tempInstallments) {
      if ((Number(inst.amount) || 0) <= 0) {
        error("Chaque tranche doit avoir un montant supérieur à 0.");
        return;
      }
    }
    try {
      await updateSaleInstallmentsTransaction(viewSale.id, tempInstallments, editInstallmentsReason);
      const updated = await db.sales.get(viewSale.id);
      if (updated) setViewSale(updated);
      success("Échéancier enregistré et consigné dans l'historique.");
      setIsEditingInstallments(false);
      setEditInstallmentsReason('');
    } catch (err: any) {
      error(err.message || "Erreur lors de la mise à jour de l'échéancier.");
    }
  };

  // Helper: Open Installments editor with current sale's installments
  const handleOpenInstallmentsEditor = () => {
    if (!viewSale) return;
    setTempInstallments(viewSale.installments ? JSON.parse(JSON.stringify(viewSale.installments)) : []);
    setEditInstallmentsReason('');
    setIsEditingInstallments(true);
  };

  // Helper: Auto-split inside editor
  const handleTempAutoSplit = () => {
    if (!viewSale || viewSale.remainingAmount <= 0) return;
    const count = Math.max(1, splitCount);
    const baseAmount = Math.floor(viewSale.remainingAmount / count);
    const remainder = viewSale.remainingAmount - (baseAmount * count);
    const intervalDays = splitFreq === 'weekly' ? 7 : splitFreq === 'biweekly' ? 15 : 30;

    const generated: Installment[] = [];
    for (let i = 0; i < count; i++) {
      const d = new Date();
      d.setDate(d.getDate() + intervalDays * (i + 1));
      const trancheAmount = i === count - 1 ? baseAmount + remainder : baseAmount;
      generated.push({
        id: `inst_${Date.now()}_${i}`,
        amount: trancheAmount,
        dueDate: getMoroccoDateString(d),
        paid: false,
        note: `Tranche ${i + 1}/${count}`,
      });
    }
    setTempInstallments(generated);
  };

  // Filter Sales
  const filteredSales = sales.filter((s) => {
    const q = search.toLowerCase().trim();
    const matchesSearch =
      !q ||
      s.bonNumber.toLowerCase().includes(q) ||
      s.customerName.toLowerCase().includes(q) ||
      (s.customerPhone && s.customerPhone.includes(q)) ||
      s.items.some((i) => i.name.toLowerCase().includes(q) || (i.imei && i.imei.includes(q)));

    const matchesDate = !dateFilter || s.date === dateFilter;

    let matchesStatus = true;
    if (statusFilter === 'paid') {
      matchesStatus = s.remainingAmount === 0 && s.status !== 'returned';
    } else if (statusFilter === 'credit') {
      matchesStatus = s.remainingAmount > 0;
    } else if (statusFilter === 'returned') {
      matchesStatus = s.status === 'returned' || s.status === 'partially_returned';
    }

    return matchesSearch && matchesDate && matchesStatus;
  });

  const paginatedSales = filteredSales.slice(0, visibleCount);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-neutral-900 border border-amber-500/20 shadow-xl shadow-black/80">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-gold-gradient tracking-tight flex items-center gap-2">
            <History className="w-6 h-6 text-amber-400 drop-shadow-[0_0_6px_rgba(212,175,55,0.4)]" />
            <span>{t.bons.title}</span>
          </h1>
          <p className="text-xs text-neutral-300 mt-1 font-medium">
            {language === 'ar' ? 'البحث، إعادة الطباعة، وتتبع الدفعات والكريدي لكل وصل' : 'Recherchez, réimprimez et gérez les retours ou versements pour chaque bon de vente'}
          </p>
        </div>
      </div>

      {/* Filter Strip */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 p-4 rounded-xl bg-neutral-900/70 border border-neutral-800">
        {/* Search + Camera Scan */}
        <div className="flex items-center gap-2 w-full md:w-96">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="N° Bon, Client, IMEI, Produit..."
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg ps-9 pe-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-hidden focus:border-amber-500/50"
            />
          </div>
          <ScanButton
            onScan={(code) => setSearch(code.trim())}
            mode="any"
            size="md"
          />
        </div>

        {/* Date & Status Filters */}
        <div className="flex items-center gap-2 w-full md:w-auto">
          {/* Date Picker */}
          <div className="relative">
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-hidden"
            />
            {dateFilter && (
              <button
                onClick={() => setDateFilter('')}
                className="text-[10px] text-amber-400 ps-1 hover:underline"
              >
                Effacer
              </button>
            )}
          </div>

          {/* Status buttons */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1 rounded transition ${
                statusFilter === 'all'
                  ? 'bg-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {t.all}
            </button>
            <button
              onClick={() => setStatusFilter('paid')}
              className={`px-2.5 py-1 rounded transition ${
                statusFilter === 'paid'
                  ? 'bg-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {t.bons.allPaid}
            </button>
            <button
              onClick={() => setStatusFilter('credit')}
              className={`px-2.5 py-1 rounded transition ${
                statusFilter === 'credit'
                  ? 'bg-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {t.bons.hasCredit}
            </button>
            <button
              onClick={() => setStatusFilter('returned')}
              className={`px-2.5 py-1 rounded transition ${
                statusFilter === 'returned'
                  ? 'bg-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {t.bons.returnedStatus}
            </button>
          </div>
        </div>
      </div>

      {/* Sales Table */}
      <div className="rounded-xl bg-neutral-900 border border-neutral-800 overflow-hidden">
        {filteredSales.length === 0 ? (
          <div className="py-16 text-center text-xs text-neutral-400 flex flex-col items-center justify-center gap-3">
            <History className="w-10 h-10 text-neutral-600" />
            <p className="text-sm font-medium text-neutral-300">
              {search
                ? (language === 'ar' ? 'ما كاين حتى بون بهاد البحث' : 'Aucun bon trouvé pour cette recherche')
                : (language === 'ar' ? 'ما كاين والو، دير أول عملية بيع فـ الكاسة' : 'Aucun bon de vente enregistré pour le moment')}
            </p>
          </div>
        ) : isMobileMode ? (
          /* Mobile Mode: Vertical Touch-Friendly Cards */
          <div className="p-3 space-y-3">
            {paginatedSales.map((sale) => (
              <div
                key={sale.id}
                className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-amber-400 text-sm">{sale.bonNumber}</span>
                    {sale.status === 'returned' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                        {t.bons.returnedStatus}
                      </span>
                    ) : sale.status === 'partially_returned' ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                        Partiel
                      </span>
                    ) : null}
                  </div>
                  <span className="text-xs text-neutral-400 font-mono">{sale.date}</span>
                </div>

                <div className="flex items-center justify-between border-b border-neutral-800/80 pb-2">
                  <div>
                    <div className="font-bold text-sm text-neutral-100">{sale.customerName}</div>
                    {sale.customerPhone && (
                      <div className="text-xs text-neutral-400 font-mono mt-0.5">{sale.customerPhone}</div>
                    )}
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 font-medium">
                    {sale.items.length} {language === 'ar' ? 'مواد' : 'articles'}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center py-2 bg-neutral-900/80 rounded-xl p-2 border border-neutral-800/60">
                  <div>
                    <div className="text-[10px] text-neutral-400 uppercase font-semibold">{t.total}</div>
                    <div className="font-mono font-bold text-sm text-neutral-100 mt-0.5">
                      {formatMAD(sale.totalAmount, language)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-emerald-400/90 uppercase font-semibold">{t.paid}</div>
                    <div className="font-mono font-bold text-sm text-emerald-400 mt-0.5">
                      {formatMAD(sale.paidAmount, language)}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-rose-400/90 uppercase font-semibold">{t.remaining}</div>
                    <div className="font-mono font-bold text-sm text-rose-400 mt-0.5">
                      {formatMAD(sale.remainingAmount, language)}
                    </div>
                  </div>
                </div>

                {/* Big Touch Action Buttons for Mobile */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => setViewSale(sale)}
                    className="py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-bold text-xs flex items-center justify-center gap-1.5 border border-neutral-700 transition active:scale-95 min-h-[44px]"
                  >
                    <Eye className="w-4 h-4 text-amber-400" />
                    <span>{language === 'ar' ? 'التفاصيل' : 'Détails'}</span>
                  </button>

                  <button
                    onClick={() => setReceiptPrintSale(sale)}
                    className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-sm min-h-[44px]"
                  >
                    <Printer className="w-4 h-4" />
                    <span>{language === 'ar' ? 'معاينة / طباعة' : 'Aperçu / Imprimer'}</span>
                  </button>

                  <button
                    onClick={() => handleSendWhatsApp(sale)}
                    className="col-span-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-sm min-h-[44px]"
                    title={t.whatsapp.sendReceipt}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{language === 'ar' ? 'إرسال تفاصيل الوصل بالواتساب' : 'Envoyer détails via WhatsApp'}</span>
                  </button>

                  {sale.remainingAmount > 0 && sale.customerId && (
                    <button
                      onClick={() => {
                        setPaymentSale(sale);
                        setPaymentAmount(sale.remainingAmount);
                      }}
                      className="col-span-2 py-2.5 px-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 min-h-[44px]"
                    >
                      <CreditCard className="w-4 h-4 text-emerald-400" />
                      <span>{t.bons.registerPayment} ({formatMAD(sale.remainingAmount, language)})</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Desktop Mode: Wide Table */
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs">
              <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] tracking-wider border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-4 text-start">{t.bons.bonNumber}</th>
                  <th className="py-3 px-4 text-start">{t.date}</th>
                  <th className="py-3 px-4 text-start">{t.bons.client}</th>
                  <th className="py-3 px-4 text-center">{t.bons.itemsCount}</th>
                  <th className="py-3 px-4 text-end">{t.total}</th>
                  <th className="py-3 px-4 text-end">{t.paid}</th>
                  <th className="py-3 px-4 text-end">{t.remaining}</th>
                  <th className="py-3 px-4 text-center">{t.status}</th>
                  <th className="py-3 px-4 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {paginatedSales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-4 font-mono font-bold text-amber-400 whitespace-nowrap">
                      {sale.bonNumber}
                    </td>
                    <td className="py-3 px-4 text-neutral-400 whitespace-nowrap">
                      <div>{sale.date}</div>
                      {sale.remainingAmount > 0 && sale.dueDate && (() => {
                        const todayStr = getMoroccoDateString();
                        const in7Days = new Date();
                        in7Days.setDate(in7Days.getDate() + 7);
                        const in7DaysStr = getMoroccoDateString(in7Days);
                        const isLate = sale.dueDate < todayStr;
                        const isSoon = !isLate && sale.dueDate <= in7DaysStr;
                        return (
                          <div className="mt-1">
                            <span
                              className={`inline-flex items-center gap-1 text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                                isLate
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-bold'
                                  : isSoon
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-medium'
                                  : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                              }`}
                            >
                              <Clock className="w-2.5 h-2.5" />
                              <span>{sale.dueDate}</span>
                            </span>
                          </div>
                        );
                      })()}
                    </td>
                    <td className="py-3 px-4 font-semibold text-neutral-200">
                      <div>{sale.customerName}</div>
                      {sale.customerPhone && (
                        <div className="text-[10px] text-neutral-500 font-mono">
                          {sale.customerPhone}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center font-mono text-neutral-300">
                      {sale.items.length}
                    </td>
                    <td className="py-3 px-4 text-end font-mono font-bold text-neutral-100 whitespace-nowrap">
                      {formatMAD(sale.totalAmount, language)}
                    </td>
                    <td className="py-3 px-4 text-end font-mono text-emerald-400 whitespace-nowrap">
                      {formatMAD(sale.paidAmount, language)}
                    </td>
                    <td className="py-3 px-4 text-end font-mono whitespace-nowrap">
                      {sale.remainingAmount > 0 ? (
                        <span className="font-bold text-rose-400">
                          {formatMAD(sale.remainingAmount, language)}
                        </span>
                      ) : (
                        <span className="text-emerald-400 font-medium">0 DH</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      {sale.status === 'returned' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                          Retourné
                        </span>
                      ) : sale.status === 'partially_returned' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                          Partiel Retour
                        </span>
                      ) : sale.remainingAmount > 0 ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                          Crédit
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          Soldé
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setViewSale(sale)}
                          className="p-1 rounded text-neutral-400 hover:text-amber-400 transition"
                          title="Détails du bon"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setReceiptPrintSale(sale)}
                          className="p-1 rounded text-neutral-400 hover:text-amber-400 transition"
                          title={language === 'ar' ? 'معاينة وطباعة الوصل (58mm/80mm/A4)' : 'Aperçu & Imprimer Reçu (58mm/80mm/A4)'}
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleSendWhatsApp(sale)}
                          className="p-1 rounded text-neutral-400 hover:text-emerald-400 transition"
                          title={language === 'ar' ? 'إرسال تفاصيل الوصل بالواتساب' : 'Envoyer détails via WhatsApp'}
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        {(sale.hasWarranty || (sale.warrantyMonths && sale.warrantyMonths > 0)) && (
                          <button
                            onClick={() => handlePrintWarrantyPdf(sale)}
                            className="p-1 rounded text-neutral-400 hover:text-emerald-400 transition"
                            title="Imprimer Certificat de Garantie A4"
                          >
                            <ShieldCheck className="w-4 h-4" />
                          </button>
                        )}
                        {sale.remainingAmount > 0 && sale.customerId && (
                          <button
                            onClick={() => {
                              setPaymentSale(sale);
                              setPaymentAmount(sale.remainingAmount);
                            }}
                            className="p-1 rounded text-neutral-400 hover:text-emerald-400 transition"
                            title={t.bons.registerPayment}
                          >
                            <CreditCard className="w-4 h-4" />
                          </button>
                        )}
                        {can('delete_records') && (
                          <button
                            onClick={() => setDeleteSaleTarget(sale)}
                            className="p-1 rounded text-neutral-400 hover:text-rose-400 transition"
                            title={language === 'ar' ? 'حذف البون' : 'Supprimer le bon'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Load More Pagination (Partie 1 #11) */}
      {filteredSales.length > visibleCount && (
        <div className="flex justify-center pt-2">
          <button
            type="button"
            onClick={() => setVisibleCount((prev) => prev + 25)}
            className="px-5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-amber-500/30 text-amber-400 text-xs font-bold transition"
          >
            {language === 'ar'
              ? `عرض المزيد (${filteredSales.length - visibleCount} متبقية)`
              : `Voir plus (${filteredSales.length - visibleCount} restants)`}
          </button>
        </div>
      )}

      {/* Detailed Bon View Modal */}
      {viewSale && (
        <Modal
          isOpen={!!viewSale}
          onClose={() => setViewSale(null)}
          title={`Détail Bon : ${viewSale.bonNumber}`}
          maxWidth="2xl"
        >
          <div className="space-y-4 text-xs">
            {/* Header info */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-lg bg-neutral-950 border border-neutral-800">
              <div>
                <span className="text-neutral-500 block">Date</span>
                <span className="font-semibold text-neutral-200">{viewSale.date}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Client</span>
                <span className="font-semibold text-neutral-200">{viewSale.customerName}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Règlement</span>
                <span className="font-semibold text-neutral-200 capitalize">{viewSale.paymentType}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Garantie Magasin</span>
                <span className={`font-semibold ${(viewSale.hasWarranty || (viewSale.warrantyMonths && viewSale.warrantyMonths > 0)) ? 'text-amber-400' : 'text-neutral-500'}`}>
                  {(viewSale.hasWarranty || (viewSale.warrantyMonths && viewSale.warrantyMonths > 0))
                    ? `${viewSale.warrantyMonths} mois`
                    : 'Sans garantie'}
                </span>
              </div>
            </div>

            {/* Items list with individual Return action */}
            <div>
              <h4 className="font-bold text-neutral-200 mb-2">Articles vendus</h4>
              <div className="space-y-2">
                {viewSale.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-neutral-800/60 border border-neutral-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-neutral-100 flex items-center gap-2">
                        <span>{item.name}</span>
                        {item.isReturned && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-400">
                            RETOURNÉ
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-neutral-400 mt-0.5 flex items-center gap-3">
                        {item.imei && <span className="font-mono text-amber-300">IMEI: {item.imei}</span>}
                        <span>Qté: {item.quantity}</span>
                        <span>@ {formatMAD(item.price, language)}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-neutral-100">
                        {formatMAD(item.price * item.quantity, language)}
                      </span>
                      {can('delete_records') && !item.isReturned && viewSale.status !== 'returned' && (
                        <button
                          type="button"
                          onClick={() => {
                            setReturnSale(viewSale);
                            setReturnItemIndex(idx);
                          }}
                          className="px-2 py-1 text-[11px] text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded border border-rose-500/30 transition flex items-center gap-1"
                          title="Retourner cet article"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Retour</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary with Discount Support */}
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-1.5 text-xs font-mono">
              {viewSale.discountAmount && viewSale.discountAmount > 0 ? (
                <div className="flex justify-between items-center text-neutral-400 pb-1 border-b border-neutral-800/80">
                  <span>Sous-total : {formatMAD(viewSale.subtotal ?? (viewSale.totalAmount + viewSale.discountAmount), language)}</span>
                  <span className="text-rose-400 font-semibold">
                    Remise {viewSale.discountType === 'percent' && viewSale.discountValue ? `(${viewSale.discountValue}%)` : ''} : - {formatMAD(viewSale.discountAmount, language)}
                  </span>
                </div>
              ) : null}

              <div className="flex justify-between items-center pt-0.5">
                <span className="text-neutral-300 font-bold">Total Net : <strong className="text-amber-400">{formatMAD(viewSale.totalAmount, language)}</strong></span>
                <span className="text-emerald-400">Payé : <strong>{formatMAD(viewSale.paidAmount, language)}</strong></span>
                <span className={viewSale.remainingAmount > 0 ? 'text-rose-400 font-bold' : 'text-neutral-400'}>
                  Reste : <strong>{formatMAD(viewSale.remainingAmount, language)}</strong>
                </span>
              </div>
            </div>

            {viewSale.notes && (
              <div className="p-2.5 rounded bg-neutral-950 text-neutral-400 text-xs italic">
                Notes : {viewSale.notes}
              </div>
            )}

            {/* Bottom Actions */}
            <div className="flex flex-wrap justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setReceiptPrintSale(viewSale)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs"
              >
                <Printer className="w-4 h-4" />
                <span>
                  {language === 'ar'
                    ? 'معاينة وطباعة (58mm / 80mm / A4)'
                    : 'Aperçu & Imprimer (58mm / 80mm / A4)'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handlePrintPdf(viewSale)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 border border-amber-500/30 font-bold text-xs"
              >
                <Printer className="w-4 h-4" />
                <span>PDF (A4)</span>
              </button>

              <button
                type="button"
                onClick={() => handleSendWhatsApp(viewSale)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs shadow-sm transition active:scale-95"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{language === 'ar' ? 'إرسال بالواتساب' : 'Envoyer par WhatsApp'}</span>
              </button>

              {(viewSale.hasWarranty || (viewSale.warrantyMonths && viewSale.warrantyMonths > 0)) && (
                <button
                  type="button"
                  onClick={() => handlePrintWarrantyPdf(viewSale)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Imprimer Garantie (A4)</span>
                </button>
              )}
            </div>
          </div>
        </Modal>
      )}

      {/* Return Item Confirm Modal */}
      {returnSale && returnItemIndex !== null && (
        <Modal
          isOpen={true}
          onClose={() => {
            setReturnSale(null);
            setReturnItemIndex(null);
          }}
          title={t.bons.returnItems}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300">
              <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
              <div>
                <p className="font-semibold">Confirmation de retour article</p>
                <p className="mt-1 text-neutral-300 text-[11px] leading-relaxed">
                  {t.bons.returnConfirm}
                </p>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800">
              <span className="text-neutral-400">Article concerné : </span>
              <span className="font-bold text-neutral-100">
                {returnSale.items[returnItemIndex]?.name}
              </span>
              {returnSale.items[returnItemIndex]?.imei && (
                <div className="font-mono text-amber-400 mt-1">
                  IMEI: {returnSale.items[returnItemIndex]?.imei}
                </div>
              )}
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">Motif du retour</label>
              <input
                type="text"
                value={returnNotes}
                onChange={(e) => setReturnNotes(e.target.value)}
                placeholder="ex: Changement d'avis client, défaut appareil..."
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setReturnSale(null);
                  setReturnItemIndex(null);
                }}
                className="px-3 py-2 rounded-lg bg-neutral-800 text-neutral-300"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={handleConfirmReturn}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 font-bold text-white shadow-sm"
              >
                Confirmer le retour
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Register Payment Modal */}
      {paymentSale && (
        <Modal
          isOpen={true}
          onClose={() => setPaymentSale(null)}
          title={`Encaisser un Paiement - Bon ${paymentSale.bonNumber}`}
          maxWidth="md"
        >
          <form onSubmit={handleSavePayment} className="space-y-4 text-xs">
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 flex justify-between items-center font-mono">
              <span className="text-neutral-400">Solde restant sur ce bon :</span>
              <span className="font-bold text-rose-400 text-sm">
                {formatMAD(paymentSale.remainingAmount, language)}
              </span>
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">
                {t.bons.paymentAmount} (DH) *
              </label>
              <input
                type="number"
                min="1"
                step="0.01"
                max={paymentSale.remainingAmount}
                required
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100 font-mono font-bold text-emerald-400"
              />
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">
                Note / Référence versement
              </label>
              <input
                type="text"
                value={paymentNote}
                onChange={(e) => setPaymentNote(e.target.value)}
                placeholder="ex: Espèces reçu au comptoir..."
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-neutral-100"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPaymentSale(null)}
                className="px-3 py-2 bg-neutral-800 text-neutral-300 rounded-lg"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-sm"
              >
                Enregistrer le versement
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Thermal & Browser Receipt Preview / Print Modal */}
      <ReceiptPrintModal
        isOpen={!!receiptPrintSale}
        onClose={() => setReceiptPrintSale(null)}
        sale={receiptPrintSale}
      />

      {/* Delete Bon Confirm Dialog (Owner only) */}
      <ConfirmDialog
        isOpen={!!deleteSaleTarget}
        onClose={() => setDeleteSaleTarget(null)}
        onConfirm={async () => {
          if (!deleteSaleTarget?.id) return;
          try {
            await deleteSaleTransaction(deleteSaleTarget.id);
            success(`Bon ${deleteSaleTarget.bonNumber} supprimé.`);
            if (viewSale?.id === deleteSaleTarget.id) setViewSale(null);
            setDeleteSaleTarget(null);
          } catch (err: any) {
            error(err.message || 'Erreur lors de la suppression du bon.');
          }
        }}
        title={`Supprimer le bon ${deleteSaleTarget?.bonNumber || ''}`}
        message="Cette action supprimera le bon, remettra en stock les articles non retournés et ajustera le crédit client."
        isDestructive={true}
      />
    </div>
  );
};
