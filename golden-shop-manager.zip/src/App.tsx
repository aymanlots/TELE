import React, { useState, useEffect, Suspense } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, initializeDatabaseIfNeeded, getStoreSettings, clearAllData } from './db';
import { AppTab } from './types';
import { I18nProvider, useI18n } from './i18n';
import { ThemeProvider } from './lib/theme';
import { ViewModeProvider, useViewMode } from './lib/viewMode';
import { ToastProvider } from './components/Toast';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { OfflineIndicator } from './components/OfflineIndicator';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { AccessAuthProvider, useAccessAuth } from './lib/accessAuth';
import { LockScreen } from './components/LockScreen';

// Lazy-loaded Pages (Task E1)
const DashboardPage = React.lazy(() => import('./pages/DashboardPage').then((m) => ({ default: m.DashboardPage })));
const StockPage = React.lazy(() => import('./pages/StockPage').then((m) => ({ default: m.StockPage })));
const PosPage = React.lazy(() => import('./pages/PosPage').then((m) => ({ default: m.PosPage })));
const BonsHistoryPage = React.lazy(() => import('./pages/BonsHistoryPage').then((m) => ({ default: m.BonsHistoryPage })));
const WarrantySavPage = React.lazy(() => import('./pages/WarrantySavPage').then((m) => ({ default: m.WarrantySavPage })));
const CustomersPage = React.lazy(() => import('./pages/CustomersPage').then((m) => ({ default: m.CustomersPage })));
const SuppliersPage = React.lazy(() => import('./pages/SuppliersPage').then((m) => ({ default: m.SuppliersPage })));
const SettingsPage = React.lazy(() => import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })));
const RepairsPage = React.lazy(() => import('./pages/RepairsPage').then((m) => ({ default: m.RepairsPage })));
const SparePartsPage = React.lazy(() => import('./pages/SparePartsPage').then((m) => ({ default: m.SparePartsPage })));
const ExpensesPage = React.lazy(() => import('./pages/ExpensesPage').then((m) => ({ default: m.ExpensesPage })));
const ReportsPage = React.lazy(() => import('./pages/ReportsPage').then((m) => ({ default: m.ReportsPage })));

export function AppContent() {
  const { language } = useI18n();
  const { isMobileMode } = useViewMode();
  const { isUnlocked, canAccess, isOwnerMode } = useAccessAuth();
  const [activeTab, setActiveTab] = useState<AppTab>(() => (isOwnerMode ? 'dashboard' : 'pos'));
  const [isSidebarOpenMobile, setIsSidebarOpenMobile] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [navParams, setNavParams] = useState<any>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [hasBackupWarning, setHasBackupWarning] = useState(false);

  // Enforce role access if activeTab is restricted (Task C2)
  useEffect(() => {
    if (!canAccess(activeTab)) {
      setActiveTab('pos');
    }
  }, [activeTab, canAccess]);

  // Initialize DB on first mount
  useEffect(() => {
    async function init() {
      await initializeDatabaseIfNeeded();
      if (navigator.storage && navigator.storage.persist) {
        try {
          await navigator.storage.persist();
        } catch {}
      }
      const settings = await getStoreSettings();
      if (settings.lastBackupDate) {
        const last = new Date(settings.lastBackupDate);
        const diffDays = Math.floor((Date.now() - last.getTime()) / (1000 * 60 * 60 * 24));
        setHasBackupWarning(diffDays >= 7);
      } else {
        setHasBackupWarning(true);
      }
      setIsInitialized(true);
    }
    init();
  }, []);

  // Global keydown shortcut for search (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Real-time store branding from settings via useLiveQuery
  const storeSettings = useLiveQuery(async () => {
    try {
      const record = await db.settings.get('store_settings');
      return record?.value;
    } catch {
      return null;
    }
  }, []);

  const storeName = storeSettings?.storeName?.trim() || '';
  const storeLogo = storeSettings?.logo;
  const fallbackName = language === 'ar' ? 'متجري' : 'Mon Magasin';
  const displayName = storeName || fallbackName;

  // Synchronize document.title dynamically with zero reload
  useEffect(() => {
    document.title = displayName;
  }, [displayName]);

  // Sidebar badge queries (resilient to avoid throwing before IndexedDB initialization)
  const lowStockCount =
    useLiveQuery(async () => {
      try {
        const prods = await db.products.toArray();
        return prods.filter((p) => !p.deleted_at && (p.quantity ?? 0) <= (p.minAlertQty ?? 5)).length;
      } catch {
        return 0;
      }
    }, []) ?? 0;

  const openSavCount =
    useLiveQuery(async () => {
      try {
        const tickets = await db.savTickets.toArray();
        return tickets.filter((t) => !t.deleted_at && t.status !== 'resolved').length;
      } catch {
        return 0;
      }
    }, []) ?? 0;

  const openRepairsCount =
    useLiveQuery(async () => {
      try {
        const repairs = await db.repairs.toArray();
        return repairs.filter((r) => !r.deleted_at && r.status !== 'delivered').length;
      } catch {
        return 0;
      }
    }, []) ?? 0;

  const lowSparePartsCount =
    useLiveQuery(async () => {
      try {
        const parts = await db.spareParts.toArray();
        return parts.filter((p) => !p.deleted_at && p.quantity <= (p.minAlertQty ?? 2)).length;
      } catch {
        return 0;
      }
    }, []) ?? 0;

  // Handle navigation from child pages or search modal (with role protection - Task C2)
  const handleNavigate = (tab: AppTab, params?: any) => {
    if (!canAccess(tab)) {
      setActiveTab('pos');
      return;
    }
    setActiveTab(tab);
    setNavParams(params || null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!isInitialized) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-neutral-950 text-neutral-100 gap-4">
        <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center font-bold text-amber-400 text-lg animate-pulse uppercase">
          {storeName ? storeName.charAt(0).toUpperCase() : 'M'}
        </div>
        <p className="text-xs text-neutral-400 font-medium">Chargement...</p>
      </div>
    );
  }

  if (!isUnlocked) {
    return <LockScreen />;
  }

  const effectiveTab: AppTab = canAccess(activeTab) ? activeTab : 'pos';

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col">
      {/* Offline Connectivity Status Pill */}
      <OfflineIndicator />

      {/* Global Search Dialog */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={handleNavigate}
      />

      <div className="flex-1 flex w-full">
        {/* Responsive Desktop Sidebar (Only in Desktop Mode) */}
        {!isMobileMode && (
          <Sidebar
            activeTab={effectiveTab}
            onSelectTab={(tab) => handleNavigate(tab)}
            isOpen={isSidebarOpenMobile}
            onCloseMobile={() => setIsSidebarOpenMobile(false)}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
            lowStockCount={lowStockCount}
            lowSparePartsCount={lowSparePartsCount}
            openSavCount={openSavCount}
            openRepairsCount={openRepairsCount}
            storeName={storeName}
            storeLogo={storeLogo}
          />
        )}

        {/* Main Work Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Top Bar Header */}
          <Header
            onToggleSidebar={() => setIsSidebarOpenMobile((prev) => !prev)}
            onOpenSearch={() => setIsSearchOpen(true)}
            activeTab={effectiveTab}
            hasBackupWarning={hasBackupWarning}
            onNavigateSettings={() => handleNavigate('settings')}
            storeName={storeName}
            storeLogo={storeLogo}
          />

          {/* Page Content Viewport */}
          <main className={`flex-1 ${isMobileMode ? 'p-3 sm:p-5 pb-28 max-w-4xl' : 'p-4 sm:p-6 lg:p-8 max-w-7xl'} w-full mx-auto`}>
            <Suspense
              fallback={
                <div className="py-20 flex flex-col items-center justify-center gap-3 text-neutral-400">
                  <div className="w-8 h-8 rounded-lg border-2 border-amber-500 border-t-transparent animate-spin" />
                  <span className="text-xs font-medium">Chargement du module...</span>
                </div>
              }
            >
              {effectiveTab === 'dashboard' && canAccess('dashboard') && <DashboardPage onNavigate={handleNavigate} />}
              {effectiveTab === 'stock' && (
                <StockPage
                  initialSearch={navParams?.search}
                  initialAction={navParams?.action}
                />
              )}
              {effectiveTab === 'spare-parts' && (
                <SparePartsPage
                  initialSearch={navParams?.search}
                  initialAction={navParams?.action}
                />
              )}
              {effectiveTab === 'pos' && (
                <PosPage onNavigateToBons={() => handleNavigate('bons')} />
              )}
              {effectiveTab === 'bons' && (
                <BonsHistoryPage initialSearch={navParams?.search} />
              )}
              {effectiveTab === 'repairs' && (
                <RepairsPage initialSearch={navParams?.search} />
              )}
              {effectiveTab === 'expenses' && canAccess('expenses') && <ExpensesPage />}
              {effectiveTab === 'reports' && canAccess('reports') && <ReportsPage initialSubTab="overview" />}
              {effectiveTab === 'activity' && canAccess('activity') && <ReportsPage initialSubTab="activity" />}
              {effectiveTab === 'warranty' && <WarrantySavPage />}
              {effectiveTab === 'customers' && (
                <CustomersPage initialSearch={navParams?.search} />
              )}
              {effectiveTab === 'suppliers' && canAccess('suppliers') && <SuppliersPage />}
              {effectiveTab === 'settings' && canAccess('settings') && (
                <SettingsPage
                  onSettingsSaved={async () => {
                    const settings = await getStoreSettings();
                    if (settings.lastBackupDate) {
                      const last = new Date(settings.lastBackupDate);
                      const diffDays = Math.floor((Date.now() - last.getTime()) / (1000 * 60 * 60 * 24));
                      setHasBackupWarning(diffDays >= 7);
                    }
                  }}
                />
              )}
            </Suspense>
          </main>
        </div>
      </div>

      {/* Mobile Mode Bottom Navigation Bar */}
      {isMobileMode && (
        <BottomNav
          activeTab={effectiveTab}
          onSelectTab={handleNavigate}
          lowStockCount={lowStockCount}
          lowSparePartsCount={lowSparePartsCount}
          openSavCount={openSavCount}
          openRepairsCount={openRepairsCount}
        />
      )}
    </div>
  );
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col items-center justify-center p-6 text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xl mb-4 uppercase">
            M
          </div>
          <h2 className="text-base font-bold text-neutral-100 mb-2">
            Mon Magasin
          </h2>
          <p className="text-xs text-neutral-400 max-w-sm mb-6 leading-relaxed">
            Une erreur inattendue est survenue lors de l'accès aux données locales. Cliquez ci-dessous pour recharger l'application.
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold rounded-lg text-xs transition"
            >
              Recharger l'application
            </button>
            <button
              onClick={async () => {
                try {
                  await clearAllData();
                  window.location.reload();
                } catch {
                  window.location.reload();
                }
              }}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-medium rounded-lg text-xs transition"
            >
              Réinitialiser les données
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <ViewModeProvider>
          <I18nProvider>
            <AccessAuthProvider>
              <ToastProvider>
                <AppContent />
              </ToastProvider>
            </AccessAuthProvider>
          </I18nProvider>
        </ViewModeProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
