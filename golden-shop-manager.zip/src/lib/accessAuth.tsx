import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import {
  REMEMBER_DEVICE_MS,
  MAX_FAILED_ATTEMPTS,
  LOCKOUT_DURATION_MS,
  DEFAULT_AUTO_LOCK_MINUTES,
} from '../config/access';
import { db, getStoreSettings } from '../db';
import { UserRole, AppTab } from '../types';
import {
  hashPinPBKDF2,
  verifyPinPBKDF2,
  setSessionPinSecret,
} from './cryptoUtils';
import {
  Permission,
  hasPermission,
  isOwnerRole,
  canAccessTab,
} from './permissions';

interface AccessAuthContextType {
  isUnlocked: boolean;
  isPinConfigured: boolean;
  isLockedOut: boolean;
  lockoutSecondsLeft: number;
  failedAttempts: number;
  maxAttempts: number;
  userRole: UserRole;
  activeRole: UserRole;
  isOwnerMode: boolean;
  can: (permission: Permission) => boolean;
  canAccess: (tab: AppTab) => boolean;
  setUserRole: (role: UserRole) => void;
  setupInitialPin: (newPin: string) => Promise<{ success: boolean; error?: string }>;
  verifyPin: (pin: string, role?: UserRole) => Promise<{ success: boolean; remainingAttempts: number; lockedOut: boolean }>;
  changePin: (currentPin: string, newPin: string) => Promise<{ success: boolean; error?: 'wrong_current' | 'invalid_format' }>;
  lock: () => void;
  autoLockMinutes: number;
  setAutoLockMinutesState: (mins: number) => void;
}

const AccessAuthContext = createContext<AccessAuthContextType | null>(null);

const STORAGE_KEYS = {
  VERIFIED_AT: 'golden_access_verified_at',
  SESSION_UNLOCKED: 'golden_access_session_unlocked',
  FAILED_ATTEMPTS: 'golden_access_failed_attempts',
  LOCKOUT_UNTIL: 'golden_access_lockout_until',
  PIN_PBKDF2: 'golden_access_pin_pbkdf2',
  LEGACY_CUSTOM_SHA256: 'golden_access_custom_sha256',
  USER_ROLE: 'golden_shop_user_role',
};

const IDB_SECURITY_KEY = 'access_security_state';

interface PersistedSecurityState {
  pinPbkdf2?: string;
  failedAttempts?: number;
  lockoutUntil?: number;
}

async function readIdbSecurityState(): Promise<PersistedSecurityState> {
  try {
    const rec = await db.settings.get(IDB_SECURITY_KEY);
    if (rec && rec.value && typeof rec.value === 'object') {
      return rec.value as PersistedSecurityState;
    }
  } catch {}
  return {};
}

async function writeIdbSecurityState(patch: Partial<PersistedSecurityState>): Promise<void> {
  try {
    const current = await readIdbSecurityState();
    await db.settings.put({
      key: IDB_SECURITY_KEY,
      value: { ...current, ...patch },
      updated_at: new Date().toISOString(),
    });
  } catch {}
}

/**
 * Legacy SHA-256 helper for transparent one-time migration of existing custom PINs
 */
export async function computeSha256(plainText: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(plainText.trim());
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export const AccessAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isPinConfigured, setIsPinConfigured] = useState<boolean>(() => {
    try {
      const pbkdf2 = localStorage.getItem(STORAGE_KEYS.PIN_PBKDF2);
      const legacySha = localStorage.getItem(STORAGE_KEYS.LEGACY_CUSTOM_SHA256);
      return Boolean((pbkdf2 && pbkdf2.startsWith('pbkdf2:')) || (legacySha && legacySha.length === 64));
    } catch {
      return false;
    }
  });

  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => {
    try {
      const verifiedAtStr = localStorage.getItem(STORAGE_KEYS.VERIFIED_AT);
      const sessionUnlocked = localStorage.getItem(STORAGE_KEYS.SESSION_UNLOCKED);
      const pbkdf2 = localStorage.getItem(STORAGE_KEYS.PIN_PBKDF2);
      const legacySha = localStorage.getItem(STORAGE_KEYS.LEGACY_CUSTOM_SHA256);
      if (!pbkdf2 && !legacySha) {
        return false; // Must set up initial PIN on first launch
      }
      if (!verifiedAtStr || sessionUnlocked !== 'true') {
        return false;
      }
      const verifiedAt = Number(verifiedAtStr);
      if (Date.now() - verifiedAt < REMEMBER_DEVICE_MS) {
        return true;
      }
      localStorage.removeItem(STORAGE_KEYS.SESSION_UNLOCKED);
      return false;
    } catch {
      return false;
    }
  });

  const [userRole, setUserRoleState] = useState<UserRole>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER_ROLE);
      return saved === 'employee' ? 'employee' : 'owner';
    } catch {
      return 'owner';
    }
  });

  const setUserRole = useCallback((role: UserRole) => {
    setUserRoleState(role);
    try {
      localStorage.setItem(STORAGE_KEYS.USER_ROLE, role);
      localStorage.setItem(
        'golden_shop_user_name',
        role === 'owner' ? 'Propriétaire' : 'Employé'
      );
    } catch {}
  }, []);

  const [failedAttempts, setFailedAttempts] = useState<number>(() => {
    try {
      return Number(localStorage.getItem(STORAGE_KEYS.FAILED_ATTEMPTS)) || 0;
    } catch {
      return 0;
    }
  });

  const [lockoutSecondsLeft, setLockoutSecondsLeft] = useState<number>(0);
  const [autoLockMinutes, setAutoLockMinutesState] = useState<number>(DEFAULT_AUTO_LOCK_MINUTES);
  const lastActivityRef = useRef<number>(Date.now());

  // Sync security state (PIN hash + lockout persistence) between IndexedDB and localStorage
  useEffect(() => {
    async function syncSecurityState() {
      try {
        const settings = await getStoreSettings();
        if (settings.autoLockMinutes !== undefined) {
          setAutoLockMinutesState(settings.autoLockMinutes);
        }

        const idbState = await readIdbSecurityState();
        const localPbkdf2 = localStorage.getItem(STORAGE_KEYS.PIN_PBKDF2);

        if (!localPbkdf2 && idbState.pinPbkdf2) {
          localStorage.setItem(STORAGE_KEYS.PIN_PBKDF2, idbState.pinPbkdf2);
          setIsPinConfigured(true);
        } else if (localPbkdf2 && !idbState.pinPbkdf2) {
          await writeIdbSecurityState({ pinPbkdf2: localPbkdf2 });
          setIsPinConfigured(true);
        } else if (localPbkdf2 || idbState.pinPbkdf2) {
          setIsPinConfigured(true);
        }

        // Restore lockout or failedAttempts from IndexedDB if localStorage was partially cleared
        const localLockout = Number(localStorage.getItem(STORAGE_KEYS.LOCKOUT_UNTIL)) || 0;
        const idbLockout = idbState.lockoutUntil || 0;
        const effectiveLockout = Math.max(localLockout, idbLockout);

        if (effectiveLockout > Date.now()) {
          localStorage.setItem(STORAGE_KEYS.LOCKOUT_UNTIL, String(effectiveLockout));
          setLockoutSecondsLeft(Math.ceil((effectiveLockout - Date.now()) / 1000));
        }

        const localAttempts = Number(localStorage.getItem(STORAGE_KEYS.FAILED_ATTEMPTS)) || 0;
        const idbAttempts = idbState.failedAttempts || 0;
        const effectiveAttempts = Math.max(localAttempts, idbAttempts);
        if (effectiveAttempts > 0) {
          setFailedAttempts(effectiveAttempts);
          localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, String(effectiveAttempts));
        }
      } catch {}
    }
    syncSecurityState();
  }, []);

  // Check ongoing lockout every second
  useEffect(() => {
    function evaluateLockout() {
      try {
        const lockoutUntilStr = localStorage.getItem(STORAGE_KEYS.LOCKOUT_UNTIL);
        if (lockoutUntilStr) {
          const lockoutUntil = Number(lockoutUntilStr);
          const diffMs = lockoutUntil - Date.now();
          if (diffMs > 0) {
            setLockoutSecondsLeft(Math.ceil(diffMs / 1000));
            return true;
          } else {
            localStorage.removeItem(STORAGE_KEYS.LOCKOUT_UNTIL);
            localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, '0');
            writeIdbSecurityState({ lockoutUntil: 0, failedAttempts: 0 });
            setFailedAttempts(0);
            setLockoutSecondsLeft(0);
            return false;
          }
        }
      } catch {}
      setLockoutSecondsLeft(0);
      return false;
    }

    evaluateLockout();
    const interval = setInterval(evaluateLockout, 1000);
    return () => clearInterval(interval);
  }, []);

  // Lock function
  const lock = useCallback(() => {
    setIsUnlocked(false);
    try {
      localStorage.setItem(STORAGE_KEYS.SESSION_UNLOCKED, 'false');
    } catch {}
  }, []);

  // Auto-lock on inactivity
  useEffect(() => {
    if (!isUnlocked || autoLockMinutes <= 0) return;

    lastActivityRef.current = Date.now();
    const handleUserInteraction = () => {
      lastActivityRef.current = Date.now();
    };

    const events = ['pointerdown', 'keydown', 'touchstart', 'scroll', 'wheel'];
    events.forEach((ev) => window.addEventListener(ev, handleUserInteraction, { passive: true }));

    const checkInterval = setInterval(() => {
      const inactiveMs = Date.now() - lastActivityRef.current;
      const thresholdMs = autoLockMinutes * 60 * 1000;
      if (inactiveMs >= thresholdMs) {
        lock();
      }
    }, 5000);

    return () => {
      events.forEach((ev) => window.removeEventListener(ev, handleUserInteraction));
      clearInterval(checkInterval);
    };
  }, [isUnlocked, autoLockMinutes, lock]);

  // First-launch PIN configuration (PBKDF2 with random salt, 120,000 iterations)
  const setupInitialPin = async (newPin: string): Promise<{ success: boolean; error?: string }> => {
    const clean = newPin.trim();
    if (!/^\d{6}$/.test(clean)) {
      return { success: false, error: 'invalid_format' };
    }

    const pbkdf2Record = await hashPinPBKDF2(clean);
    const now = Date.now();
    try {
      localStorage.setItem(STORAGE_KEYS.PIN_PBKDF2, pbkdf2Record);
      localStorage.setItem(STORAGE_KEYS.VERIFIED_AT, String(now));
      localStorage.setItem(STORAGE_KEYS.SESSION_UNLOCKED, 'true');
      localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, '0');
      localStorage.removeItem(STORAGE_KEYS.LOCKOUT_UNTIL);
    } catch {}

    await writeIdbSecurityState({
      pinPbkdf2: pbkdf2Record,
      failedAttempts: 0,
      lockoutUntil: 0,
    });

    setSessionPinSecret(clean);
    setIsPinConfigured(true);
    setFailedAttempts(0);
    setLockoutSecondsLeft(0);
    setIsUnlocked(true);
    return { success: true };
  };

  // Verify entered PIN against PBKDF2 hash (or migrate legacy SHA-256 hash)
  const verifyPin = async (
    pin: string,
    role?: UserRole
  ): Promise<{ success: boolean; remainingAttempts: number; lockedOut: boolean }> => {
    const idbState = await readIdbSecurityState();
    const localLockout = Number(localStorage.getItem(STORAGE_KEYS.LOCKOUT_UNTIL)) || 0;
    const effectiveLockout = Math.max(localLockout, idbState.lockoutUntil || 0);

    if (effectiveLockout > Date.now()) {
      return { success: false, remainingAttempts: 0, lockedOut: true };
    }

    const pbkdf2Record = localStorage.getItem(STORAGE_KEYS.PIN_PBKDF2) || idbState.pinPbkdf2;
    let isMatch = false;

    if (pbkdf2Record && pbkdf2Record.startsWith('pbkdf2:')) {
      isMatch = await verifyPinPBKDF2(pin, pbkdf2Record);
    } else {
      // Check legacy custom SHA-256 hash if present, and upgrade to PBKDF2 on match
      const legacySha = localStorage.getItem(STORAGE_KEYS.LEGACY_CUSTOM_SHA256);
      if (legacySha && legacySha.length === 64) {
        const inputSha = await computeSha256(pin);
        if (inputSha === legacySha) {
          isMatch = true;
          const upgraded = await hashPinPBKDF2(pin);
          localStorage.setItem(STORAGE_KEYS.PIN_PBKDF2, upgraded);
          localStorage.removeItem(STORAGE_KEYS.LEGACY_CUSTOM_SHA256);
          await writeIdbSecurityState({ pinPbkdf2: upgraded });
        }
      }
    }

    if (isMatch) {
      const now = Date.now();
      try {
        localStorage.setItem(STORAGE_KEYS.VERIFIED_AT, String(now));
        localStorage.setItem(STORAGE_KEYS.SESSION_UNLOCKED, 'true');
        localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, '0');
        localStorage.removeItem(STORAGE_KEYS.LOCKOUT_UNTIL);
      } catch {}

      await writeIdbSecurityState({ failedAttempts: 0, lockoutUntil: 0 });
      setSessionPinSecret(pin);
      if (role) {
        setUserRole(role);
      }
      setFailedAttempts(0);
      setLockoutSecondsLeft(0);
      lastActivityRef.current = now;
      setIsUnlocked(true);

      return { success: true, remainingAttempts: MAX_FAILED_ATTEMPTS, lockedOut: false };
    } else {
      const currentFailed = Math.max(failedAttempts, idbState.failedAttempts || 0);
      const nextAttempts = currentFailed + 1;
      setFailedAttempts(nextAttempts);

      if (nextAttempts >= MAX_FAILED_ATTEMPTS) {
        const lockoutUntil = Date.now() + LOCKOUT_DURATION_MS;
        try {
          localStorage.setItem(STORAGE_KEYS.LOCKOUT_UNTIL, String(lockoutUntil));
          localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, String(nextAttempts));
        } catch {}
        await writeIdbSecurityState({ failedAttempts: nextAttempts, lockoutUntil });
        setLockoutSecondsLeft(Math.ceil(LOCKOUT_DURATION_MS / 1000));
        return { success: false, remainingAttempts: 0, lockedOut: true };
      } else {
        try {
          localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, String(nextAttempts));
        } catch {}
        await writeIdbSecurityState({ failedAttempts: nextAttempts });
        return {
          success: false,
          remainingAttempts: Math.max(0, MAX_FAILED_ATTEMPTS - nextAttempts),
          lockedOut: false,
        };
      }
    }
  };

  // Change PIN from Settings (requires verifying current PIN)
  const changePin = async (
    currentPin: string,
    newPin: string
  ): Promise<{ success: boolean; error?: 'wrong_current' | 'invalid_format' }> => {
    const cleanNew = newPin.trim();
    if (!/^\d{6}$/.test(cleanNew)) {
      return { success: false, error: 'invalid_format' };
    }

    const idbState = await readIdbSecurityState();
    const pbkdf2Record = localStorage.getItem(STORAGE_KEYS.PIN_PBKDF2) || idbState.pinPbkdf2;
    let currentValid = false;

    if (pbkdf2Record && pbkdf2Record.startsWith('pbkdf2:')) {
      currentValid = await verifyPinPBKDF2(currentPin, pbkdf2Record);
    } else {
      const legacySha = localStorage.getItem(STORAGE_KEYS.LEGACY_CUSTOM_SHA256);
      if (legacySha) {
        currentValid = (await computeSha256(currentPin)) === legacySha;
      }
    }

    if (!currentValid) {
      return { success: false, error: 'wrong_current' };
    }

    const newPbkdf2 = await hashPinPBKDF2(cleanNew);
    try {
      localStorage.setItem(STORAGE_KEYS.PIN_PBKDF2, newPbkdf2);
      localStorage.removeItem(STORAGE_KEYS.LEGACY_CUSTOM_SHA256);
      localStorage.setItem(STORAGE_KEYS.VERIFIED_AT, String(Date.now()));
    } catch {}
    await writeIdbSecurityState({ pinPbkdf2: newPbkdf2 });
    setSessionPinSecret(cleanNew);

    return { success: true };
  };

  const isLockedOut = lockoutSecondsLeft > 0;
  const isOwnerMode = isOwnerRole(userRole);
  const can = useCallback((permission: Permission) => hasPermission(userRole, permission), [userRole]);
  const canAccess = useCallback((tab: AppTab) => canAccessTab(userRole, tab), [userRole]);

  return (
    <AccessAuthContext.Provider
      value={{
        isUnlocked,
        isPinConfigured,
        isLockedOut,
        lockoutSecondsLeft,
        failedAttempts,
        maxAttempts: MAX_FAILED_ATTEMPTS,
        userRole,
        activeRole: userRole,
        isOwnerMode,
        can,
        canAccess,
        setUserRole,
        setupInitialPin,
        verifyPin,
        changePin,
        lock,
        autoLockMinutes,
        setAutoLockMinutesState,
      }}
    >
      {children}
    </AccessAuthContext.Provider>
  );
};

export const useAccessAuth = () => {
  const context = useContext(AccessAuthContext);
  if (!context) {
    throw new Error('useAccessAuth must be used within an AccessAuthProvider');
  }
  return context;
};
