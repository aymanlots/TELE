import { UserRole, AppTab } from '../types';

export type Permission =
  | 'view_cost_price'
  | 'view_profits'
  | 'view_financial_dashboard'
  | 'manage_settings'
  | 'delete_records'
  | 'cancel_payments'
  | 'manage_backups'
  | 'manage_users'
  | 'manage_expenses'
  | 'manage_suppliers'
  | 'view_reports'
  | 'view_activity_logs'
  | 'make_sales'
  | 'manage_stock'
  | 'manage_repairs'
  | 'manage_customers'
  | 'manage_payments';

const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  owner: [
    'view_cost_price',
    'view_profits',
    'view_financial_dashboard',
    'manage_settings',
    'delete_records',
    'cancel_payments',
    'manage_backups',
    'manage_users',
    'manage_expenses',
    'manage_suppliers',
    'view_reports',
    'view_activity_logs',
    'make_sales',
    'manage_stock',
    'manage_repairs',
    'manage_customers',
    'manage_payments',
  ],
  employee: [
    'make_sales',
    'manage_stock',
    'manage_repairs',
    'manage_customers',
    'manage_payments',
  ],
};

const OWNER_ONLY_TABS: AppTab[] = [
  'dashboard',
  'reports',
  'expenses',
  'suppliers',
  'settings',
  'activity',
];

export function hasPermission(role: UserRole | undefined, permission: Permission): boolean {
  const effectiveRole: UserRole = role === 'employee' ? 'employee' : 'owner';
  const allowed = ROLE_PERMISSIONS[effectiveRole] || ROLE_PERMISSIONS.employee;
  return allowed.includes(permission);
}

export function isOwnerRole(role: UserRole | undefined): boolean {
  return hasPermission(role, 'manage_settings');
}

export function canAccessTab(role: UserRole | undefined, tab: AppTab): boolean {
  if (OWNER_ONLY_TABS.includes(tab)) {
    return hasPermission(role, 'view_financial_dashboard');
  }
  return true;
}

