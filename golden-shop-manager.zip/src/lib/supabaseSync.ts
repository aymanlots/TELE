import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { db, getDeviceId, withSyncMetadata } from '../db';
import { UserRole } from '../types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : null;

export type SyncStatusState = 'synced' | 'pending' | 'offline' | 'error' | 'unconfigured';

export interface SyncStatusSnapshot {
  status: SyncStatusState;
  pendingCount: number;
  conflictCount: number;
  lastSyncedAt: string | null;
  lastError: string | null;
  isSyncing: boolean;
}

const LAST_SYNC_STORAGE_KEY = 'golden_shop_last_sync_at';

type SyncListener = (snapshot: SyncStatusSnapshot) => void;
const listeners = new Set<SyncListener>();

let currentSnapshot: SyncStatusSnapshot = {
  status: isSupabaseConfigured ? (navigator.onLine ? 'synced' : 'offline') : 'unconfigured',
  pendingCount: 0,
  conflictCount: 0,
  lastSyncedAt: localStorage.getItem(LAST_SYNC_STORAGE_KEY),
  lastError: null,
  isSyncing: false,
};

function notifyListeners() {
  for (const l of listeners) {
    l({ ...currentSnapshot });
  }
}

export function subscribeSyncStatus(listener: SyncListener): () => void {
  listeners.add(listener);
  refreshSyncCounts().then(() => listener({ ...currentSnapshot }));
  return () => {
    listeners.delete(listener);
  };
}

export async function refreshSyncCounts(): Promise<void> {
  try {
    const pendingCount = await db.outbox.count();
    const conflictCount = await db.syncConflicts.filter((c) => !c.resolved).count();
    const online = typeof navigator !== 'undefined' ? navigator.onLine : true;

    let nextStatus: SyncStatusState = currentSnapshot.status;
    if (!isSupabaseConfigured) {
      nextStatus = 'unconfigured';
    } else if (!online) {
      nextStatus = 'offline';
    } else if (currentSnapshot.lastError) {
      nextStatus = 'error';
    } else if (pendingCount > 0) {
      nextStatus = 'pending';
    } else {
      nextStatus = 'synced';
    }

    currentSnapshot = {
      ...currentSnapshot,
      status: nextStatus,
      pendingCount,
      conflictCount,
    };
    notifyListeners();
  } catch {}
}

/**
 * Map local Dexie table names to remote Supabase table names
 */
const TABLE_MAP: Record<string, { dexieTable: string; remoteTable: string }> = {
  products: { dexieTable: 'products', remoteTable: 'products' },
  customers: { dexieTable: 'customers', remoteTable: 'customers' },
  sales: { dexieTable: 'sales', remoteTable: 'sales' },
  warranties: { dexieTable: 'warranties', remoteTable: 'warranties' },
  sav_tickets: { dexieTable: 'savTickets', remoteTable: 'sav_tickets' },
  repairs: { dexieTable: 'repairs', remoteTable: 'repairs' },
  spare_parts: { dexieTable: 'spareParts', remoteTable: 'spare_parts' },
  suppliers: { dexieTable: 'suppliers', remoteTable: 'suppliers' },
  supplier_payments: { dexieTable: 'supplierPayments', remoteTable: 'supplier_payments' },
  supplier_purchase_orders: {
    dexieTable: 'supplierPurchaseOrders',
    remoteTable: 'supplier_purchase_orders',
  },
  customer_payments: { dexieTable: 'customerPayments', remoteTable: 'customer_payments' },
  credit_audit_logs: { dexieTable: 'creditAuditLogs', remoteTable: 'credit_audit_logs' },
  expenses: { dexieTable: 'expenses', remoteTable: 'expenses' },
  recurring_expenses: { dexieTable: 'recurringExpenses', remoteTable: 'recurring_expenses' },
  stock_movements: { dexieTable: 'stockMovements', remoteTable: 'stock_movements' },
  cash_closures: { dexieTable: 'cashClosures', remoteTable: 'cash_closures' },
  activity_logs: { dexieTable: 'activityLogs', remoteTable: 'activity_logs' },
};

/**
 * Formats a local Dexie record into the remote Supabase row format
 */
function toRemoteRow(remoteTable: string, payload: any): Record<string, any> {
  const base = {
    id: payload.uuid,
    local_id: typeof payload.id === 'number' ? payload.id : null,
    payload,
    device_id: payload.device_id || getDeviceId(),
    updated_at: payload.updated_at || new Date().toISOString(),
    deleted_at: payload.deleted_at || null,
  };

  switch (remoteTable) {
    case 'products':
      return {
        ...base,
        name: payload.name || '',
        category: payload.category || 'other',
        barcode: payload.barcode || null,
        quantity: payload.quantity ?? 0,
        min_alert_qty: payload.minAlertQty ?? 5,
        purchase_price: payload.purchasePrice ?? 0,
        retail_price: payload.retailPrice ?? 0,
        wholesale_price: payload.wholesalePrice ?? 0,
      };
    case 'customers':
      return {
        ...base,
        name: payload.name || '',
        phone: payload.phone || null,
        cin: payload.CIN || null,
        total_credit: payload.totalCredit ?? 0,
      };
    case 'sales':
      return {
        ...base,
        bon_number: payload.bonNumber || 'G-0001',
        customer_uuid: payload.customerUuid || null,
        customer_name: payload.customerName || 'Client',
        date: payload.date || '',
        total_amount: payload.totalAmount ?? 0,
        paid_amount: payload.paidAmount ?? 0,
        remaining_amount: payload.remainingAmount ?? 0,
        status: payload.status || 'active',
        sale_kind: payload.saleKind || 'product',
      };
    case 'warranties':
      return {
        ...base,
        bon_number: payload.bonNumber || '',
        imei: payload.imei || null,
        status: payload.status || 'active',
      };
    case 'sav_tickets':
      return {
        ...base,
        bon_number: payload.bonNumber || null,
        imei: payload.imei || null,
        status: payload.status || 'open',
      };
    case 'repairs':
      return {
        ...base,
        repair_number: payload.repairNumber || 'R-0001',
        customer_name: payload.customerName || '',
        customer_phone: payload.customerPhone || null,
        status: payload.status || 'pending',
        agreed_price: payload.agreedPrice ?? 0,
        deposit_amount: payload.depositAmount ?? 0,
        remaining_amount: payload.remainingAmount ?? 0,
        total_parts_cost: payload.totalPartsCost ?? 0,
        net_profit: payload.netProfit ?? 0,
      };
    case 'spare_parts':
      return {
        ...base,
        name: payload.name || '',
        quantity: payload.quantity ?? 0,
        purchase_price: payload.purchasePrice ?? 0,
        selling_price: payload.sellingPrice ?? 0,
      };
    case 'suppliers':
      return {
        ...base,
        name: payload.name || '',
        phone: payload.phone || null,
        total_debt: payload.totalDebt ?? 0,
        paid_amount: payload.paidAmount ?? 0,
      };
    case 'supplier_payments':
      return {
        ...base,
        supplier_uuid: payload.supplierUuid || null,
        amount: payload.amount ?? 0,
        date: payload.date || '',
      };
    case 'supplier_purchase_orders':
      return {
        ...base,
        bon_number: payload.bonNumber || '',
        supplier_uuid: payload.supplierUuid || null,
        total_amount: payload.totalAmount ?? 0,
      };
    case 'customer_payments':
      return {
        ...base,
        customer_uuid: payload.customerUuid || null,
        sale_uuid: payload.saleUuid || null,
        amount: payload.amount ?? 0,
        date: payload.date || '',
        status: payload.status || 'active',
      };
    case 'credit_audit_logs':
      return {
        ...base,
        customer_uuid: payload.customerUuid || null,
        action: payload.action || 'create',
      };
    case 'expenses':
      return {
        ...base,
        category: payload.category || 'other',
        amount: payload.amount ?? 0,
        date: payload.date || '',
      };
    case 'recurring_expenses':
      return {
        ...base,
        title: payload.title || '',
        amount: payload.amount ?? 0,
      };
    case 'stock_movements':
      return {
        ...base,
        product_uuid: payload.productUuid || null,
        type: payload.type || 'adjustment',
        quantity_delta: payload.quantityDelta ?? 0,
      };
    case 'cash_closures':
      return {
        ...base,
        date: payload.date || '',
        counted_cash: payload.countedCash ?? 0,
        discrepancy: payload.discrepancy ?? 0,
      };
    case 'activity_logs':
      return {
        ...base,
        action: payload.action || 'sale',
        entity_type: payload.entityType || 'sale',
      };
    default:
      return base;
  }
}

/**
 * Push local Outbox in batches + Pull incremental remote updates from Supabase
 */
export async function triggerCloudSync(): Promise<{ success: boolean; error?: string }> {
  if (!supabase || !isSupabaseConfigured) {
    await refreshSyncCounts();
    return { success: false, error: 'Supabase non configuré' };
  }
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    await refreshSyncCounts();
    return { success: false, error: 'Mode hors-ligne' };
  }
  if (currentSnapshot.isSyncing) {
    return { success: true };
  }

  currentSnapshot = { ...currentSnapshot, isSyncing: true, lastError: null };
  notifyListeners();

  try {
    // 1. Process Outbox in batches of 25
    const pendingItems = await db.outbox.orderBy('id').limit(50).toArray();

    for (const item of pendingItems) {
      if (!item.id) continue;
      const mapping = TABLE_MAP[item.table];
      if (!mapping) {
        await db.outbox.delete(item.id);
        continue;
      }

      let payload = { ...item.payload };

      // Partie 2 #5: Renumber provisional offline bon G-L-xxxx, REP-L-xxxx, R-L-xxxx, BA-L-xxxx via atomic server RPC
      if (item.table === 'sales' && payload.bonNumber?.startsWith('G-L-')) {
        try {
          const { data: rpcBon } = await supabase.rpc('next_bon_number');
          if (rpcBon && typeof rpcBon === 'string') {
            payload.bonNumber = rpcBon;
            if (payload.id) {
              await db.sales.update(payload.id, { bonNumber: rpcBon });
            }
          }
        } catch {}
      } else if (item.table === 'sales' && payload.bonNumber?.startsWith('REP-L-')) {
        try {
          const { data: rpcRepBon } = await supabase.rpc('next_trade_in_number');
          if (rpcRepBon && typeof rpcRepBon === 'string') {
            payload.bonNumber = rpcRepBon;
            if (payload.id) {
              await db.sales.update(payload.id, { bonNumber: rpcRepBon });
            }
          }
        } catch {}
      } else if (item.table === 'repairs' && payload.repairNumber?.startsWith('R-L-')) {
        try {
          const { data: rpcRep } = await supabase.rpc('next_repair_number');
          if (rpcRep && typeof rpcRep === 'string') {
            payload.repairNumber = rpcRep;
            if (payload.id) {
              await db.repairs.update(payload.id, { repairNumber: rpcRep });
            }
          }
        } catch {}
      } else if (
        item.table === 'supplier_purchase_orders' &&
        payload.bonNumber?.startsWith('BA-L-')
      ) {
        try {
          const { data: rpcPo } = await supabase.rpc('next_purchase_order_number');
          if (rpcPo && typeof rpcPo === 'string') {
            payload.bonNumber = rpcPo;
            if (payload.id) {
              await db.supplierPurchaseOrders.update(payload.id, { bonNumber: rpcPo });
            }
          }
        } catch {}
      }

      if (item.operation === 'delete') {
        const { error } = await supabase
          .from(mapping.remoteTable)
          .update({ deleted_at: payload.deleted_at || new Date().toISOString(), updated_at: new Date().toISOString() })
          .eq('id', item.uuid);
        if (error) throw error;
      } else {
        const row = toRemoteRow(mapping.remoteTable, payload);
        const { error } = await supabase.from(mapping.remoteTable).upsert(row, { onConflict: 'id' });
        if (error) throw error;
      }

      await db.outbox.delete(item.id);
    }

    // 2. Pull incremental remote changes since lastSyncAt
    const lastSyncAt = localStorage.getItem(LAST_SYNC_STORAGE_KEY) || '1970-01-01T00:00:00.000Z';
    const currentDeviceId = getDeviceId();

    for (const [tableKey, mapping] of Object.entries(TABLE_MAP)) {
      const { data: rows, error } = await supabase
        .from(mapping.remoteTable)
        .select('*')
        .gt('updated_at', lastSyncAt)
        .order('updated_at', { ascending: true })
        .limit(200);

      if (error || !rows || rows.length === 0) continue;

      const dexieTable = (db as any)[mapping.dexieTable];
      if (!dexieTable) continue;

      for (const remoteRow of rows) {
        if (remoteRow.device_id === currentDeviceId) continue; // Ignore our own echo

        const remotePayload = remoteRow.payload || {};
        const entityUuid = remoteRow.id;
        const localMatch = await dexieTable.where('uuid').equals(entityUuid).first();

        if (remoteRow.deleted_at) {
          if (localMatch && localMatch.id) {
            await dexieTable.delete(localMatch.id);
          }
          continue;
        }

        if (!localMatch) {
          // Insert new record from remote
          const toInsert = { ...remotePayload, uuid: entityUuid, updated_at: remoteRow.updated_at };
          delete toInsert.id; // Let Dexie assign local auto-increment id
          await dexieTable.add(toInsert);
        } else {
          // Conflict resolution (Partie 2 #3):
          // For sales and customer_payments, if local record also has pending unpushed changes, preserve both and log conflict!
          const hasLocalOutbox = await db.outbox.where('uuid').equals(entityUuid).count();
          if (
            hasLocalOutbox > 0 &&
            (tableKey === 'sales' || tableKey === 'customer_payments')
          ) {
            await db.syncConflicts.add({
              entityTable: tableKey,
              entityUuid,
              localRecord: localMatch,
              remoteRecord: remotePayload,
              detectedAt: new Date().toISOString(),
              resolved: false,
            });
          } else {
            // Most recent updated_at wins for metadata; for products, compute stock via initialQty + sum(stock_movements.quantityDelta)
            const localTime = new Date(localMatch.updated_at || 0).getTime();
            const remoteTime = new Date(remoteRow.updated_at || 0).getTime();
            if (remoteTime >= localTime || tableKey === 'products') {
              let mergedQuantity = remotePayload.quantity ?? localMatch.quantity;
              if (tableKey === 'products') {
                const movements = await db.stockMovements
                  .filter((m) => !m.deleted_at && (m.productUuid === entityUuid || m.productId === localMatch.id))
                  .toArray();
                if (movements.length > 0) {
                  const sortedMovements = [...movements].sort((a, b) =>
                    (a.createdAt || a.date || '').localeCompare(b.createdAt || b.date || '')
                  );
                  const baseQty = sortedMovements[0].previousQty ?? 0;
                  const sumDelta = sortedMovements.reduce(
                    (acc, m) => acc + (Number(m.quantityDelta) || 0),
                    0
                  );
                  mergedQuantity = Math.max(0, baseQty + sumDelta);
                }
              }

              await dexieTable.put({
                ...localMatch,
                ...(remoteTime >= localTime ? remotePayload : {}),
                ...(tableKey === 'products' ? { quantity: mergedQuantity } : {}),
                id: localMatch.id,
                uuid: entityUuid,
                updated_at: remoteTime >= localTime ? remoteRow.updated_at : localMatch.updated_at,
              });
            }
          }
        }
      }
    }

    const nowIso = new Date().toISOString();
    localStorage.setItem(LAST_SYNC_STORAGE_KEY, nowIso);
    currentSnapshot = {
      ...currentSnapshot,
      lastSyncedAt: nowIso,
      lastError: null,
      isSyncing: false,
    };
    await refreshSyncCounts();
    return { success: true };
  } catch (err: any) {
    currentSnapshot = {
      ...currentSnapshot,
      status: 'error',
      lastError: err?.message || 'Erreur de synchronisation',
      isSyncing: false,
    };
    notifyListeners();
    return { success: false, error: currentSnapshot.lastError || 'Erreur' };
  }
}

/**
 * One-time migration of all local Dexie tables to Supabase ("Migrer vers le cloud" - Partie 2 #6)
 */
export async function migrateAllLocalDataToCloud(
  onProgress?: (percent: number, stepLabel: string) => void
): Promise<{ success: boolean; totalMigrated: number; error?: string }> {
  if (!supabase || !isSupabaseConfigured) {
    return {
      success: false,
      totalMigrated: 0,
      error: 'Veuillez configurer VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY.',
    };
  }

  try {
    const entries = Object.entries(TABLE_MAP);
    let totalMigrated = 0;

    for (let i = 0; i < entries.length; i++) {
      const [key, mapping] = entries[i];
      const pct = Math.round(((i + 1) / entries.length) * 100);
      if (onProgress) onProgress(pct, mapping.remoteTable);

      const dexieTable = (db as any)[mapping.dexieTable];
      if (!dexieTable) continue;

      const records = await dexieTable.toArray();
      if (!records.length) continue;

      const rowsToUpsert = [];
      for (const rec of records) {
        const synced = withSyncMetadata(rec);
        if (rec.id && !rec.uuid) {
          await dexieTable.put(synced);
        }
        rowsToUpsert.push(toRemoteRow(mapping.remoteTable, synced));
      }

      // Upsert in chunks of 50
      for (let c = 0; c < rowsToUpsert.length; c += 50) {
        const chunk = rowsToUpsert.slice(c, c + 50);
        const { error } = await supabase.from(mapping.remoteTable).upsert(chunk, { onConflict: 'id' });
        if (error) throw error;
        totalMigrated += chunk.length;
      }
    }

    // Clear outbox since everything is freshly uploaded
    await db.outbox.clear();
    const nowIso = new Date().toISOString();
    localStorage.setItem(LAST_SYNC_STORAGE_KEY, nowIso);
    await refreshSyncCounts();

    return { success: true, totalMigrated };
  } catch (err: any) {
    return {
      success: false,
      totalMigrated: 0,
      error: err?.message || 'Erreur lors de la migration vers Supabase.',
    };
  }
}

/**
 * Supabase Auth helpers (Partie 2 #4)
 */
export async function signInSupabaseUser(
  email: string,
  password: string
): Promise<{ success: boolean; role?: UserRole; error?: string }> {
  if (!supabase) {
    return { success: false, error: 'Supabase non configuré.' };
  }
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error || !data.user) {
    return { success: false, error: error?.message || 'Identifiants invalides.' };
  }

  let role: UserRole = 'owner';
  try {
    const { data: profile } = await supabase
      .from('users_profile')
      .select('role, active')
      .eq('id', data.user.id)
      .single();
    if (profile) {
      if (profile.active === false) {
        await supabase.auth.signOut();
        return { success: false, error: 'Ce compte employé a été désactivé par le propriétaire.' };
      }
      role = profile.role === 'employee' ? 'employee' : 'owner';
    }
  } catch {}

  localStorage.setItem('golden_shop_user_role', role);
  localStorage.setItem('golden_shop_user_name', data.user.email || role);
  await triggerCloudSync();
  return { success: true, role };
}

export async function signOutSupabaseUser(): Promise<void> {
  if (supabase) {
    await supabase.auth.signOut();
  }
}

export interface ShopUserProfile {
  id: string;
  email: string;
  full_name?: string;
  role: UserRole;
  active: boolean;
  created_at?: string;
}

export async function fetchShopUsers(): Promise<ShopUserProfile[]> {
  if (!supabase || !isSupabaseConfigured) return [];
  const { data, error } = await supabase
    .from('users_profile')
    .select('id, email, full_name, role, active, created_at')
    .order('created_at', { ascending: true });
  if (error || !data) return [];
  return data as ShopUserProfile[];
}

export async function createEmployeeViaEdgeFunction(
  email: string,
  password: string,
  fullName: string
): Promise<{ success: boolean; user?: ShopUserProfile; error?: string }> {
  if (!supabase || !isSupabaseConfigured) {
    return { success: false, error: 'Supabase non configuré.' };
  }
  const { data, error } = await supabase.functions.invoke('create-employee', {
    body: { email, password, fullName },
  });
  if (error) {
    return { success: false, error: error.message || 'Erreur Edge Function create-employee.' };
  }
  if (data?.error) {
    return { success: false, error: data.error };
  }
  return { success: true, user: data?.user };
}

export async function toggleEmployeeActiveStatus(
  userId: string,
  active: boolean
): Promise<{ success: boolean; error?: string }> {
  if (!supabase || !isSupabaseConfigured) {
    return { success: false, error: 'Supabase non configuré.' };
  }
  const { error } = await supabase
    .from('users_profile')
    .update({ active, updated_at: new Date().toISOString() })
    .eq('id', userId);
  if (error) {
    return { success: false, error: error.message };
  }
  return { success: true };
}

// Start background sync loop (online event + 30s interval)
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    refreshSyncCounts();
    triggerCloudSync();
  });
  window.addEventListener('offline', () => {
    refreshSyncCounts();
  });
  setInterval(() => {
    if (isSupabaseConfigured && navigator.onLine) {
      triggerCloudSync();
    } else {
      refreshSyncCounts();
    }
  }, 30000);
}
