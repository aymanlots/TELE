import React, { useEffect, useState } from 'react';
import {
  Search,
  Moon,
  Sun,
  Menu,
  Globe,
  ShieldAlert,
  Smartphone,
  Monitor,
  Lock,
  Cloud,
  CloudOff,
  RefreshCw,
  AlertCircle,
  Shield,
  UserCheck,
} from 'lucide-react';
import { useI18n } from '../i18n';
import { useTheme } from '../lib/theme';
import { useViewMode } from '../lib/viewMode';
import { useAccessAuth } from '../lib/accessAuth';
import { PWAInstallButton } from './PWAInstallButton';
import { AppTab } from '../types';
import {
  subscribeSyncStatus,
  triggerCloudSync,
  SyncStatusSnapshot,
  isSupabaseConfigured,
} from '../lib/supabaseSync';

interface HeaderProps {
  onToggleSidebar: () => void;
  onOpenSearch: () => void;
  activeTab: AppTab;
  hasBackupWarning?: boolean;
  onNavigateSettings?: () => void;
  storeName?: string;
  storeLogo?: string;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  onOpenSearch,
  hasBackupWarning = false,
  onNavigateSettings,
  storeName,
  storeLogo,
}) => {
  const { language, setLanguage, t } = useI18n();
  const { theme, toggleTheme } = useTheme();
  const { isMobileMode, toggleViewMode } = useViewMode();
  const { lock, isOwnerMode, can } = useAccessAuth();
  const [syncSnap, setSyncSnap] = useState<SyncStatusSnapshot | null>(null);

  useEffect(() => {
    return subscribeSyncStatus((snap) => setSyncSnap(snap));
  }, []);

  const fallbackName = 'Golden Shop Manager';
  const displayName = storeName?.trim() || fallbackName;
  const initial = displayName.charAt(0).toUpperCase() || 'G';

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-3 px-3 sm:px-6 py-2.5 bg-neutral-900/95 backdrop-blur-md border-b border-neutral-800 text-neutral-100">
      {/* Zone 1: Sidebar Toggle & Brand */}
      <div className="flex items-center gap-2.5 shrink-0">
        {!isMobileMode && (
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition md:hidden"
            aria-label="Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}
        <div className="flex items-center gap-3.5 py-1">
          {storeLogo ? (
            <img
              src={storeLogo}
              alt={displayName}
              className="w-20 h-20 sm:w-24 sm:h-24 min-w-[80px] min-h-[80px] rounded-2xl object-contain bg-neutral-950 p-2 border-2 border-amber-400/80 shadow-xl shadow-amber-500/20 shrink-0"
            />
          ) : (
            <div className="w-20 h-20 sm:w-24 sm:h-24 min-w-[80px] min-h-[80px] rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 border-2 border-amber-300 flex items-center justify-center font-black text-neutral-950 text-3xl shadow-xl shadow-amber-500/25 uppercase shrink-0">
              {initial}
            </div>
          )}
          <div className="flex flex-col justify-center">
            <span className="font-black text-base sm:text-lg md:text-xl tracking-tight text-gold-gradient whitespace-nowrap leading-tight drop-shadow-xs">
              {displayName}
            </span>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-xs text-amber-400 font-bold hidden sm:inline tracking-wide">
                {language === 'ar' ? 'نظام إدارة المحل' : 'Gestion de Magasin'}
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-neutral-800 border border-neutral-700 text-[10px] font-bold text-neutral-300">
                {isOwnerMode ? (
                  <>
                    <Shield className="w-3 h-3 text-amber-400" />
                    <span>{language === 'ar' ? 'المالك' : 'Propriétaire'}</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-3 h-3 text-emerald-400" />
                    <span>{language === 'ar' ? 'موظف' : 'Employé'}</span>
                  </>
                )}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Zone 2: Global Search Trigger Button */}
      <div className="flex-1 max-w-xs md:max-w-md mx-1 sm:mx-2">
        <button
          type="button"
          onClick={onOpenSearch}
          className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-neutral-950/90 hover:bg-neutral-900 border border-amber-500/20 hover:border-amber-500/50 text-xs text-neutral-300 transition shadow-inner"
        >
          <div className="flex items-center gap-2 truncate">
            <Search className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate text-neutral-300">{t.searchPlaceholder}</span>
          </div>
          <kbd className="hidden md:inline-block font-mono text-[10px] bg-neutral-900 border border-neutral-700/80 px-1.5 py-0.5 rounded text-amber-400/90 shrink-0">
            Ctrl+K
          </kbd>
        </button>
      </div>

      {/* Zone 3: Controls (Sync Status, ViewMode, Backup Alert, PWA, Language, Lock, Theme) */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* Visual Sync Status Pill (Partie 2 #3) */}
        {syncSnap && (
          <button
            type="button"
            onClick={() => {
              if (isSupabaseConfigured) {
                triggerCloudSync();
              } else if (can('manage_settings') && onNavigateSettings) {
                onNavigateSettings();
              }
            }}
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold transition ${
              syncSnap.status === 'error'
                ? 'bg-rose-500/15 text-rose-300 border-rose-500/40 hover:bg-rose-500/25'
                : syncSnap.status === 'offline'
                ? 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                : syncSnap.status === 'pending'
                ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
                : syncSnap.status === 'synced'
                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
                : 'bg-neutral-800/80 text-neutral-400 border-neutral-700'
            }`}
            title={
              syncSnap.status === 'error'
                ? `${syncSnap.lastError || 'Erreur'} — Cliquer pour réessayer`
                : 'Statut de synchronisation'
            }
          >
            {syncSnap.isSyncing ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
            ) : syncSnap.status === 'error' ? (
              <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
            ) : syncSnap.status === 'offline' ? (
              <CloudOff className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>
              {syncSnap.status === 'error'
                ? language === 'ar'
                  ? 'خطأ مزامنة (إعادة)'
                  : 'Erreur de sync (Réessayer)'
                : syncSnap.status === 'offline'
                ? language === 'ar'
                  ? 'بدون إنترنت'
                  : 'Hors ligne'
                : syncSnap.status === 'pending'
                ? language === 'ar'
                  ? `في الانتظار (${syncSnap.pendingCount})`
                  : `En attente (${syncSnap.pendingCount} opérations)`
                : syncSnap.status === 'synced'
                ? language === 'ar'
                  ? 'متزامن'
                  : 'Synchronisé'
                : language === 'ar'
                ? `محلي (${syncSnap.pendingCount})`
                : 'Mode local'}
            </span>
          </button>
        )}

        {/* View Mode Toggle: Desktop / Mobile */}
        <button
          type="button"
          onClick={toggleViewMode}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-bold transition active:scale-95 shadow-sm ${
            isMobileMode
              ? 'bg-gradient-to-b from-amber-400 to-amber-600 text-neutral-950 border-amber-300 shadow-md shadow-amber-500/25'
              : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-100 border-neutral-700'
          }`}
          title={
            isMobileMode
              ? language === 'ar'
                ? 'وضع الهاتف مفعّل (انقر للتبديل لوضع الكمبيوتر)'
                : 'Mode Téléphone activé (Cliquer pour Mode PC)'
              : language === 'ar'
              ? 'وضع الكمبيوتر مفعّل (انقر للتبديل لوضع الهاتف)'
              : 'Mode PC activé (Cliquer pour Mode Téléphone)'
          }
        >
          {isMobileMode ? (
            <>
              <Smartphone className="w-4 h-4 text-neutral-950" />
              <span className="text-[11px] font-black">{language === 'ar' ? 'هاتف' : 'Mobile'}</span>
            </>
          ) : (
            <>
              <Monitor className="w-4 h-4 text-amber-400" />
              <span className="text-[11px] font-semibold hidden sm:inline">
                {language === 'ar' ? 'كمبيوتر' : 'PC'}
              </span>
            </>
          )}
        </button>

        {hasBackupWarning && can('manage_backups') && onNavigateSettings && (
          <button
            onClick={onNavigateSettings}
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20 transition animate-pulse"
            title="Sauvegarde recommandée (> 7 jours)"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Sauvegarde</span>
          </button>
        )}

        <PWAInstallButton />

        {/* Language Switcher */}
        <button
          type="button"
          onClick={() => setLanguage(language === 'ar' ? 'fr' : 'ar')}
          className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 border border-neutral-700 transition"
          title="Changer la langue / تبديل اللغة"
        >
          <Globe className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-mono text-[11px]">{language === 'ar' ? 'FR' : 'عربي'}</span>
        </button>

        {/* Manual Lock Button */}
        <button
          type="button"
          onClick={lock}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-amber-400 border border-neutral-700/80 hover:border-amber-500/40 text-xs font-semibold transition active:scale-95 shadow-sm"
          title={t.lock.lockHeaderTooltip}
          aria-label={t.lock.lockHeaderTooltip}
        >
          <Lock className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden xl:inline text-[11px] font-bold">
            {language === 'ar' ? 'قفل' : 'Verrouiller'}
          </span>
        </button>

        {/* Theme Toggle */}
        <button
          type="button"
          onClick={toggleTheme}
          className="p-2 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition"
          aria-label="Changer le thème"
        >
          {theme === 'dark' ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4 text-neutral-400" />
          )}
        </button>
      </div>
    </header>
  );
};
