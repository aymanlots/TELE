import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  badge?: string;
  alert?: boolean;
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  badge,
  alert = false,
  onClick,
}) => {
  return (
    <div
      onClick={onClick}
      className={`p-5 rounded-2xl border transition-all duration-200 ${
        onClick ? 'cursor-pointer hover:border-amber-400/60 hover:-translate-y-1 hover:shadow-2xl' : ''
      } ${
        alert
          ? 'bg-rose-950/20 border-rose-500/40 shadow-lg shadow-rose-950/20'
          : 'bg-neutral-900 border-neutral-800/90 shadow-xl shadow-black/70'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-semibold text-neutral-400 tracking-wide">{title}</p>
          <div className="text-2xl font-black font-mono tracking-tight text-white tabular-nums">
            {value}
          </div>
        </div>
        <div
          className={`p-3 rounded-xl shrink-0 ${
            alert
              ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30 shadow-inner'
              : 'bg-gradient-to-br from-amber-400/20 to-amber-600/10 text-amber-400 border border-amber-500/30 shadow-md shadow-amber-500/10'
          }`}
        >
          <Icon className="w-5 h-5 drop-shadow-[0_0_6px_rgba(212,175,55,0.4)]" />
        </div>
      </div>

      {(subtitle || badge) && (
        <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs text-neutral-400">
          {subtitle && <span>{subtitle}</span>}
          {badge && (
            <span
              className={`font-semibold ${
                alert ? 'text-rose-400' : 'text-amber-400'
              }`}
            >
              {badge}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
