import React from 'react';
import {
  LayoutDashboard,
  Boxes,
  Receipt,
  History,
  ShieldCheck,
  Users,
  Truck,
  Settings,
  ChevronLeft,
  ChevronRight,
  Wrench,
  Cpu,
  Wallet,
  BarChart3,
  Activity,
} from 'lucide-react';
import { AppTab } from '../types';
import { useI18n } from '../i18n';
import { useAccessAuth } from '../lib/accessAuth';

interface SidebarProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  lowStockCount?: number;
  lowSparePartsCount?: number;
  openSavCount?: number;
  openRepairsCount?: number;
  storeName?: string;
  storeLogo?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpen,
  onCloseMobile,
  isCollapsed,
  onToggleCollapse,
  lowStockCount = 0,
  lowSparePartsCount = 0,
  openSavCount = 0,
  openRepairsCount = 0,
  storeName,
  storeLogo,
}) => {
  const { t, isRTL } = useI18n();
  const { canAccess } = useAccessAuth();

  const allNavItems: { id: AppTab; label: string; icon: React.FC<{ className?: string }>; badge?: number; badgeAlert?: boolean }[] = [
    { id: 'dashboard', label: t.nav.dashboard, icon: LayoutDashboard },
    { id: 'pos', label: t.nav.pos, icon: Receipt },
    { id: 'stock', label: t.nav.stock, icon: Boxes, badge: lowStockCount, badgeAlert: true },
    { id: 'spare-parts', label: t.nav.spareParts, icon: Cpu, badge: lowSparePartsCount, badgeAlert: true },
    { id: 'repairs', label: t.nav.repairs, icon: Wrench, badge: openRepairsCount },
    { id: 'expenses', label: t.nav.expenses, icon: Wallet },
    { id: 'reports', label: isRTL ? 'التقارير المالية' : 'Rapports', icon: BarChart3 },
    { id: 'activity', label: isRTL ? 'سجل الأنشطة' : 'Journal d\'activité', icon: Activity },
    { id: 'bons', label: t.nav.bons, icon: History },
    { id: 'warranty', label: t.nav.warranty, icon: ShieldCheck, badge: openSavCount },
    { id: 'customers', label: t.nav.customers, icon: Users },
    { id: 'suppliers', label: t.nav.suppliers, icon: Truck },
    { id: 'settings', label: t.nav.settings, icon: Settings },
  ];

  const navItems = allNavItems.filter((item) => canAccess(item.id));

  const collapseIcon = isRTL
    ? isCollapsed
      ? <ChevronLeft className="w-4 h-4" />
      : <ChevronRight className="w-4 h-4" />
    : isCollapsed
      ? <ChevronRight className="w-4 h-4" />
      : <ChevronLeft className="w-4 h-4" />;

  const fallbackName = isRTL ? 'متجري' : 'Mon Magasin';
  const displayName = storeName?.trim() || fallbackName;
  const initial = displayName.charAt(0).toUpperCase() || 'M';

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed md:sticky top-0 start-0 z-40 h-screen bg-neutral-900 border-e border-neutral-800 transition-all duration-200 flex flex-col justify-between ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 rtl:translate-x-full md:rtl:translate-x-0'
        } ${isCollapsed ? 'w-20' : 'w-64'}`}
      >
        {/* Brand & collapse trigger */}
        <div>
          <div className="relative border-b border-neutral-800/80 p-4">
            {!isCollapsed ? (
              <div className="flex flex-col items-center text-center">
                <div className="absolute top-3 end-3">
                  <button
                    onClick={onToggleCollapse}
                    className="hidden md:flex p-1.5 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition"
                    title="Réduire"
                  >
                    {collapseIcon}
                  </button>
                </div>

                {storeLogo ? (
                  <img
                    src={storeLogo}
                    alt={displayName}
                    className="w-24 h-24 rounded-2xl object-contain bg-neutral-950 border-2 border-amber-400/80 p-2 shadow-xl shadow-amber-500/20 mb-2"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 border-2 border-amber-300 flex items-center justify-center font-black text-neutral-950 text-3xl shadow-xl shadow-amber-500/25 mb-2 uppercase">
                    {initial}
                  </div>
                )}

                <div className="text-base font-black text-gold-gradient tracking-tight leading-tight w-full truncate px-1">
                  {displayName}
                </div>
                <div className="text-[11px] font-bold text-amber-400 mt-0.5 tracking-wider">
                  {isRTL ? 'إدارة المحل' : 'Gestion de Magasin'}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center gap-2">
                {storeLogo ? (
                  <img
                    src={storeLogo}
                    alt={displayName}
                    className="w-12 h-12 rounded-xl object-contain bg-neutral-950 border-2 border-amber-400/70 p-1 shadow-md shadow-amber-500/20"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center font-black text-neutral-950 text-xl shadow-md uppercase">
                    {initial}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Navigation Items */}
          <nav className="p-3 space-y-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all active:scale-95 ${
                    isCollapsed ? 'justify-center px-0' : ''
                  } ${
                    isActive
                      ? 'bg-gradient-to-r from-amber-500/25 via-amber-500/15 to-transparent text-amber-300 font-bold border border-amber-500/40 shadow-sm shadow-amber-500/10'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800/80 hover:border-neutral-700/60 border border-transparent'
                  }`}
                  title={item.label}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-transform ${
                      isActive ? 'text-amber-400 scale-110' : 'text-neutral-400'
                    }`}
                  />
                  {!isCollapsed && <span className="truncate flex-1 text-start">{item.label}</span>}

                  {!isCollapsed && item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                        item.badgeAlert
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer Collapse Button (Collapsed Mode) */}
        {isCollapsed && (
          <div className="p-3 border-t border-neutral-800 hidden md:flex justify-center">
            <button
              onClick={onToggleCollapse}
              className="p-2 rounded-lg text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition"
              title="Agrandir"
            >
              {collapseIcon}
            </button>
          </div>
        )}

        {/* Offline Badge status in sidebar */}
        {!isCollapsed && (
          <div className="p-4 border-t border-neutral-800/80">
            <div className="px-3 py-2 rounded-lg bg-neutral-950/60 border border-neutral-800 flex items-center justify-between text-[11px] text-neutral-400">
              <span className="font-mono">100% Hors-Ligne</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
