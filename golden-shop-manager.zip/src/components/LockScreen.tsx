import React, { useState, useEffect, useCallback } from 'react';
import { Lock, ShieldAlert, Delete, Globe, Clock, UserCheck, Shield } from 'lucide-react';
import { useAccessAuth } from '../lib/accessAuth';
import { useI18n } from '../i18n';
import { getStoreSettings } from '../db';
import { UserRole } from '../types';

export const LockScreen: React.FC = () => {
  const {
    isPinConfigured,
    isLockedOut,
    lockoutSecondsLeft,
    userRole,
    setUserRole,
    setupInitialPin,
    verifyPin,
  } = useAccessAuth();
  const { t, language, setLanguage } = useI18n();

  const [pin, setPin] = useState<string>('');
  const [setupStep, setSetupStep] = useState<'first' | 'confirm'>('first');
  const [firstPinDraft, setFirstPinDraft] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<UserRole>(userRole);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [storeName, setStoreName] = useState<string>('');
  const [storeLogo, setStoreLogo] = useState<string | undefined>(undefined);

  useEffect(() => {
    async function loadBrand() {
      try {
        const s = await getStoreSettings();
        setStoreName(s.storeName || '');
        setStoreLogo(s.logo);
      } catch {}
    }
    loadBrand();
  }, []);

  const fallbackName = 'Golden Shop Manager';
  const displayName = storeName.trim() || fallbackName;
  const initial = displayName.charAt(0).toUpperCase() || 'G';

  const handleDigit = useCallback(
    (digit: string) => {
      if (isLockedOut || isVerifying) return;
      if (pin.length < 6) {
        const next = pin + digit;
        setPin(next);
        setErrorMessage(null);
      }
    },
    [pin, isLockedOut, isVerifying]
  );

  const handleDelete = useCallback(() => {
    if (isLockedOut || isVerifying) return;
    setPin((prev) => prev.slice(0, -1));
    setErrorMessage(null);
  }, [isLockedOut, isVerifying]);

  const handleClear = useCallback(() => {
    if (isLockedOut || isVerifying) return;
    setPin('');
    setErrorMessage(null);
  }, [isLockedOut, isVerifying]);

  // Auto-handle 6-digit completion (either initial setup or normal unlock)
  useEffect(() => {
    if (pin.length === 6 && !isLockedOut && !isVerifying) {
      let isCancelled = false;

      const triggerAction = async () => {
        if (!isPinConfigured) {
          if (setupStep === 'first') {
            setFirstPinDraft(pin);
            setPin('');
            setSetupStep('confirm');
            return;
          } else {
            if (pin !== firstPinDraft) {
              setIsShaking(true);
              setTimeout(() => setIsShaking(false), 500);
              setPin('');
              setSetupStep('first');
              setFirstPinDraft('');
              setErrorMessage(t.lock.codeMismatch);
              return;
            }
            setIsVerifying(true);
            setUserRole(selectedRole);
            await setupInitialPin(pin);
            if (!isCancelled) setIsVerifying(false);
            return;
          }
        }

        setIsVerifying(true);
        const result = await verifyPin(pin, selectedRole);

        if (isCancelled) return;

        if (!result.success) {
          setIsShaking(true);
          setTimeout(() => setIsShaking(false), 500);
          setPin('');

          if (result.lockedOut) {
            setErrorMessage(t.lock.lockedOutTitle);
          } else {
            setErrorMessage(t.lock.wrongPin);
          }
        }
        setIsVerifying(false);
      };

      triggerAction();

      return () => {
        isCancelled = true;
      };
    }
  }, [
    pin,
    isPinConfigured,
    setupStep,
    firstPinDraft,
    selectedRole,
    isLockedOut,
    isVerifying,
    setupInitialPin,
    verifyPin,
    setUserRole,
    t,
  ]);

  // Physical keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isLockedOut) return;

      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleDelete();
      } else if (e.key === 'Escape' || e.key === 'Delete') {
        e.preventDefault();
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDigit, handleDelete, handleClear, isLockedOut]);

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0B0B0F] text-neutral-100 overflow-y-auto selection:bg-amber-500/30">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            'radial-gradient(circle 600px at 50% 15%, rgba(212, 175, 55, 0.08), transparent 70%), radial-gradient(circle 400px at 80% 80%, rgba(212, 175, 55, 0.03), transparent 60%)',
        }}
      />

      {/* Language Switcher */}
      <div className="absolute top-4 end-4 z-20">
        <button
          type="button"
          onClick={() => setLanguage(language === 'ar' ? 'fr' : 'ar')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 border border-amber-500/25 hover:border-amber-500/60 text-xs font-semibold text-neutral-200 transition shadow-lg active:scale-95"
        >
          <Globe className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-mono text-xs font-bold">{language === 'ar' ? 'FR' : 'عربي'}</span>
        </button>
      </div>

      {/* Main Lock Card */}
      <div className="relative w-full max-w-sm sm:max-w-md bg-[#15151C] border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.95),0_0_25px_rgba(212,175,55,0.12),inset_0_1px_0_rgba(245,215,110,0.2)] my-auto text-center space-y-5">
        <div className="flex flex-col items-center justify-center">
          <div className="relative mb-3">
            {storeLogo ? (
              <img
                src={storeLogo}
                alt={displayName}
                className="w-24 h-24 min-w-[96px] min-h-[96px] rounded-2xl object-contain bg-[#0E0E15] p-2 border-2 border-amber-400/80 shadow-2xl shadow-amber-500/25"
              />
            ) : (
              <div className="w-24 h-24 min-w-[96px] min-h-[96px] rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 border-2 border-amber-300 flex items-center justify-center font-black text-neutral-950 text-4xl shadow-2xl shadow-amber-500/30 uppercase">
                {initial}
              </div>
            )}
            <div className="absolute -bottom-2 -end-2 p-2 rounded-xl bg-[#111118] border border-amber-400/60 shadow-lg text-amber-400">
              <Lock className="w-4 h-4" />
            </div>
          </div>

          <h1 className="text-xl sm:text-2xl font-black text-gold-gradient tracking-tight">
            {displayName}
          </h1>
          <p className="text-xs text-neutral-300 mt-1 font-medium">
            {!isPinConfigured
              ? setupStep === 'first'
                ? language === 'ar'
                  ? 'مرحباً بك! قم بتعيين كود جديد من 6 أرقام لحماية متجرك'
                  : 'Bienvenue ! Définissez votre nouveau code à 6 chiffres'
                : language === 'ar'
                ? 'أعد إدخال الكود لتأكيده'
                : 'Confirmez votre code à 6 chiffres'
              : t.lock.subtitle}
          </p>
        </div>

        {/* Role Selector (Owner vs Employee - Partie 3 #1) */}
        {!isLockedOut && (
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-[#0E0E15] border border-neutral-800 text-xs">
            <button
              type="button"
              onClick={() => setSelectedRole('owner')}
              className={`flex items-center justify-center gap-1.5 py-2 rounded-lg font-bold transition ${
                selectedRole === 'owner'
                  ? 'bg-amber-500 text-neutral-950 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'المالك (المدير)' : 'Propriétaire'}</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedRole('employee')}
              className={`flex items-center justify-center gap-1.5 py-2 rounded-lg font-bold transition ${
                selectedRole === 'employee'
                  ? 'bg-amber-500 text-neutral-950 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>{language === 'ar' ? 'المستخدم (موظف)' : 'Employé'}</span>
            </button>
          </div>
        )}

        {/* Lockout Warning State */}
        {isLockedOut ? (
          <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-500/50 text-rose-300 space-y-3 shadow-xl">
            <div className="flex items-center justify-center gap-2 text-rose-400 font-bold text-sm">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
              <span>{t.lock.lockedOutTitle}</span>
            </div>
            <p className="text-xs text-rose-200/90 leading-relaxed">
              {t.lock.lockedOutDesc}
            </p>
            <div className="pt-2 border-t border-rose-500/30 flex flex-col items-center">
              <span className="text-[11px] text-rose-300 mb-1">{t.lock.timeRemaining}</span>
              <div className="flex items-center gap-2 font-mono font-black text-2xl text-rose-400 tracking-wider bg-[#0E0E15] px-4 py-1.5 rounded-xl border border-rose-500/40 shadow-inner">
                <Clock className="w-5 h-5 text-rose-400 animate-spin" style={{ animationDuration: '3s' }} />
                <span>{formatTimer(lockoutSecondsLeft)}</span>
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* 6-Digit PIN Indicator Slots */}
            <div
              className={`flex items-center justify-center gap-3 py-1.5 ${
                isShaking ? 'animate-[shake_0.4s_ease-in-out]' : ''
              }`}
            >
              {[0, 1, 2, 3, 4, 5].map((idx) => {
                const isFilled = idx < pin.length;
                return (
                  <div
                    key={idx}
                    className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full transition-all duration-200 border ${
                      isFilled
                        ? 'bg-gradient-to-br from-amber-300 to-amber-500 border-amber-300 scale-110 shadow-[0_0_12px_rgba(212,175,55,0.85)]'
                        : 'bg-[#0E0E15] border-amber-500/30 shadow-inner'
                    }`}
                  />
                );
              })}
            </div>

            {errorMessage && (
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-400 text-xs font-semibold flex items-center justify-center gap-2 animate-fadeIn">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* 3D Gold Virtual Keypad */}
            <div className="grid grid-cols-3 gap-2 sm:gap-2.5 pt-1">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleDigit(digit)}
                  disabled={isLockedOut || isVerifying}
                  className="h-14 sm:h-16 rounded-2xl bg-gradient-to-b from-[#262636] to-[#171722] border border-amber-500/20 hover:border-amber-500/50 text-xl font-mono font-bold text-neutral-100 flex items-center justify-center transition-all duration-150 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_4px_10px_rgba(0,0,0,0.55)] hover:shadow-[0_6px_16px_rgba(0,0,0,0.65),0_0_12px_rgba(212,175,55,0.18)] active:translate-y-1 active:shadow-inner"
                >
                  {digit}
                </button>
              ))}

              <button
                type="button"
                onClick={handleClear}
                disabled={isLockedOut || isVerifying || pin.length === 0}
                className="h-14 sm:h-16 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs font-bold text-neutral-400 hover:text-neutral-200 flex items-center justify-center transition active:translate-y-0.5 disabled:opacity-30 disabled:pointer-events-none"
              >
                {t.lock.clear}
              </button>

              <button
                type="button"
                onClick={() => handleDigit('0')}
                disabled={isLockedOut || isVerifying}
                className="h-14 sm:h-16 rounded-2xl bg-gradient-to-b from-[#262636] to-[#171722] border border-amber-500/20 hover:border-amber-500/50 text-xl font-mono font-bold text-neutral-100 flex items-center justify-center transition-all duration-150 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),0_4px_10px_rgba(0,0,0,0.55)] hover:shadow-[0_6px_16px_rgba(0,0,0,0.65),0_0_12px_rgba(212,175,55,0.18)] active:translate-y-1 active:shadow-inner"
              >
                0
              </button>

              <button
                type="button"
                onClick={handleDelete}
                disabled={isLockedOut || isVerifying || pin.length === 0}
                className="h-14 sm:h-16 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-amber-400 flex items-center justify-center transition active:translate-y-0.5 disabled:opacity-30 disabled:pointer-events-none"
                aria-label="Effacer un chiffre"
              >
                <Delete className="w-5 h-5" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
